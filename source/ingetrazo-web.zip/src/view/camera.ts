// SPDX-License-Identifier: GPL-3.0-or-later
// IngeTrazo Web — Z-up camera: orbit around the point under the cursor,
// pan, zoom toward the cursor, perspective ↔ parallel, standard views.
import { OrthographicCamera, PerspectiveCamera, Vector3, type Camera } from 'three';

export type StdView = 'top' | 'bottom' | 'front' | 'back' | 'left' | 'right' | 'iso';
/** A standard view, or any direction to look from (toward the model). */
export type ViewSpec = StdView | Vector3;

export class CameraRig {
  persp: PerspectiveCamera;
  ortho: OrthographicCamera;
  parallel = false;
  /** The point orbit and zoom revolve around. */
  target = new Vector3(0, 0, 0);
  width = 1;
  height = 1;

  constructor() {
    this.persp = new PerspectiveCamera(35, 1, 0.01, 10000);
    this.ortho = new OrthographicCamera(-1, 1, 1, -1, -10000, 10000);
    for (const c of [this.persp, this.ortho]) c.up.set(0, 0, 1);
    this.persp.position.set(8, -10, 6);
    this.lookAt(this.target);
  }

  get camera(): Camera & (PerspectiveCamera | OrthographicCamera) {
    return this.parallel ? this.ortho : this.persp;
  }

  get position(): Vector3 {
    return this.persp.position;
  }

  resize(w: number, h: number): void {
    this.width = w;
    this.height = h;
    this.persp.aspect = w / h;
    this.persp.updateProjectionMatrix();
    this.syncOrtho();
  }

  private lookAt(p: Vector3): void {
    this.persp.lookAt(p);
    this.persp.updateMatrixWorld();
    this.syncOrtho();
  }

  /** Parallel camera framed like the perspective one at the target depth. */
  private syncOrtho(): void {
    const d = this.persp.position.distanceTo(this.target);
    const h = 2 * d * Math.tan((this.persp.fov * Math.PI) / 360);
    const w = h * (this.width / this.height);
    const o = this.ortho;
    o.left = -w / 2;
    o.right = w / 2;
    o.top = h / 2;
    o.bottom = -h / 2;
    o.position.copy(this.persp.position);
    o.quaternion.copy(this.persp.quaternion);
    o.near = -d * 50 - 1000;
    o.far = d * 50 + 1000;
    o.zoom = 1;
    o.updateProjectionMatrix();
    o.updateMatrixWorld();
    const near = Math.max(0.005, d / 2000);
    this.persp.near = near;
    this.persp.far = Math.max(1000, d * 200);
    this.persp.updateProjectionMatrix();
  }

  setParallel(on: boolean): void {
    this.parallel = on;
    this.syncOrtho();
  }

  /** Orbit by screen pixels around ``pivot`` (default: the target). */
  orbit(dx: number, dy: number, pivot?: Vector3): void {
    const piv = pivot ?? this.target;
    const cam = this.persp;
    const az = -dx * 0.006;
    const el = -dy * 0.006;
    const offset = cam.position.clone().sub(piv);
    const toTarget = this.target.clone().sub(piv);
    // Azimuth around world Z.
    offset.applyAxisAngle(new Vector3(0, 0, 1), az);
    toTarget.applyAxisAngle(new Vector3(0, 0, 1), az);
    // Elevation around the camera's right axis, clamped short of the poles.
    const dir = this.target.clone().sub(cam.position).normalize().applyAxisAngle(new Vector3(0, 0, 1), az);
    // Polar angle of the camera seen from the target, measured from +Z.
    const phi = Math.acos(Math.max(-1, Math.min(1, -dir.z)));
    const newPhi = Math.min(Math.PI - 0.01, Math.max(0.01, phi + el));
    const dEl = newPhi - phi;
    const right = new Vector3().crossVectors(dir, new Vector3(0, 0, 1)).normalize();
    if (right.lengthSq() > 0) {
      offset.applyAxisAngle(right, dEl);
      toTarget.applyAxisAngle(right, dEl);
    }
    cam.position.copy(piv).add(offset);
    this.target.copy(piv).add(toTarget);
    this.lookAt(this.target);
  }

  /** World size of one pixel at the target depth. */
  pixelSize(at?: Vector3): number {
    const p = at ?? this.target;
    if (this.parallel) return (this.ortho.top - this.ortho.bottom) / this.ortho.zoom / this.height;
    const d = Math.max(1e-3, this.persp.position.distanceTo(p));
    return (2 * d * Math.tan((this.persp.fov * Math.PI) / 360)) / this.height;
  }

  pan(dx: number, dy: number, at?: Vector3): void {
    const s = this.pixelSize(at);
    const cam = this.persp;
    const right = new Vector3().setFromMatrixColumn(cam.matrixWorld, 0);
    const up = new Vector3().setFromMatrixColumn(cam.matrixWorld, 1);
    const move = right.multiplyScalar(-dx * s).addScaledVector(up, dy * s);
    cam.position.add(move);
    this.target.add(move);
    this.lookAt(this.target);
  }

  /** Dolly toward ``at`` (world point under the cursor). factor < 1 = closer. */
  zoom(factor: number, at?: Vector3): void {
    const cam = this.persp;
    const focus = at ?? this.target;
    const d = cam.position.distanceTo(focus);
    if (factor < 1 && d < 0.02) return;
    cam.position.sub(focus).multiplyScalar(factor).add(focus);
    this.target.sub(focus).multiplyScalar(factor).add(focus);
    // Keep the target ahead of the camera at a sensible depth.
    const fwd = new Vector3();
    cam.getWorldDirection(fwd);
    const depth = this.target.clone().sub(cam.position).dot(fwd);
    if (depth < 0.05) this.target.copy(cam.position).addScaledVector(fwd, 0.05);
    this.lookAt(this.target);
  }

  /** Frame a bounding box. */
  fit(min: Vector3, max: Vector3, view?: ViewSpec): void {
    const center = min.clone().add(max).multiplyScalar(0.5);
    const radius = Math.max(0.5, min.distanceTo(max) / 2);
    let dir = this.persp.position.clone().sub(this.target).normalize();
    if (view) dir = viewDir(view);
    const fov = (this.persp.fov * Math.PI) / 180;
    const aspect = this.width / this.height;
    const fit = Math.min(fov, 2 * Math.atan(Math.tan(fov / 2) * aspect));
    const dist = (radius / Math.sin(fit / 2)) * 1.05;
    this.target.copy(center);
    this.persp.position.copy(center).addScaledVector(dir, dist);
    if (Math.abs(dir.z) > 0.9999) this.persp.position.y -= dist * 1e-4;
    this.lookAt(this.target);
  }

  setView(view: ViewSpec, min?: Vector3, max?: Vector3): void {
    if (min && max) this.fit(min, max, view);
    else {
      const d = this.persp.position.distanceTo(this.target);
      this.persp.position.copy(this.target).addScaledVector(viewDir(view), d);
      if (view === 'top' || view === 'bottom') this.persp.position.y -= d * 1e-4;
      this.lookAt(this.target);
    }
  }

  state(): { position: number[]; target: number[]; parallel: boolean } {
    return { position: this.persp.position.toArray(), target: this.target.toArray(), parallel: this.parallel };
  }

  restore(s: { position: number[]; target: number[]; parallel?: boolean }): void {
    this.persp.position.fromArray(s.position);
    this.target.fromArray(s.target);
    this.parallel = !!s.parallel;
    this.lookAt(this.target);
  }
}

function viewDir(v: ViewSpec): Vector3 {
  if (v instanceof Vector3) return v.clone().normalize();
  switch (v) {
    case 'top':
      return new Vector3(0, 0, 1);
    case 'bottom':
      return new Vector3(0, 0, -1);
    case 'front':
      return new Vector3(0, -1, 0);
    case 'back':
      return new Vector3(0, 1, 0);
    case 'left':
      return new Vector3(-1, 0, 0);
    case 'right':
      return new Vector3(1, 0, 0);
    default:
      return new Vector3(1, -1.2, 0.9).normalize();
  }
}
