// SPDX-License-Identifier: GPL-3.0-or-later
// IngeTrazo Web — turn a Mesh into GPU buffers: faces grouped by paint,
// visible hard edges as line segments, and a triangle → Face map for picking.
import {
  BufferAttribute,
  BufferGeometry,
  Color,
  DoubleSide,
  FrontSide,
  BackSide,
  type Material,
  MeshLambertMaterial,
  RepeatWrapping,
  SRGBColorSpace,
  type Texture,
  TextureLoader,
  Vector3,
} from 'three';
import type { Edge, Face, Mesh, TextureAttr } from '../core/mesh';
import { projectionBasis, triangulateFace } from '../core/plane';
import type { Model } from '../core/scene';

export const DEFAULT_FACE = new Color().setRGB(0.95, 0.94, 0.91, SRGBColorSpace);
export const DEFAULT_BACK = new Color().setRGB(0.62, 0.7, 0.78, SRGBColorSpace);
export const EDGE_COLOR = new Color().setRGB(0.13, 0.17, 0.23, SRGBColorSpace);

export type BuiltMesh = {
  version: number;
  geometry: BufferGeometry;
  /** Paint key per geometry group (``default`` = unpainted). */
  keys: string[];
  backKeys: string[];
  faceOfTri: Face[];
  edges: BufferGeometry;
  edgeList: Edge[];
};

function colorKey(c: [number, number, number] | undefined, opacity?: number): string {
  if (!c) return opacity !== undefined && opacity < 1 ? `default@${opacity}` : 'default';
  return `c:${c.map((x) => x.toFixed(4)).join(',')}${opacity !== undefined && opacity < 1 ? `@${opacity}` : ''}`;
}

function textureKey(t: TextureAttr, c?: [number, number, number], opacity?: number): string {
  const src = t.embed ?? t.path ?? '';
  return `t:${src}|${c ? c.join(',') : ''}|${opacity ?? 1}`;
}

export function faceKey(f: Face): string {
  const a = f.attrs;
  if (a.texture && (a.texture.embed || a.texture.path)) return textureKey(a.texture, a.color, a.opacity);
  return colorKey(a.color, a.opacity);
}

function backKey(f: Face): string {
  const b = f.attrs.back;
  if (b === true) return faceKey(f);
  if (b && typeof b === 'object') {
    if (b.texture && (b.texture.embed || b.texture.path)) return textureKey(b.texture, b.color);
    if (b.color) return colorKey(b.color);
  }
  return 'back';
}

function uvAxes(t: TextureAttr, n: Vector3): { gu: Vector3; cu: number; gv: Vector3; cv: number } {
  const uvw = t.uvw;
  if (uvw && uvw.length >= 8)
    return { gu: new Vector3(uvw[0], uvw[1], uvw[2]), cu: uvw[3], gv: new Vector3(uvw[4], uvw[5], uvw[6]), cv: uvw[7] };
  let [ua, va] = projectionBasis(n);
  const rot = Number(t.rot ?? 0);
  if (rot) {
    const r = (rot * Math.PI) / 180;
    const c = Math.cos(r);
    const s = Math.sin(r);
    const nu = ua.clone().multiplyScalar(c).addScaledVector(va, s);
    const nv = va.clone().multiplyScalar(c).addScaledVector(ua, -s);
    ua = nu;
    va = nv;
  }
  const sw = Number(t.sw) || 1;
  const sh = Number(t.sh) || 1;
  return { gu: ua.divideScalar(sw), cu: 0, gv: va.divideScalar(sh), cv: 0 };
}

export function buildMesh(mesh: Mesh): BuiltMesh {
  const byKey = new Map<string, { faces: Face[]; back: string }>();
  for (const f of mesh.faces) {
    if (f.attrs.hidden || f.loop.length < 3) continue;
    const k = faceKey(f);
    const bk = backKey(f);
    const kk = `${k}#${bk}`;
    if (!byKey.has(kk)) byKey.set(kk, { faces: [], back: bk });
    byKey.get(kk)!.faces.push(f);
  }
  const pos: number[] = [];
  const nor: number[] = [];
  const uv: number[] = [];
  const faceOfTri: Face[] = [];
  const geometry = new BufferGeometry();
  const keys: string[] = [];
  const backKeys: string[] = [];
  let start = 0;
  for (const [kk, { faces, back }] of byKey) {
    const key = kk.slice(0, kk.lastIndexOf('#'));
    for (const f of faces) {
      const n = f.normal();
      const { verts, tris } = triangulateFace(f);
      const tex = f.attrs.texture;
      const ax = tex ? uvAxes(tex, n) : null;
      for (let i = 0; i < tris.length; i += 3) {
        for (let j = 0; j < 3; j++) {
          const p = verts[tris[i + j]];
          pos.push(p.x, p.y, p.z);
          nor.push(n.x, n.y, n.z);
          if (ax) uv.push(ax.gu.dot(p) + ax.cu, ax.gv.dot(p) + ax.cv);
          else uv.push(0, 0);
        }
        faceOfTri.push(f);
      }
    }
    const count = pos.length / 3 - start;
    if (count > 0) {
      geometry.addGroup(start, count, keys.length);
      keys.push(key);
      backKeys.push(back);
    }
    start = pos.length / 3;
  }
  geometry.setAttribute('position', new BufferAttribute(new Float32Array(pos), 3));
  geometry.setAttribute('normal', new BufferAttribute(new Float32Array(nor), 3));
  geometry.setAttribute('uv', new BufferAttribute(new Float32Array(uv), 2));
  geometry.computeBoundingSphere();

  const ep: number[] = [];
  const edgeList: Edge[] = [];
  for (const e of mesh.edges) {
    if (e.soft || e.hidden) continue;
    if (e.faces.length && e.faces.every((f) => f.attrs.hidden)) continue;
    ep.push(e.a.x, e.a.y, e.a.z, e.b.x, e.b.y, e.b.z);
    edgeList.push(e);
  }
  const edges = new BufferGeometry();
  edges.setAttribute('position', new BufferAttribute(new Float32Array(ep), 3));
  edges.computeBoundingSphere();
  return { version: mesh.version, geometry, keys, backKeys, faceOfTri, edges, edgeList };
}

/** Materials by paint key, shared across meshes. */
export class MaterialLibrary {
  private cache = new Map<string, Material>();
  private textures = new Map<string, Texture>();
  private loader = new TextureLoader();
  xray = false;
  onTextureLoaded: () => void = () => {};

  constructor(private model: () => Model) {}

  reset(): void {
    for (const m of this.cache.values()) m.dispose();
    for (const t of this.textures.values()) t.dispose();
    this.cache.clear();
    this.textures.clear();
  }

  setXray(on: boolean): void {
    if (this.xray === on) return;
    this.xray = on;
    for (const m of this.cache.values()) m.dispose();
    this.cache.clear();
  }

  private texture(src: string): Texture | null {
    if (this.textures.has(src)) return this.textures.get(src)!;
    const img = this.model().textures.get(src);
    if (!img) return null;
    const t = this.loader.load(img.url, () => this.onTextureLoaded());
    t.wrapS = t.wrapT = RepeatWrapping;
    t.colorSpace = SRGBColorSpace;
    t.anisotropy = 4;
    this.textures.set(src, t);
    return t;
  }

  /** Material for a paint key; ``side`` front/back; ``override`` replaces
   * the unpainted default (a group's own paint). */
  get(key: string, side: 'front' | 'back', override?: [number, number, number] | null, faded = false): Material {
    const ck = `${side}|${key}|${override ? override.join(',') : ''}|${faded}`;
    const hit = this.cache.get(ck);
    if (hit) return hit;
    const m = new MeshLambertMaterial({
      side: side === 'front' ? FrontSide : BackSide,
      polygonOffset: true,
      polygonOffsetFactor: 1,
      polygonOffsetUnits: 1,
    });
    let opacity = 1;
    if (key === 'back') {
      if (override) m.color.setRGB(...override, SRGBColorSpace);
      else m.color.copy(DEFAULT_BACK);
    } else if (key.startsWith('t:')) {
      const [src, col, op] = key.slice(2).split('|');
      const tex = this.texture(src);
      if (tex) {
        m.map = tex;
        m.alphaTest = 0.4;
      }
      if (col) m.color.setRGB(...(col.split(',').map(Number) as [number, number, number]), SRGBColorSpace);
      else if (!tex) m.color.copy(DEFAULT_FACE);
      if (col && tex) m.color.set(0xffffff);
      opacity = Number(op) || 1;
    } else {
      const [base, op] = key.split('@');
      if (base === 'default') {
        if (override) m.color.setRGB(...override, SRGBColorSpace);
        else m.color.copy(DEFAULT_FACE);
      } else {
        m.color.setRGB(...(base.slice(2).split(',').map(Number) as [number, number, number]), SRGBColorSpace);
      }
      if (op) opacity = Number(op);
    }
    if (this.xray) opacity = Math.min(opacity, 0.45);
    if (faded) opacity = Math.min(opacity, 0.25);
    if (opacity < 1) {
      m.transparent = true;
      m.opacity = opacity;
      m.depthWrite = false;
      m.side = DoubleSide;
      if (side === 'back') m.visible = false;
    }
    this.cache.set(ck, m);
    return m;
  }
}
