// SPDX-License-Identifier: GPL-3.0-or-later
// IngeTrazo Web — the 3D viewport: renders the model, the selection and the
// tools' overlays; answers picking questions.
import {
  AmbientLight,
  BufferAttribute,
  BufferGeometry,
  Color,
  DirectionalLight,
  DoubleSide,
  Group as TGroup,
  HemisphereLight,
  LineBasicMaterial,
  LineSegments,
  Matrix4,
  Mesh as TMesh,
  MeshBasicMaterial,
  type Object3D,
  Raycaster,
  Scene,
  SRGBColorSpace,
  Vector2,
  Vector3,
  WebGLRenderer,
} from 'three';
import { LineSegments2 } from 'three/examples/jsm/lines/LineSegments2.js';
import { LineSegmentsGeometry } from 'three/examples/jsm/lines/LineSegmentsGeometry.js';
import { LineMaterial } from 'three/examples/jsm/lines/LineMaterial.js';
import type { Edge, Face, Mesh } from '../core/mesh';
import { triangulateFace, triangulatePolygon } from '../core/plane';
import type { Group, Model } from '../core/scene';
import { type BuiltMesh, EDGE_COLOR, MaterialLibrary, buildMesh } from './build';
import { CameraRig, type ViewSpec } from './camera';
import { ViewCube } from './viewcube';

export type Hit = {
  point: Vector3;
  distance: number;
  /** Face in the active context (when the hit is one). */
  face?: Face;
  /** Child group of the active context that was hit. */
  group?: Group;
  /** World normal of the hit face. */
  normal?: Vector3;
  /** Instance the hit belongs to (null = root mesh). */
  owner: Group | null;
  ownerFace?: Face;
};

export type EdgeHit = { edge: Edge; point: Vector3; px: number };

export type PreviewLine = { a: Vector3; b: Vector3; color?: string; width?: number; dashed?: boolean };

const SELECT_COLOR = new Color('#1f6feb');

type Instance = { group: Group | null; obj: TGroup; mesh: Mesh; world: Matrix4; faded: boolean };

export class Viewport {
  readonly renderer: WebGLRenderer;
  readonly scene = new Scene();
  readonly rig = new CameraRig();
  readonly materials: MaterialLibrary;
  private modelRoot = new TGroup();
  private overlay = new TGroup();
  private selectionObj = new TGroup();
  private previewObj = new TGroup();
  private guidesObj = new TGroup();
  private built = new Map<Mesh, BuiltMesh>();
  private instances: Instance[] = [];
  private structureSeen = -1;
  private versionsSeen = new Map<Mesh, number>();
  private needsRender = true;
  private raycaster = new Raycaster();
  private lineMats = new Map<string, LineMaterial>();
  readonly html: HTMLDivElement;
  private marker: HTMLDivElement;
  private tip: HTMLDivElement;
  private labels: HTMLDivElement;
  context: Group | null = null;
  selection: { faces: Set<Face>; edges: Set<Edge>; groups: Set<Group> } = {
    faces: new Set(),
    edges: new Set(),
    groups: new Set(),
  };
  private selectionDirty = true;
  billboards: Instance[] = [];
  showEdges = true;
  onFrame: () => void = () => {};
  /** A side of the orientation cube was clicked. */
  onViewPick: (v: ViewSpec) => void = (v) => {
    this.rig.setView(v);
    this.invalidate();
  };
  readonly viewCube: ViewCube;
  /** The view was orbited by dragging the cube. */
  onCubeOrbit: () => void = () => {};

  constructor(
    readonly canvas: HTMLCanvasElement,
    private model: () => Model,
  ) {
    this.renderer = new WebGLRenderer({ canvas, antialias: true, preserveDrawingBuffer: true });
    this.renderer.setPixelRatio(Math.min(2, window.devicePixelRatio));
    this.renderer.outputColorSpace = SRGBColorSpace;
    canvas.addEventListener('webglcontextrestored', () => {
      this.structureSeen = -1;
      this.versionsSeen.clear();
      this.invalidate();
    });
    this.materials = new MaterialLibrary(model);
    this.materials.onTextureLoaded = () => this.invalidate();
    this.scene.background = new Color().setRGB(0.925, 0.935, 0.945, SRGBColorSpace);

    const hemi = new HemisphereLight(0xffffff, 0xb9b4a8, 1.6);
    hemi.position.set(0, 0, 1);
    this.scene.add(hemi, new AmbientLight(0xffffff, 0.55));
    const sun = new DirectionalLight(0xffffff, 1.4);
    sun.position.set(0.5, -0.8, 1.2);
    this.scene.add(sun);
    const camLight = new DirectionalLight(0xffffff, 0.5);
    this.rig.persp.add(camLight);
    camLight.position.set(0.3, 0.5, 1);
    this.scene.add(this.rig.persp);

    this.scene.add(this.axes(), this.modelRoot, this.overlay);
    this.overlay.add(this.selectionObj, this.previewObj, this.guidesObj);

    const host = canvas.parentElement!;
    this.html = document.createElement('div');
    this.html.className = 'vp-html';
    host.appendChild(this.html);
    this.marker = document.createElement('div');
    this.marker.className = 'vp-marker';
    this.tip = document.createElement('div');
    this.tip.className = 'vp-tip';
    this.labels = document.createElement('div');
    this.html.append(this.labels, this.marker, this.tip);
    this.viewCube = new ViewCube(
      host,
      (v) => this.onViewPick(v),
      (dx, dy) => {
        this.rig.orbit(dx, dy);
        this.invalidate();
        this.onCubeOrbit();
      },
    );

    new ResizeObserver(() => this.resize()).observe(host);
    this.resize();
    const loop = () => {
      requestAnimationFrame(loop);
      this.frame();
    };
    requestAnimationFrame(loop);
  }

  private axes(): Object3D {
    const g = new TGroup();
    const L = 1e4;
    // Each axis in pieces of growing length: a single 10 km segment whose far
    // end lies behind the camera is dropped by some GPUs instead of clipped.
    const mk = (_a: number[], b: number[], color: string, dashed: boolean) => {
      const pos: number[] = [];
      let t0 = 0;
      for (let t1 = 1; t1 <= L; t1 *= 4) {
        pos.push(b[0] * t0 / L, b[1] * t0 / L, b[2] * t0 / L, b[0] * t1 / L, b[1] * t1 / L, b[2] * t1 / L);
        t0 = t1;
      }
      const geo = new BufferGeometry();
      geo.setAttribute('position', new BufferAttribute(new Float32Array(pos), 3));
      const m = new LineBasicMaterial({ color, transparent: dashed, opacity: dashed ? 0.35 : 0.9 });
      return new LineSegments(geo, m);
    };
    g.add(
      mk([0, 0, 0], [L, 0, 0], '#d22', false),
      mk([0, 0, 0], [-L, 0, 0], '#d22', true),
      mk([0, 0, 0], [0, L, 0], '#1a1', false),
      mk([0, 0, 0], [0, -L, 0], '#1a1', true),
      mk([0, 0, 0], [0, 0, L], '#23d', false),
      mk([0, 0, 0], [0, 0, -L], '#23d', true),
    );
    g.renderOrder = -1;
    return g;
  }

  resize(): void {
    const host = this.canvas.parentElement!;
    const w = Math.max(1, host.clientWidth);
    const h = Math.max(1, host.clientHeight);
    this.renderer.setSize(w, h, false);
    this.canvas.style.width = `${w}px`;
    this.canvas.style.height = `${h}px`;
    this.rig.resize(w, h);
    for (const m of this.lineMats.values()) m.resolution.set(w, h);
    this.invalidate();
  }

  invalidate(): void {
    this.needsRender = true;
  }

  selectionChanged(): void {
    this.selectionDirty = true;
    this.invalidate();
  }

  /** Rebuild GPU objects that went stale. */
  sync(): void {
    const model = this.model();
    let stale = this.structureSeen !== model.structure;
    const meshes = new Set<Mesh>([model.root]);
    for (const g of model.allGroups()) meshes.add(g.mesh);
    for (const m of meshes) {
      if (this.versionsSeen.get(m) !== m.version) {
        stale = true;
        const old = this.built.get(m);
        if (old) {
          old.geometry.dispose();
          old.edges.dispose();
        }
        this.built.set(m, buildMesh(m));
        this.versionsSeen.set(m, m.version);
      }
    }
    for (const m of [...this.built.keys()])
      if (!meshes.has(m)) {
        this.built.get(m)!.geometry.dispose();
        this.built.get(m)!.edges.dispose();
        this.built.delete(m);
        this.versionsSeen.delete(m);
      }
    if (stale || this.contextDirty) {
      this.contextDirty = false;
      this.structureSeen = model.structure;
      this.rebuildInstances();
      this.selectionDirty = true;
      this.invalidate();
    }
    if (this.selectionDirty) {
      this.selectionDirty = false;
      this.rebuildSelection();
      this.invalidate();
    }
  }

  private contextDirty = false;
  setContext(g: Group | null): void {
    this.context = g;
    this.contextDirty = true;
    this.invalidate();
  }

  private inContext(g: Group | null): boolean {
    if (!this.context) return true;
    let p: Group | null = g;
    while (p) {
      if (p === this.context) return true;
      p = p.parent;
    }
    return false;
  }

  private rebuildInstances(): void {
    this.modelRoot.clear();
    this.instances = [];
    this.billboards = [];
    const model = this.model();
    const edgeMat = new LineBasicMaterial({ color: EDGE_COLOR });
    const fadedEdge = new LineBasicMaterial({ color: EDGE_COLOR, transparent: true, opacity: 0.25 });
    const place = (mesh: Mesh, group: Group | null, parentObj: TGroup, parentWorld: Matrix4, paint: [number, number, number] | null) => {
      const obj = new TGroup();
      obj.matrixAutoUpdate = false;
      if (group) obj.matrix.copy(group.matrix);
      const world = parentWorld.clone().multiply(group ? group.matrix : new Matrix4());
      const faded = !this.inContext(group);
      const b = this.built.get(mesh)!;
      const override = group?.material?.color ?? paint;
      // A hole (Tinkercad style) is a see-through grey body.
      const hole = group?.extra.hole === true;
      const front = hole
        ? b.keys.map(() => this.materials.get(HOLE_KEY, 'front', null, faded))
        : b.keys.map((k) => this.materials.get(k, 'front', override, faded));
      const back = hole
        ? b.backKeys.map(() => this.materials.get(HOLE_KEY, 'back', null, faded))
        : b.backKeys.map((k, i) =>
            k === 'back' ? this.materials.get('back', 'back', null, faded) : this.materials.get(k, 'back', i >= 0 ? override : null, faded),
          );
      if (b.keys.length) {
        const geo = group?.extra.billboard === true ? billboardGeometry(b.geometry) : b.geometry;
        const f = new TMesh(geo, front);
        const bk = new TMesh(geo, back);
        f.userData = bk.userData = { owner: group, mesh };
        obj.add(f, bk);
      }
      // Face-me figures are pictures: their quad outline is not drawn.
      if (this.showEdges && !group?.extra.billboard) {
        const lines = new LineSegments(b.edges, faded ? fadedEdge : edgeMat);
        lines.userData = { lines: true };
        obj.add(lines);
      }
      parentObj.add(obj);
      obj.updateMatrixWorld(true);
      const inst = { group, obj, mesh, world, faded };
      this.instances.push(inst);
      if (group?.extra.billboard) this.billboards.push(inst);
      if (group) {
        for (const c of group.children) if (!c.hidden) place(c.mesh, c, obj, world, override ?? null);
      }
    };
    place(model.root, null, this.modelRoot, new Matrix4(), null);
    for (const g of model.groups) if (!g.hidden) place(g.mesh, g, this.modelRoot, new Matrix4(), null);
    this.modelRoot.updateMatrixWorld(true);
  }

  // ---- Selection rendering -------------------------------------------------
  private lineMat(color: string, width: number, dashed = false, depth = true): LineMaterial {
    const k = `${color}|${width}|${dashed}|${depth}`;
    let m = this.lineMats.get(k);
    if (!m) {
      m = new LineMaterial({ color: new Color(color).getHex(), linewidth: width, dashed, dashSize: 0.1, gapSize: 0.06, depthTest: depth });
      m.resolution.set(this.rig.width, this.rig.height);
      m.transparent = !depth;
      this.lineMats.set(k, m);
    }
    return m;
  }

  contextWorld(): Matrix4 {
    return this.context ? this.context.worldMatrix() : new Matrix4();
  }

  private rebuildSelection(): void {
    for (const c of this.selectionObj.children) disposeObj(c);
    this.selectionObj.clear();
    const sel = this.selection;
    const world = this.contextWorld();
    const tri: number[] = [];
    for (const f of sel.faces) {
      const { verts, tris } = triangulateFace(f);
      for (const i of tris) {
        const p = verts[i].clone().applyMatrix4(world);
        tri.push(p.x, p.y, p.z);
      }
    }
    if (tri.length) {
      const geo = new BufferGeometry();
      geo.setAttribute('position', new BufferAttribute(new Float32Array(tri), 3));
      const m = new MeshBasicMaterial({
        color: SELECT_COLOR,
        transparent: true,
        opacity: 0.28,
        side: DoubleSide,
        depthWrite: false,
        polygonOffset: true,
        polygonOffsetFactor: -1,
        polygonOffsetUnits: -1,
      });
      this.selectionObj.add(new TMesh(geo, m));
    }
    const seg: number[] = [];
    for (const e of sel.edges) {
      const a = e.a.clone().applyMatrix4(world);
      const b = e.b.clone().applyMatrix4(world);
      seg.push(a.x, a.y, a.z, b.x, b.y, b.z);
    }
    for (const g of sel.groups) seg.push(...boxSegments(g));
    if (this.context) seg.push(...boxSegments(this.context, true));
    if (seg.length) {
      const geo = new LineSegmentsGeometry();
      geo.setPositions(seg);
      this.selectionObj.add(new LineSegments2(geo, this.lineMat('#1f6feb', 2.5)));
    }
  }

  /** Extension overlay objects (world coordinates). */
  addOverlay(obj: Object3D): void {
    this.overlay.add(obj);
    this.invalidate();
  }

  /** Tape Measure guides: long dashed lines and small crosses. */
  setGuides(g: { points: Vector3[]; lines: { a: Vector3; dir: Vector3 }[] }): void {
    for (const c of this.guidesObj.children) disposeObj(c);
    this.guidesObj.clear();
    const pos: number[] = [];
    const L = 500;
    for (const l of g.lines) {
      const a = l.a.clone().addScaledVector(l.dir, -L);
      const b = l.a.clone().addScaledVector(l.dir, L);
      pos.push(a.x, a.y, a.z, b.x, b.y, b.z);
    }
    for (const p of g.points) {
      const s = 0.05;
      for (const d of [new Vector3(s, 0, 0), new Vector3(0, s, 0), new Vector3(0, 0, s)]) {
        const a = p.clone().sub(d);
        const b = p.clone().add(d);
        pos.push(a.x, a.y, a.z, b.x, b.y, b.z);
      }
    }
    if (pos.length) {
      const geo = new LineSegmentsGeometry();
      geo.setPositions(pos);
      const ls = new LineSegments2(geo, this.lineMat('#555555', 1, true));
      ls.computeLineDistances();
      this.guidesObj.add(ls);
    }
    this.invalidate();
  }

  // ---- Tool previews ---------------------------------------------------------
  setPreview(lines: PreviewLine[], faces: { pts: Vector3[]; color?: string; opacity?: number }[] = []): void {
    for (const c of this.previewObj.children) disposeObj(c);
    this.previewObj.clear();
    const byMat = new Map<string, number[]>();
    for (const l of lines) {
      const k = `${l.color ?? '#111'}|${l.width ?? 2}|${!!l.dashed}`;
      if (!byMat.has(k)) byMat.set(k, []);
      byMat.get(k)!.push(l.a.x, l.a.y, l.a.z, l.b.x, l.b.y, l.b.z);
    }
    for (const [k, pos] of byMat) {
      const [color, w, dashed] = k.split('|');
      const geo = new LineSegmentsGeometry();
      geo.setPositions(pos);
      const ls = new LineSegments2(geo, this.lineMat(color, Number(w), dashed === 'true', false));
      if (dashed === 'true') ls.computeLineDistances();
      ls.renderOrder = 10;
      this.previewObj.add(ls);
    }
    for (const f of faces) {
      if (f.pts.length < 3) continue;
      const { verts, tris } = triangulatePolygon(f.pts);
      const pos: number[] = [];
      for (const i of tris) pos.push(verts[i].x, verts[i].y, verts[i].z);
      const geo = new BufferGeometry();
      geo.setAttribute('position', new BufferAttribute(new Float32Array(pos), 3));
      const m = new MeshBasicMaterial({
        color: f.color ?? '#1f6feb',
        transparent: true,
        opacity: f.opacity ?? 0.25,
        side: DoubleSide,
        depthWrite: false,
      });
      this.previewObj.add(new TMesh(geo, m));
    }
    this.invalidate();
  }

  clearPreview(): void {
    this.setPreview([]);
    this.setMarker(null);
    this.setTip(null);
    this.setLabels([]);
  }

  setMarker(p: Vector3 | null, color = '#1a1', shape: 'dot' | 'square' | 'diamond' = 'dot'): void {
    if (!p) {
      this.marker.style.display = 'none';
      return;
    }
    const s = this.toScreen(p);
    this.marker.style.display = 'block';
    this.marker.style.transform = `translate(${s.x}px, ${s.y}px)`;
    this.marker.style.setProperty('--c', color);
    this.marker.dataset.shape = shape;
  }

  setTip(text: string | null, at?: Vector2): void {
    if (!text) {
      this.tip.style.display = 'none';
      return;
    }
    this.tip.textContent = text;
    this.tip.style.display = 'block';
    if (at) this.tip.style.transform = `translate(${at.x + 16}px, ${at.y + 18}px)`;
  }

  setLabels(items: { at: Vector3; text: string }[]): void {
    this.labels.replaceChildren(
      ...items.map((it) => {
        const d = document.createElement('div');
        d.className = 'vp-label';
        const s = this.toScreen(it.at);
        d.style.transform = `translate(${s.x}px, ${s.y}px) translate(-50%, -140%)`;
        d.textContent = it.text;
        return d;
      }),
    );
  }

  // ---- Math helpers ------------------------------------------------------------
  toScreen(p: Vector3): Vector2 {
    const v = p.clone().project(this.rig.camera);
    return new Vector2(((v.x + 1) / 2) * this.rig.width, ((1 - v.y) / 2) * this.rig.height);
  }

  /** Is ``p`` in front of the camera? */
  inFront(p: Vector3): boolean {
    const v = p.clone().applyMatrix4(this.rig.camera.matrixWorldInverse);
    return v.z < 0;
  }

  ray(x: number, y: number): { origin: Vector3; dir: Vector3 } {
    const ndc = new Vector2((x / this.rig.width) * 2 - 1, -(y / this.rig.height) * 2 + 1);
    this.raycaster.setFromCamera(ndc, this.rig.camera);
    return { origin: this.raycaster.ray.origin.clone(), dir: this.raycaster.ray.direction.clone() };
  }

  /** Front-most model hit under the cursor, respecting the edit context. */
  pick(x: number, y: number, opts: { anyContext?: boolean } = {}): Hit | null {
    const { origin, dir } = this.ray(x, y);
    this.raycaster.set(origin, dir);
    const targets: Object3D[] = [];
    this.modelRoot.traverse((o) => {
      if ((o as TMesh).isMesh && o.userData.mesh) targets.push(o);
    });
    const hits = this.raycaster.intersectObjects(targets, false);
    for (const h of hits) {
      if (h.faceIndex === undefined || h.faceIndex === null) continue;
      const owner = h.object.userData.owner as Group | null;
      const mesh = h.object.userData.mesh as Mesh;
      const built = this.built.get(mesh);
      const face = built?.faceOfTri[h.faceIndex];
      const inst = this.instances.find((i) => i.obj === h.object.parent);
      const normal = face ? face.normal().transformDirection(inst ? inst.world : new Matrix4()) : undefined;
      if (opts.anyContext) return { point: h.point, distance: h.distance, owner, ownerFace: face, normal };
      if (owner === this.context) return { point: h.point, distance: h.distance, face, normal, owner, ownerFace: face };
      // A group nested in the context: report its child-of-context ancestor.
      let g: Group | null = owner;
      while (g && g.parent !== this.context) g = g.parent;
      if (g && (this.context ? g.parent === this.context : g.parent === null)) {
        if (g.locked) continue;
        return { point: h.point, distance: h.distance, group: g, normal, owner, ownerFace: face };
      }
    }
    return null;
  }

  /** Nearest visible edge of the active context within ``maxPx``. */
  pickEdge(x: number, y: number, maxPx = 7, occluder?: Hit | null): EdgeHit | null {
    const mesh = this.context ? this.context.mesh : this.model().root;
    const world = this.contextWorld();
    const camera = this.rig.camera;
    const m = new Matrix4().multiplyMatrices(camera.projectionMatrix, camera.matrixWorldInverse).multiply(world);
    const w = this.rig.width;
    const h = this.rig.height;
    let best: EdgeHit | null = null;
    const pa = new Vector3();
    const pb = new Vector3();
    for (const e of mesh.edges) {
      if (e.hidden) continue;
      if (e.soft && !e.faces.length) continue;
      pa.copy(e.a).applyMatrix4(m);
      pb.copy(e.b).applyMatrix4(m);
      if (pa.z > 1 || pb.z > 1 || pa.z < -1 || pb.z < -1) continue;
      const ax = ((pa.x + 1) / 2) * w;
      const ay = ((1 - pa.y) / 2) * h;
      const bx = ((pb.x + 1) / 2) * w;
      const by = ((1 - pb.y) / 2) * h;
      const dx = bx - ax;
      const dy = by - ay;
      const len2 = dx * dx + dy * dy;
      let t = len2 > 0 ? ((x - ax) * dx + (y - ay) * dy) / len2 : 0;
      t = Math.max(0, Math.min(1, t));
      const d = Math.hypot(ax + t * dx - x, ay + t * dy - y);
      if (d > maxPx || (best && d >= best.px)) continue;
      const point = e.a.clone().lerp(e.b, t).applyMatrix4(world);
      if (e.soft) continue;
      if (occluder) {
        const dist = point.distanceTo(this.rig.camera.position);
        if (dist > occluder.distance * 1.002 + 0.002) continue;
      }
      best = { edge: e, point, px: d };
    }
    return best;
  }

  /** Every visible instance with its world matrix (for inference). */
  visibleInstances(): Instance[] {
    return this.instances;
  }

  // ---- Frame -------------------------------------------------------------------
  private frame(): void {
    this.sync();
    if (this.billboards.length) this.updateBillboards();
    if (!this.needsRender) return;
    this.needsRender = false;
    this.renderer.render(this.scene, this.rig.camera);
    this.viewCube.update(this.rig.camera.matrixWorldInverse);
    this.onFrame();
  }

  private bbSeen = '';
  private updateBillboards(): void {
    const cam = this.rig.position;
    const key = `${cam.x.toFixed(3)},${cam.y.toFixed(3)}`;
    if (key === this.bbSeen) return;
    this.bbSeen = key;
    for (const inst of this.billboards) {
      const b = inst.mesh.bounds();
      if (!b) continue;
      const c = b.min.clone().add(b.max).multiplyScalar(0.5);
      const f = [...inst.mesh.faces][0];
      if (!f) continue;
      const n = f.normal();
      const wc = c.clone().applyMatrix4(inst.world);
      const toCam = cam.clone().sub(wc);
      const ang = Math.atan2(toCam.y, toCam.x) - Math.atan2(n.y, n.x);
      const base = inst.group ? inst.group.matrix : new Matrix4();
      const rot = new Matrix4()
        .makeTranslation(c.x, c.y, 0)
        .multiply(new Matrix4().makeRotationZ(ang))
        .multiply(new Matrix4().makeTranslation(-c.x, -c.y, 0));
      inst.obj.matrix.copy(base).multiply(rot);
      inst.obj.updateMatrixWorld(true);
    }
    this.needsRender = true;
  }

  /** Image of the current view (for thumbnails/export). */
  snapshot(): string {
    this.renderer.render(this.scene, this.rig.camera);
    return this.canvas.toDataURL('image/png');
  }
}

/** Paint key of a hole body: grey, see-through. */
const HOLE_KEY = 'c:0.5500,0.5700,0.6000@0.35';

const billboardGeos = new WeakMap<BufferGeometry, BufferGeometry>();

/** A face-me figure shows its picture exactly once across the quad (UV 0…1,
 * as IngeTrazo's billboard pass draws it), not with the planar texture
 * projection that would tile it from the world origin and cut the figure. */
function billboardGeometry(src: BufferGeometry): BufferGeometry {
  const hit = billboardGeos.get(src);
  if (hit) return hit;
  const geo = src.clone();
  const pos = geo.getAttribute('position');
  const nor = geo.getAttribute('normal');
  const n = new Vector3(nor.getX(0), nor.getY(0), nor.getZ(0));
  // Picture's right = Z × n (to the right for a viewer facing the front).
  const right = new Vector3(0, 0, 1).cross(n);
  if (right.lengthSq() < 1e-9) right.set(1, 0, 0);
  right.normalize();
  const up = new Vector3().crossVectors(n, right).normalize();
  let u0 = Infinity;
  let u1 = -Infinity;
  let v0 = Infinity;
  let v1 = -Infinity;
  const p = new Vector3();
  for (let i = 0; i < pos.count; i++) {
    p.fromBufferAttribute(pos, i);
    u0 = Math.min(u0, p.dot(right));
    u1 = Math.max(u1, p.dot(right));
    v0 = Math.min(v0, p.dot(up));
    v1 = Math.max(v1, p.dot(up));
  }
  const uv = new Float32Array(pos.count * 2);
  for (let i = 0; i < pos.count; i++) {
    p.fromBufferAttribute(pos, i);
    uv[i * 2] = (p.dot(right) - u0) / Math.max(1e-9, u1 - u0);
    uv[i * 2 + 1] = (p.dot(up) - v0) / Math.max(1e-9, v1 - v0);
  }
  geo.setAttribute('uv', new BufferAttribute(uv, 2));
  billboardGeos.set(src, geo);
  return geo;
}

function boxSegments(g: Group, dashedLook = false): number[] {
  const b = g.mesh.bounds();
  const world = g.worldMatrix();
  const min = b ? b.min.clone() : new Vector3();
  const max = b ? b.max.clone() : new Vector3();
  const childBoxes = [...g.children];
  for (const c of childBoxes) {
    const cb = c.mesh.bounds();
    if (!cb) continue;
    for (const corner of corners(cb.min, cb.max)) {
      const p = corner.applyMatrix4(c.matrix);
      min.min(p);
      max.max(p);
    }
  }
  if (!b && !childBoxes.length) return [];
  const pad = dashedLook ? 0.02 : 0;
  min.subScalar(pad);
  max.addScalar(pad);
  const cs = corners(min, max).map((p) => p.applyMatrix4(world));
  const idx = [0, 1, 1, 3, 3, 2, 2, 0, 4, 5, 5, 7, 7, 6, 6, 4, 0, 4, 1, 5, 2, 6, 3, 7];
  const out: number[] = [];
  for (const i of idx) out.push(cs[i].x, cs[i].y, cs[i].z);
  return out;
}

function corners(min: Vector3, max: Vector3): Vector3[] {
  const out: Vector3[] = [];
  for (let i = 0; i < 8; i++)
    out.push(new Vector3(i & 1 ? max.x : min.x, i & 2 ? max.y : min.y, i & 4 ? max.z : min.z));
  return out;
}

function disposeObj(o: Object3D, materials = true): void {
  o.traverse((c) => {
    const m = c as TMesh;
    if (m.geometry) m.geometry.dispose();
    if (materials && m.material && !(m.material instanceof LineMaterial)) {
      const mats = Array.isArray(m.material) ? m.material : [m.material];
      for (const x of mats) x.dispose();
    }
  });
}
