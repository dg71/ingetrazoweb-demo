// SPDX-License-Identifier: GPL-3.0-or-later
// IngeTrazo Web — orientation cube: a small CSS-3D cube in the viewport
// corner that turns with the camera. Every side is a 3×3 grid of regions:
// the centre looks straight at that side, the border strips look at one of
// the 12 edges (between two sides) and the corner cells at one of the
// 8 corners (between three sides). Hovering a region lights it up on every
// side it touches; dragging the cube orbits the view (a click without
// moving still picks a region); the house button returns to the iso view.
import { Matrix4, Vector3 } from 'three';
import type { StdView, ViewSpec } from './camera';
import { t } from '../i18n';

type Side = { view: StdView; label: string; title: string; n: Vector3; right: Vector3; up: Vector3 };

// Z-up: the front view looks from −Y, so the cube's front face points to −Y.
const SIDES: Side[] = [
  { view: 'top', label: t('TOP'), title: t('Top view'), n: new Vector3(0, 0, 1), right: new Vector3(1, 0, 0), up: new Vector3(0, 1, 0) },
  { view: 'bottom', label: t('BOTTOM'), title: t('Bottom view'), n: new Vector3(0, 0, -1), right: new Vector3(1, 0, 0), up: new Vector3(0, -1, 0) },
  { view: 'front', label: t('FRONT'), title: t('Front view'), n: new Vector3(0, -1, 0), right: new Vector3(1, 0, 0), up: new Vector3(0, 0, 1) },
  { view: 'back', label: t('BACK'), title: t('Back view'), n: new Vector3(0, 1, 0), right: new Vector3(-1, 0, 0), up: new Vector3(0, 0, 1) },
  { view: 'right', label: t('RIGHT'), title: t('Right view'), n: new Vector3(1, 0, 0), right: new Vector3(0, 1, 0), up: new Vector3(0, 0, 1) },
  { view: 'left', label: t('LEFT'), title: t('Left view'), n: new Vector3(-1, 0, 0), right: new Vector3(0, -1, 0), up: new Vector3(0, 0, 1) },
];

const HALF = 30; // px: half the cube's edge

const NAMES: Record<string, string> = { x: t('right'), '-x': t('left'), y: t('back'), '-y': t('front'), z: t('top'), '-z': t('bottom') };

function css(m: number[]): string {
  return `matrix3d(${m.map((x) => (Math.abs(x) < 1e-10 ? 0 : x).toFixed(6)).join(',')})`;
}

/** Stable key of a region direction (components −1/0/1). */
function keyOf(d: Vector3): string {
  return `${Math.round(d.x)},${Math.round(d.y)},${Math.round(d.z)}`;
}

/** "Schrägansicht oben vorne rechts" for the tooltip (edge: two parts, corner: three). */
function nameOf(d: Vector3): string {
  const parts: string[] = [];
  if (d.z) parts.push(NAMES[d.z > 0 ? 'z' : '-z']);
  if (d.y) parts.push(NAMES[d.y > 0 ? 'y' : '-y']);
  if (d.x) parts.push(NAMES[d.x > 0 ? 'x' : '-x']);
  const [a, b, c] = parts;
  return c === undefined ? t('Oblique view {a} {b}', { a, b }) : t('Oblique view {a} {b} {c}', { a, b, c });
}

export class ViewCube {
  readonly el: HTMLDivElement;
  private cube: HTMLDivElement;
  private cells = new Map<string, HTMLButtonElement[]>();
  private last = '';
  /** Set while a drag just ended, so the click that follows is ignored. */
  private dragged = false;

  constructor(host: HTMLElement, onPick: (v: ViewSpec) => void, onOrbit: (dx: number, dy: number) => void) {
    this.el = document.createElement('div');
    this.el.className = 'viewcube';
    this.el.setAttribute('role', 'group');
    this.el.setAttribute('aria-label', t('View cube'));
    this.cube = document.createElement('div');
    this.cube.className = 'viewcube-cube';
    for (const s of SIDES) {
      const face = document.createElement('div');
      face.className = `viewcube-face vc-${s.view}`;
      // Element plane: x → right, y (CSS down) → −up, z → the face normal.
      const d = s.up.clone().negate();
      face.style.transform = css([s.right.x, s.right.y, s.right.z, 0, d.x, d.y, d.z, 0, s.n.x, s.n.y, s.n.z, 0, s.n.x * HALF, s.n.y * HALF, s.n.z * HALF, 1]);
      // Rows top → bottom (up = +1 … −1), columns left → right.
      for (const j of [1, 0, -1])
        for (const i of [-1, 0, 1]) {
          const dir = s.n.clone().addScaledVector(s.right, i).addScaledVector(s.up, j);
          const key = keyOf(dir);
          const cell = document.createElement('button');
          cell.type = 'button';
          const kind = i === 0 && j === 0 ? 'side' : i !== 0 && j !== 0 ? 'corner' : 'edge';
          cell.className = `vc-cell vc-${kind}`;
          cell.dataset.key = key;
          if (kind === 'side') {
            cell.title = s.title;
            cell.setAttribute('aria-label', cell.title);
          } else {
            cell.title = nameOf(dir);
            cell.setAttribute('aria-label', cell.title);
          }
          cell.addEventListener('pointerenter', () => this.hot(key, true));
          cell.addEventListener('pointerleave', () => this.hot(key, false));
          cell.addEventListener('click', (e) => {
            e.stopPropagation();
            if (this.dragged) return;
            onPick(kind === 'side' ? s.view : dir.clone());
          });
          if (!this.cells.has(key)) this.cells.set(key, []);
          this.cells.get(key)!.push(cell);
          face.appendChild(cell);
        }
      const label = document.createElement('span');
      label.className = 'vc-label';
      label.textContent = s.label;
      face.appendChild(label);
      this.cube.appendChild(face);
    }
    const home = document.createElement('button');
    home.type = 'button';
    home.className = 'viewcube-home';
    home.title = t('Iso view');
    home.setAttribute('aria-label', home.title);
    home.innerHTML =
      '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" aria-hidden="true"><path d="M4 11l8-7 8 7v9h-5v-6H9v6H4z"/></svg>';
    home.addEventListener('click', () => onPick('iso'));
    this.el.append(this.cube, home);
    host.appendChild(this.el);
    this.dragOrbit(onOrbit);
  }

  /** Press on the cube and move: orbit. Window listeners (no pointer
   * capture) keep the click on a region working when the mouse did not move. */
  private dragOrbit(onOrbit: (dx: number, dy: number) => void): void {
    this.cube.addEventListener('pointerdown', (e) => {
      if (e.button !== 0) return;
      e.preventDefault();
      let x = e.clientX;
      let y = e.clientY;
      let moved = 0;
      this.dragged = false;
      const move = (ev: PointerEvent) => {
        const dx = ev.clientX - x;
        const dy = ev.clientY - y;
        x = ev.clientX;
        y = ev.clientY;
        moved += Math.abs(dx) + Math.abs(dy);
        if (moved < 4) return;
        if (!this.dragged) {
          this.dragged = true;
          this.el.classList.add('dragging');
        }
        onOrbit(dx, dy);
      };
      const up = () => {
        window.removeEventListener('pointermove', move);
        window.removeEventListener('pointerup', up);
        this.el.classList.remove('dragging');
        // The click (if any) fires right after pointerup; reset after it.
        setTimeout(() => (this.dragged = false), 0);
      };
      window.addEventListener('pointermove', move);
      window.addEventListener('pointerup', up);
    });
  }

  /** Light a region on every side it belongs to. */
  private hot(key: string, on: boolean): void {
    for (const c of this.cells.get(key) ?? []) c.classList.toggle('hot', on);
  }

  /** Turn the cube like the world seen through ``viewInverse``. */
  update(viewInverse: Matrix4): void {
    const e = viewInverse.elements;
    // Rotation part of the view matrix, then flip Y (CSS y points down).
    const m = [e[0], -e[1], e[2], 0, e[4], -e[5], e[6], 0, e[8], -e[9], e[10], 0, 0, 0, 0, 1];
    const tf = css(m);
    if (tf === this.last) return;
    this.last = tf;
    this.cube.style.transform = tf;
  }
}
