// SPDX-License-Identifier: GPL-3.0-or-later
// IngeTrazo Web — glTF/GLB import.
import { t } from '../i18n';
//
// glTF is metres and Y-up; the model is metres and Z-up, so the whole file
// turns +90° about X. Every glTF mesh becomes a group (a mesh used by several
// nodes becomes a component whose copies share it), placed by its node
// transform. Triangles keep their material: colour, opacity, and textures —
// the embedded image is carried into the document and every face gets the
// affine world→UV map of its triangle (``texture.uvw``), so the picture sits
// where the file put it. Coplanar triangles with the same paint merge back
// into faces; shallow creases are softened so curved surfaces read smooth.
import {
  type BufferGeometry,
  Color,
  type Material,
  Matrix4,
  type Mesh as TMesh,
  type MeshStandardMaterial,
  type Object3D,
  SRGBColorSpace,
  type Texture,
  Vector2,
  Vector3,
} from 'three';
import { GLTFLoader, type GLTF } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { type FaceAttrs, Mesh } from '../core/mesh';
import { dissolveSeams } from '../core/ops';
import { planeAxes } from '../core/plane';
import { Group, type Model } from '../core/scene';

/** glTF Y-up → model Z-up. */
const Y_TO_Z = new Matrix4().makeRotationX(Math.PI / 2);

/** Coplanar merging stops paying off (and costs time) above this. */
const MERGE_LIMIT = 200_000;

export type GltfImport = { group: Group; triangles: number; textures: number; meshes: number };

export async function importGLTF(bytes: Uint8Array, name: string, model: Model): Promise<GltfImport> {
  const loader = new GLTFLoader();
  const buf = bytes.slice().buffer as ArrayBuffer;
  const gltf: GLTF = await new Promise((resolve, reject) => loader.parse(buf, '', resolve, reject));
  const textures = new TextureStore(gltf, model);
  const root = new Group(undefined, name);
  const meshOf = new Map<BufferGeometry, Mesh>();
  let triangles = 0;
  let meshes = 0;

  gltf.scene.updateMatrixWorld(true);
  const visit = async (obj: Object3D) => {
    const tm = obj as TMesh;
    if (tm.isMesh && tm.geometry) {
      let mesh = meshOf.get(tm.geometry);
      const shared = !!mesh;
      if (!mesh) {
        mesh = new Mesh();
        triangles += await addTriangles(mesh, tm.geometry, tm.material, textures);
        finish(mesh);
        meshOf.set(tm.geometry, mesh);
        meshes++;
      }
      const g = new Group(mesh, tm.name || obj.parent?.name || t('Mesh {n}', { n: meshes }));
      // Node placement, turned Z-up: Y_TO_Z · world · Y_TO_Z⁻¹ keeps the
      // mesh in its own (Y-up) frame, so turn the geometry as well — done
      // once in addTriangles — and conjugate the matrix here.
      g.matrix.copy(Y_TO_Z.clone().multiply(tm.matrixWorld).multiply(Y_TO_Z.clone().invert()));
      g.component = shared || countUses(gltf.scene, tm.geometry) > 1;
      g.parent = root;
      root.children.push(g);
    }
    for (const c of obj.children) await visit(c);
  };
  await visit(gltf.scene);
  // A file holding a single mesh does not need the extra level.
  if (root.children.length === 1) {
    const only = root.children[0];
    only.parent = null;
    only.name = name;
    return { group: only, triangles, textures: textures.count, meshes };
  }
  return { group: root, triangles, textures: textures.count, meshes };
}

function countUses(scene: Object3D, geo: BufferGeometry): number {
  let n = 0;
  scene.traverse((o) => {
    if ((o as TMesh).isMesh && (o as TMesh).geometry === geo) n++;
  });
  return n;
}

/** Add the triangles of ``geo`` (turned Z-up) with their paint. */
async function addTriangles(mesh: Mesh, geo: BufferGeometry, material: Material | Material[], tex: TextureStore): Promise<number> {
  const pos = geo.getAttribute('position');
  const uv = geo.getAttribute('uv');
  const idx = geo.getIndex();
  const count = idx ? idx.count : pos.count;
  const mats = Array.isArray(material) ? material : [material];
  const ranges = geo.groups.length ? geo.groups : [{ start: 0, count, materialIndex: 0 }];
  let tris = 0;
  for (const r of ranges) {
    const mat = mats[r.materialIndex ?? 0] ?? mats[0];
    const paint = await paintOf(mat as MeshStandardMaterial, tex);
    const textured = !!paint.texture;
    for (let i = r.start; i + 2 < r.start + r.count && i + 2 < count; i += 3) {
      const ids = [0, 1, 2].map((k) => (idx ? idx.getX(i + k) : i + k));
      const p = ids.map((j) => new Vector3(pos.getX(j), pos.getY(j), pos.getZ(j)).applyMatrix4(Y_TO_Z));
      if (new Vector3().crossVectors(p[1].clone().sub(p[0]), p[2].clone().sub(p[0])).length() < 1e-12) continue;
      const v = p.map((q) => mesh.vertex(q));
      if (v[0] === v[1] || v[1] === v[2] || v[0] === v[2]) continue;
      const f = mesh.addFaceVerts(v);
      const attrs: FaceAttrs = structuredClone(paint);
      if (textured && uv) {
        // glTF UVs start at the image's top; the renderer's at its bottom.
        const t = ids.map((j) => new Vector2(uv.getX(j), 1 - uv.getY(j)));
        const uvw = fitUvw(p, t);
        if (uvw) attrs.texture = { ...attrs.texture, uvw };
      }
      f.attrs = attrs;
      tris++;
    }
  }
  return tris;
}

/** The affine map u = gu·p + cu, v = gv·p + cv through a triangle's three
 * corners, with gu, gv in the triangle's plane. Rounded so coplanar
 * triangles of one mapping compare equal (and merge). */
export function fitUvw(p: Vector3[], t: Vector2[]): number[] | null {
  const n = new Vector3().crossVectors(p[1].clone().sub(p[0]), p[2].clone().sub(p[0]));
  if (n.lengthSq() < 1e-24) return null;
  const [U, V] = planeAxes(n);
  const s = p.map((q) => new Vector2(q.dot(U), q.dot(V)));
  // Solve [s.x s.y 1] · [a b c]ᵀ = value for both u and v.
  const det = s[0].x * (s[1].y - s[2].y) - s[0].y * (s[1].x - s[2].x) + (s[1].x * s[2].y - s[2].x * s[1].y);
  if (Math.abs(det) < 1e-18) return null;
  const solve = (w: number[]) => {
    const a = (w[0] * (s[1].y - s[2].y) - s[0].y * (w[1] - w[2]) + (w[1] * s[2].y - w[2] * s[1].y)) / det;
    const b = (s[0].x * (w[1] - w[2]) - w[0] * (s[1].x - s[2].x) + (s[1].x * w[2] - s[2].x * w[1])) / det;
    const c = (s[0].x * (s[1].y * w[2] - s[2].y * w[1]) - s[0].y * (s[1].x * w[2] - s[2].x * w[1]) + w[0] * (s[1].x * s[2].y - s[2].x * s[1].y)) / det;
    const g = U.clone().multiplyScalar(a).addScaledVector(V, b);
    return [g.x, g.y, g.z, c];
  };
  const r = (x: number) => Math.round(x * 1e5) / 1e5;
  return [...solve(t.map((x) => x.x)), ...solve(t.map((x) => x.y))].map(r);
}

async function paintOf(m: MeshStandardMaterial | undefined, tex: TextureStore): Promise<FaceAttrs> {
  const out: FaceAttrs = {};
  if (!m) return out;
  if (m.color) {
    const c = { r: 1, g: 1, b: 1 };
    (m.color as Color).getRGB(c, SRGBColorSpace);
    const rgb: [number, number, number] = [c.r, c.g, c.b].map((x) => Math.round(x * 1e4) / 1e4) as [number, number, number];
    // White under a texture is the glTF default, not a paint.
    if (!(m.map && rgb.every((x) => x > 0.999))) out.color = rgb;
  }
  if (m.transparent && m.opacity < 1) out.opacity = Math.round(m.opacity * 1000) / 1000;
  if (m.name) out.mat = m.name;
  if (m.map) {
    const member = await tex.member(m.map);
    if (member) out.texture = { embed: member, sw: 1, sh: 1 };
  }
  return out;
}

/** Same paint on both sides of a seam (uvw rounded in fitUvw). */
function samePaint(a: FaceAttrs, b: FaceAttrs): boolean {
  return JSON.stringify(a) === JSON.stringify(b);
}

function finish(mesh: Mesh): void {
  if (mesh.faces.size < MERGE_LIMIT) dissolveSeams(mesh, [...mesh.edges], { accept: (f, g) => samePaint(f.attrs, g.attrs), local: true });
  for (const e of mesh.edges) {
    if (e.faces.length !== 2) continue;
    const d = e.faces[0].normal().dot(e.faces[1].normal());
    if (d > Math.cos((20 * Math.PI) / 180)) e.soft = true;
  }
}

/** Carries the file's images into the document's texture store. */
class TextureStore {
  private byTexture = new Map<Texture, string | null>();
  count = 0;
  constructor(
    private gltf: GLTF,
    private model: Model,
  ) {}

  async member(t: Texture): Promise<string | null> {
    if (this.byTexture.has(t)) return this.byTexture.get(t)!;
    let result: string | null = null;
    try {
      const got = await this.originalBytes(t);
      if (got) {
        const hash = fnv(got.bytes);
        const base = (got.name || t.name || 'textur').replace(/[^\w.-]+/g, '_').replace(/\.[^.]*$/, '');
        const ext = got.mime === 'image/png' ? 'png' : got.mime === 'image/webp' ? 'webp' : 'jpg';
        const member = `textures/${hash}-${base}.${ext}`;
        if (!this.model.textures.has(member)) {
          this.model.textures.set(member, {
            member,
            name: `${base}.${ext}`,
            bytes: got.bytes,
            mime: got.mime,
            url: URL.createObjectURL(new Blob([got.bytes], { type: got.mime })),
          });
          this.count++;
        }
        result = member;
      }
    } catch {
      result = null;
    }
    this.byTexture.set(t, result);
    return result;
  }

  /** The image file exactly as the glTF holds it (no re-encoding). */
  private async originalBytes(t: Texture): Promise<{ bytes: Uint8Array; mime: string; name?: string } | null> {
    const parser = this.gltf.parser;
    const assoc = parser.associations.get(t) as { textures?: number } | undefined;
    const json = parser.json as {
      textures?: { source?: number }[];
      images?: { bufferView?: number; uri?: string; mimeType?: string; name?: string }[];
    };
    const ti = assoc?.textures;
    const src = ti !== undefined ? json.textures?.[ti]?.source : undefined;
    const img = src !== undefined ? json.images?.[src] : undefined;
    if (!img) return null;
    if (img.bufferView !== undefined) {
      const ab = (await parser.getDependency('bufferView', img.bufferView)) as ArrayBuffer;
      return { bytes: new Uint8Array(ab.slice(0)), mime: img.mimeType ?? 'image/png', name: img.name };
    }
    if (img.uri?.startsWith('data:')) {
      const res = await fetch(img.uri);
      return { bytes: new Uint8Array(await res.arrayBuffer()), mime: img.mimeType ?? res.headers.get('content-type') ?? 'image/png', name: img.name };
    }
    return null; // external file next to a .gltf — not reachable from one upload
  }
}

function fnv(b: Uint8Array): string {
  let h1 = 0x811c9dc5;
  let h2 = 0x01000193;
  for (let i = 0; i < b.length; i++) {
    h1 = Math.imul(h1 ^ b[i], 16777619);
    h2 = Math.imul(h2 + b[i], 2246822519);
  }
  return ((h1 >>> 0).toString(16).padStart(8, '0') + (h2 >>> 0).toString(16).padStart(8, '0')).slice(0, 16);
}
