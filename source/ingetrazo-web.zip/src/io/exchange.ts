// SPDX-License-Identifier: GPL-3.0-or-later
// IngeTrazo Web — mesh interchange: export glTF/GLB, STL, OBJ; import STL/OBJ.
import { t } from '../i18n';
import {
  BufferGeometry,
  DoubleSide,
  Group as TGroup,
  type Material,
  Matrix4,
  Mesh as TMesh,
  MeshStandardMaterial,
  MeshLambertMaterial,
  Vector3,
} from 'three';
import { GLTFExporter } from 'three/examples/jsm/exporters/GLTFExporter.js';
import { STLExporter } from 'three/examples/jsm/exporters/STLExporter.js';
import { OBJExporter } from 'three/examples/jsm/exporters/OBJExporter.js';
import { STLLoader } from 'three/examples/jsm/loaders/STLLoader.js';
import { OBJLoader } from 'three/examples/jsm/loaders/OBJLoader.js';
import { Mesh } from '../core/mesh';
import { dissolveSeams } from '../core/ops';
import { Group, type Model } from '../core/scene';
import { buildMesh, type MaterialLibrary } from '../view/build';

/** The model as a plain three.js scene graph, Y-up (glTF convention). */
function exportScene(model: Model, mats: MaterialLibrary, yUp: boolean): TGroup {
  const root = new TGroup();
  root.name = model.name;
  if (yUp) root.rotation.x = -Math.PI / 2;
  const built = new Map<Mesh, ReturnType<typeof buildMesh>>();
  const geo = (m: Mesh) => {
    let b = built.get(m);
    if (!b) {
      b = buildMesh(m);
      built.set(m, b);
    }
    return b;
  };
  const convert = (src: Material): Material => {
    const l = src as MeshLambertMaterial;
    const out = new MeshStandardMaterial({
      color: l.color,
      map: l.map ?? null,
      transparent: l.transparent,
      opacity: l.opacity,
      alphaTest: l.alphaTest,
      side: DoubleSide,
      roughness: 0.85,
      metalness: 0,
    });
    return out;
  };
  const place = (mesh: Mesh, g: Group | null, parent: TGroup, paint: [number, number, number] | null) => {
    const obj = new TGroup();
    obj.name = g?.name ?? t('Model');
    if (g) {
      obj.matrixAutoUpdate = false;
      obj.matrix.copy(g.matrix);
      obj.matrix.decompose(obj.position, obj.quaternion, obj.scale);
      obj.matrixAutoUpdate = true;
    }
    const b = geo(mesh);
    const override = g?.material?.color ?? paint;
    if (b.keys.length) {
      const m = new TMesh(b.geometry, b.keys.map((k) => convert(mats.get(k, 'front', override))));
      m.name = obj.name;
      obj.add(m);
    }
    parent.add(obj);
    if (g) for (const c of g.children) if (!c.hidden) place(c.mesh, c, obj, override ?? null);
  };
  place(model.root, null, root, null);
  for (const g of model.groups) if (!g.hidden) place(g.mesh, g, root, null);
  root.updateMatrixWorld(true);
  return root;
}

export async function exportGLTF(model: Model, mats: MaterialLibrary, binary: boolean): Promise<Blob> {
  const scene = exportScene(model, mats, true);
  const exporter = new GLTFExporter();
  const result = await exporter.parseAsync(scene, { binary, onlyVisible: true });
  if (binary) return new Blob([result as ArrayBuffer], { type: 'model/gltf-binary' });
  return new Blob([JSON.stringify(result)], { type: 'model/gltf+json' });
}

export function exportSTL(model: Model, mats: MaterialLibrary): Blob {
  const scene = exportScene(model, mats, false);
  const out = new STLExporter().parse(scene, { binary: true }) as unknown as DataView;
  return new Blob([out.buffer as ArrayBuffer], { type: 'model/stl' });
}

export function exportOBJ(model: Model, mats: MaterialLibrary): Blob {
  const scene = exportScene(model, mats, false);
  return new Blob([new OBJExporter().parse(scene)], { type: 'text/plain' });
}

/** Triangle soup → a group whose coplanar triangles merge back into faces. */
function trianglesToGroup(geos: BufferGeometry[], scale: number, name: string): Group {
  const mesh = new Mesh();
  let tris = 0;
  for (const g of geos) {
    const pos = g.getAttribute('position');
    const idx = g.getIndex();
    const n = idx ? idx.count : pos.count;
    for (let i = 0; i + 2 < n; i += 3) {
      const at = (k: number) => {
        const j = idx ? idx.getX(k) : k;
        return new Vector3(pos.getX(j), pos.getY(j), pos.getZ(j)).multiplyScalar(scale);
      };
      const a = at(i);
      const b = at(i + 1);
      const c = at(i + 2);
      if (new Vector3().crossVectors(b.clone().sub(a), c.clone().sub(a)).length() < 1e-12) continue;
      const v = [mesh.vertex(a), mesh.vertex(b), mesh.vertex(c)];
      if (v[0] === v[1] || v[1] === v[2] || v[0] === v[2]) continue;
      mesh.addFaceVerts(v);
      tris++;
    }
  }
  // Merge coplanar neighbours (principal-plane merge), and soften shallow
  // creases so curved scans read smooth.
  if (tris < 200000) dissolveSeams(mesh, [...mesh.edges], { local: true });
  for (const e of mesh.edges) {
    if (e.faces.length !== 2) continue;
    const d = e.faces[0].normal().dot(e.faces[1].normal());
    if (d > Math.cos((20 * Math.PI) / 180)) e.soft = true;
  }
  const g = new Group(mesh, name);
  return g;
}

export function importSTL(buf: ArrayBuffer, unitScale: number, name: string): Group {
  const geo = new STLLoader().parse(buf);
  return trianglesToGroup([geo], unitScale, name);
}

export function importOBJ(text: string, unitScale: number, name: string, yUp: boolean): Group {
  const obj = new OBJLoader().parse(text);
  const geos: BufferGeometry[] = [];
  obj.updateMatrixWorld(true);
  obj.traverse((o) => {
    const m = o as TMesh;
    if (m.isMesh && m.geometry) {
      const g = m.geometry.clone();
      g.applyMatrix4(m.matrixWorld);
      geos.push(g);
    }
  });
  const g = trianglesToGroup(geos, unitScale, name);
  if (yUp) {
    const rot = new Matrix4().makeRotationX(Math.PI / 2);
    g.mesh.transformVertices([...g.mesh.vertices], (p) => p.applyMatrix4(rot));
  }
  return g;
}

export function download(blob: Blob, filename: string): void {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 5000);
}
