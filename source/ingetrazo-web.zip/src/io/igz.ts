// SPDX-License-Identifier: GPL-3.0-or-later
// IngeTrazo Web — native .igz documents (see IngeTrazo formats/igz.py).
//
//   format 1: plain JSON  {"igz_format":1,"app_version":…,"scene":{…}}
//   format 2: ZIP with document.json + textures/<hash>-<name>
//   format 3: ZIP whose big meshes are binary blocks under geom/
// All three open here; saving writes format 1 (no images) or 2 (images).
import JSZip from 'jszip';
import { Matrix4, Vector3 } from 'three';
import { t } from '../i18n';
import { bumpCurveCounter, type FaceAttrs, Mesh } from '../core/mesh';
import { Group, type MaterialDef, Model, reserveGroupName } from '../core/scene';

export const APP_VERSION = '0.1.0-web';
const MAX_FORMAT = 3;

type Json = Record<string, any>;

const GROUP_KEYS = new Set([
  'edges', 'faces', 'geom', 'proto', 'xform', 'children', 'name', 'uid', 'hidden', 'locked', 'material', 'component',
]);
const SCENE_KEYS = new Set(['edges', 'faces', 'geom', 'groups', 'protos', 'kept_components', 'materials']);

export class IgzError extends Error {}

export async function loadIgz(bytes: Uint8Array, name = t('Document')): Promise<Model> {
  const model = new Model();
  model.name = name.replace(/\.igz$/i, '');
  let data: Json;
  const geom = new Map<string, Uint8Array>();
  if (bytes[0] === 0x50 && bytes[1] === 0x4b) {
    const zip = await JSZip.loadAsync(bytes);
    const doc = zip.file('document.json');
    if (!doc) throw new IgzError(t('No document.json in the container.'));
    data = JSON.parse(await doc.async('string'));
    for (const [path, entry] of Object.entries(zip.files)) {
      if (entry.dir) continue;
      if (path.startsWith('textures/')) {
        const b = await entry.async('uint8array');
        const mime = mimeOf(path);
        model.textures.set(path, {
          member: path,
          name: path.replace(/^textures\/[0-9a-f]+-/, ''),
          bytes: b,
          mime,
          url: URL.createObjectURL(new Blob([b], { type: mime })),
        });
      } else if (path.startsWith('geom/')) {
        geom.set(path, await entry.async('uint8array'));
      }
    }
  } else {
    data = JSON.parse(new TextDecoder().decode(bytes));
  }
  const fmt = Number(data.igz_format ?? 1);
  if (fmt > MAX_FORMAT) throw new IgzError(t('This document uses format {fmt}; formats up to {max} are supported.', { fmt, max: MAX_FORMAT }));
  const scene: Json = data.scene ?? {};

  loadMesh(model.root, scene, geom);
  const protos: Mesh[] = (scene.protos ?? []).map((raw: Json) => {
    const m = new Mesh();
    loadMesh(m, raw, geom);
    return m;
  });
  const groupFrom = (raw: Json, depth = 0): Group => {
    let g: Group;
    if (raw.xform && raw.proto !== undefined && protos[raw.proto]) {
      g = new Group(protos[raw.proto], raw.name || undefined);
      g.matrix.fromArray(raw.xform.map(Number));
      g.component = raw.component !== undefined ? !!raw.component : true;
    } else {
      g = new Group(undefined, raw.name || undefined);
      loadMesh(g.mesh, raw, geom);
      g.component = !!raw.component;
    }
    if (raw.name) reserveGroupName(String(raw.name));
    if (raw.uid) g.uid = String(raw.uid);
    g.hidden = !!raw.hidden;
    g.locked = !!raw.locked;
    if (raw.material && typeof raw.material === 'object') g.material = raw.material;
    for (const [k, v] of Object.entries(raw)) if (!GROUP_KEYS.has(k)) g.extra[k] = v;
    if (depth < 32) g.adopt((raw.children ?? []).map((c: Json) => groupFrom(c, depth + 1)));
    return g;
  };
  model.groups = (scene.groups ?? []).map((r: Json) => groupFrom(r));
  model.kept = (scene.kept_components ?? []).filter((r: unknown) => r && typeof r === 'object').map((r: Json) => groupFrom(r));
  for (const raw of scene.materials ?? []) if (raw?.name) model.materials.set(raw.name, raw as MaterialDef);
  for (const [k, v] of Object.entries(scene)) if (!SCENE_KEYS.has(k)) model.extra[k] = v;
  model.touch();
  return model;
}

function mimeOf(path: string): string {
  const ext = path.split('.').pop()?.toLowerCase();
  return ext === 'png' ? 'image/png' : ext === 'webp' ? 'image/webp' : ext === 'gif' ? 'image/gif' : 'image/jpeg';
}

function faceAttrsFrom(raw: Json): FaceAttrs {
  const a: FaceAttrs = {};
  if (Array.isArray(raw.color)) a.color = raw.color.slice(0, 3).map(Number) as [number, number, number];
  if (raw.texture && typeof raw.texture === 'object') a.texture = { ...raw.texture };
  if (raw.layer) a.layer = raw.layer;
  if (raw.ifc) a.ifc = { ...raw.ifc };
  if (raw.opacity !== undefined) a.opacity = Number(raw.opacity);
  if (raw.hidden) a.hidden = true;
  if (raw.mat) a.mat = raw.mat;
  if (raw.back === true) a.back = true;
  else if (raw.back && typeof raw.back === 'object') a.back = structuredClone(raw.back);
  return a;
}

function finite(p: unknown): p is number[] {
  return Array.isArray(p) && p.length >= 3 && p.every((x) => Number.isFinite(x));
}

function loadMesh(mesh: Mesh, raw: Json, geom: Map<string, Uint8Array>): void {
  if (raw.geom) {
    loadGeometryBlock(mesh, raw.geom, geom);
    return;
  }
  for (const e of raw.edges ?? []) {
    if (!finite(e.a) || !finite(e.b)) continue;
    const a = new Vector3(e.a[0], e.a[1], e.a[2]);
    const b = new Vector3(e.b[0], e.b[1], e.b[2]);
    const v0 = mesh.vertex(a);
    const v1 = mesh.vertex(b);
    if (v0 === v1) continue;
    const edge = mesh.linkEdge(v0, v1);
    if (e.soft) edge.soft = true;
    if (e.hidden) edge.hidden = true;
    if (e.layer) edge.layer = e.layer;
    if (e.curve !== undefined && e.curve !== null) {
      edge.curve = Number(e.curve);
      bumpCurveCounter(edge.curve);
    }
  }
  for (const f of raw.faces ?? []) {
    const verts = (f.vertices ?? []).filter(finite);
    if (verts.length < 3) continue;
    const loop = verts.map((p: number[]) => new Vector3(p[0], p[1], p[2]));
    const holes = (f.holes ?? []).map((h: number[][]) => h.filter(finite).map((p) => new Vector3(p[0], p[1], p[2])));
    const face = mesh.addFace(loop, holes);
    if (face.loop.length < 3) {
      mesh.removeFace(face);
      continue;
    }
    face.attrs = faceAttrsFrom(f);
  }
}

const DTYPES: Record<string, [new (b: ArrayBuffer) => ArrayLike<number> & { length: number }, number]> = {
  '<f4': [Float32Array, 4],
  '<f8': [Float64Array, 8],
  '<i4': [Int32Array, 4],
  '<i8': [BigInt64Array as unknown as new (b: ArrayBuffer) => ArrayLike<number> & { length: number }, 8],
  '|u1': [Uint8Array, 1],
  '<u1': [Uint8Array, 1],
};

function loadGeometryBlock(mesh: Mesh, meta: Json, geom: Map<string, Uint8Array>): void {
  const blob = geom.get(meta.member);
  if (!blob) throw new IgzError(t('Geometry block {member} is missing.', { member: String(meta.member) }));
  const arrays: Record<string, ArrayLike<number | bigint>> = {};
  for (const [name, spec] of Object.entries(meta.arrays as Record<string, [string, number[], number]>)) {
    const [dtype, shape, offset] = spec;
    const dt = DTYPES[dtype];
    if (!dt) throw new IgzError(t('Unknown data type {dtype}', { dtype }));
    const count = shape.reduce((a, b) => a * b, 1);
    const start = blob.byteOffset + offset;
    const buf = blob.buffer.slice(start, start + count * dt[1]) as ArrayBuffer;
    arrays[name] = new dt[0](buf) as ArrayLike<number | bigint>;
  }
  const num = (a: ArrayLike<number | bigint>, i: number) => Number(a[i]);
  const pos = arrays.pos as ArrayLike<number>;
  const verts = [];
  for (let i = 0; i < pos.length; i += 3) verts.push(mesh.vertex(new Vector3(pos[i], pos[i + 1], pos[i + 2])));
  const edges = arrays.edges;
  const flags = arrays.edge_flags;
  const curves = arrays.edge_curve;
  const layers = arrays.edge_layer;
  const layerNames: string[] = meta.edge_layers ?? [];
  for (let i = 0, k = 0; i < edges.length; i += 2, k++) {
    const a = verts[num(edges, i)];
    const b = verts[num(edges, i + 1)];
    if (!a || !b || a === b) continue;
    const e = mesh.linkEdge(a, b);
    const fl = num(flags, k);
    e.soft = (fl & 1) !== 0;
    e.hidden = (fl & 2) !== 0;
    if (curves && num(curves, k) >= 0) {
      e.curve = num(curves, k);
      bumpCurveCounter(e.curve);
    }
    if (layers && num(layers, k) >= 0) e.layer = layerNames[num(layers, k)] ?? null;
  }
  const rings = arrays.rings;
  const sizes = arrays.ring_sizes;
  const counts = arrays.ring_counts;
  const fattr = arrays.face_attr;
  const table: Json[] = meta.face_attrs ?? [];
  let r = 0;
  let c = 0;
  for (let fi = 0; fi < counts.length; fi++) {
    const nr = num(counts, fi);
    const ringsV = [];
    for (let j = 0; j < nr; j++) {
      const sz = num(sizes, r++);
      const ring = [];
      for (let q = 0; q < sz; q++) ring.push(verts[num(rings, c++)]);
      ringsV.push(ring);
    }
    if (ringsV[0].length < 3) continue;
    const face = mesh.addFaceVerts(dedupe(ringsV[0]), ringsV.slice(1).map(dedupe).filter((h) => h.length >= 3));
    const k = num(fattr, fi);
    if (k >= 0 && table[k]) face.attrs = faceAttrsFrom(table[k]);
  }
}

function dedupe<T>(lp: T[]): T[] {
  const out: T[] = [];
  for (const v of lp) if (out[out.length - 1] !== v) out.push(v);
  while (out.length > 1 && out[0] === out[out.length - 1]) out.pop();
  return out;
}

// ---- Save ------------------------------------------------------------------

const r6 = (x: number) => Math.round(x * 1e6) / 1e6;
const pt = (p: Vector3) => [r6(p.x), r6(p.y), r6(p.z)];

function meshJson(mesh: Mesh): Json {
  const edges = [];
  for (const e of mesh.edges) {
    const o: Json = { a: pt(e.a), b: pt(e.b) };
    if (e.soft) o.soft = true;
    if (e.hidden) o.hidden = true;
    if (e.curve !== null) o.curve = e.curve;
    if (e.layer !== null) o.layer = e.layer;
    edges.push(o);
  }
  const faces = [];
  for (const f of mesh.faces) {
    const o: Json = { vertices: f.loop.map((v) => pt(v.position)) };
    if (f.holes.length) o.holes = f.holes.map((h) => h.map((v) => pt(v.position)));
    const a = f.attrs;
    if (a.color) o.color = a.color.slice();
    if (a.texture) o.texture = { ...a.texture };
    if (a.layer) o.layer = a.layer;
    if (a.ifc) o.ifc = { ...a.ifc };
    if (a.opacity !== undefined) o.opacity = a.opacity;
    if (a.hidden) o.hidden = true;
    if (a.mat) o.mat = a.mat;
    if (a.back !== undefined) o.back = structuredClone(a.back);
    faces.push(o);
  }
  return { edges, faces };
}

export async function saveIgz(model: Model): Promise<Blob> {
  const scene: Json = meshJson(model.root);
  const protoIndex = new Map<Mesh, number>();
  const protos: Json[] = [];
  const shared = new Map<Mesh, number>();
  for (const g of model.allGroups()) shared.set(g.mesh, (shared.get(g.mesh) ?? 0) + 1);
  const entry = (g: Group): Json => {
    let o: Json;
    const identity = g.matrix.equals(new Matrix4());
    if (g.component || !identity || (shared.get(g.mesh) ?? 0) > 1) {
      let idx = protoIndex.get(g.mesh);
      if (idx === undefined) {
        idx = protos.length;
        protoIndex.set(g.mesh, idx);
        protos.push({});
        protos[idx] = meshJson(g.mesh);
      }
      o = { proto: idx, xform: g.matrix.toArray().map(r6), component: g.component };
    } else {
      o = meshJson(g.mesh);
    }
    if (g.name) o.name = g.name;
    if (g.uid) o.uid = g.uid;
    if (g.hidden) o.hidden = true;
    if (g.locked) o.locked = true;
    if (g.material) o.material = structuredClone(g.material);
    Object.assign(o, g.extra);
    if (g.children.length) o.children = g.children.map(entry);
    return o;
  };
  if (model.groups.length) scene.groups = model.groups.map(entry);
  if (model.kept.length) scene.kept_components = model.kept.map(entry);
  if (protos.length) scene.protos = protos;
  if (model.materials.size) scene.materials = [...model.materials.values()];
  for (const [k, v] of Object.entries(model.extra)) if (v !== undefined) scene[k] = v;

  const used = new Set<string>();
  JSON.stringify(scene, (k, v) => {
    if (k === 'embed' && typeof v === 'string') used.add(v);
    return v;
  });
  const embedded = [...used].filter((m) => model.textures.has(m));
  const doc = { igz_format: embedded.length ? 2 : 1, app_version: APP_VERSION, scene };
  if (!embedded.length) return new Blob([JSON.stringify(doc, null, 2)], { type: 'application/json' });
  const zip = new JSZip();
  const date = new Date(Date.UTC(1980, 0, 1));
  zip.file('document.json', JSON.stringify(doc, null, 2), { date, compression: 'DEFLATE' });
  for (const m of embedded) zip.file(m, model.textures.get(m)!.bytes, { date, compression: 'STORE' });
  return zip.generateAsync({ type: 'blob', mimeType: 'application/octet-stream' });
}
