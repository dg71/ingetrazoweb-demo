// SPDX-License-Identifier: GPL-3.0-or-later
// IngeTrazo Web — tool icons (24×24, stroke = currentColor).
const svg = (body: string) =>
  `<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${body}</svg>`;

export const ICONS: Record<string, string> = {
  select: svg('<path d="M5 3l13 8-6 1.5L9 19z" fill="currentColor" fill-opacity=".12"/>'),
  line: svg('<path d="M4 20L20 4"/><circle cx="4" cy="20" r="1.6" fill="currentColor"/><circle cx="20" cy="4" r="1.6" fill="currentColor"/>'),
  rectangle: svg('<rect x="4" y="6" width="16" height="12" rx=".5" fill="currentColor" fill-opacity=".1"/>'),
  circle: svg('<circle cx="12" cy="12" r="8" fill="currentColor" fill-opacity=".1"/><circle cx="12" cy="12" r="1" fill="currentColor"/>'),
  polygon: svg('<path d="M12 3.5l7.4 4.25v8.5L12 20.5l-7.4-4.25v-8.5z" fill="currentColor" fill-opacity=".1"/>'),
  pushpull: svg('<path d="M4 15l8 4 8-4-8-4z" fill="currentColor" fill-opacity=".12"/><path d="M12 13V3M8.5 6.5L12 3l3.5 3.5"/>'),
  move: svg('<path d="M12 3v18M3 12h18M12 3l-2.5 2.5M12 3l2.5 2.5M12 21l-2.5-2.5M12 21l2.5-2.5M3 12l2.5-2.5M3 12l2.5 2.5M21 12l-2.5-2.5M21 12l-2.5 2.5"/>'),
  rotate: svg('<path d="M19 12a7 7 0 1 1-2.05-4.95"/><path d="M19 4v4h-4"/>'),
  eraser: svg('<path d="M15 4l5 5-9 9H6l-3-3z" fill="currentColor" fill-opacity=".1"/><path d="M9 10l5 5M11 18h9"/>'),
  paint: svg('<path d="M5 11l7-7 7 7-7 7z" fill="currentColor" fill-opacity=".1"/><path d="M19 13c1 1.6 1.5 2.6 1.5 3.3a1.5 1.5 0 0 1-3 0c0-.7.5-1.7 1.5-3.3z" fill="currentColor"/>'),
  tape: svg('<rect x="3" y="6" width="12" height="12" rx="3"/><circle cx="9" cy="12" r="2"/><path d="M15 15h6v3h-6M18 15v1.5"/>'),
  orbit: svg('<ellipse cx="12" cy="12" rx="9" ry="4"/><path d="M12 3a4 9 0 0 1 0 18"/><path d="M19.5 9.5l1.2 2-2.2.6"/>'),
  pan: svg('<path d="M8 13V6.5a1.5 1.5 0 0 1 3 0V12M11 11V5a1.5 1.5 0 0 1 3 0v6M14 11V6.5a1.5 1.5 0 0 1 3 0V14c0 4-2.5 6.5-6 6.5-2.6 0-4.2-1.2-5.5-3.5L4 13.5a1.5 1.5 0 0 1 2.6-1.5L8 14"/>'),
  extents: svg('<path d="M4 9V4h5M15 4h5v5M20 15v5h-5M9 20H4v-5"/><rect x="8" y="8" width="8" height="8" fill="currentColor" fill-opacity=".1"/>'),
  undo: svg('<path d="M9 14L4 9l5-5"/><path d="M4 9h11a5 5 0 0 1 0 10h-3"/>'),
  redo: svg('<path d="M15 14l5-5-5-5"/><path d="M20 9H9a5 5 0 0 0 0 10h3"/>'),
  group: svg('<rect x="3.5" y="3.5" width="17" height="17" rx="1.5" stroke-dasharray="3 2"/><rect x="7" y="9" width="6" height="8" fill="currentColor" fill-opacity=".12"/><circle cx="16" cy="9" r="2.5"/>'),
};
