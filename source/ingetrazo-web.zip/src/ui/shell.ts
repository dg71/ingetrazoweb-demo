// SPDX-License-Identifier: GPL-3.0-or-later
// IngeTrazo Web — the page skeleton, inserted by startApp when absent.
// Texts are translated at load time (switching the language reloads).
import { t } from '../i18n';

export const APP_HTML = `
<div id="app">
      <header id="menubar">
        <div class="brand" title="IngeTrazo Web">
          <svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M3 20L12 4l9 16z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><path d="M7.5 20L12 12l4.5 8" fill="currentColor" opacity=".35"/></svg>
          <span>IngeTrazo <em>Web</em></span>
        </div>
        <nav id="menus"></nav>
        <div id="doc-title"></div>
      </header>
      <aside id="toolbar" aria-label="${t('Tools')}"></aside>
      <main id="viewport">
        <canvas id="canvas" tabindex="0"></canvas>
        <div id="context-bar" hidden></div>
        <div id="drop-hint" hidden>${t('Drop the file to open it ({ext})', { ext: '.igz, .glb, .gltf, .stl, .obj' })}</div>
      </main>
      <aside id="tray"></aside>
      <footer id="statusbar">
        <div id="hint"></div>
        <label id="vcb"><span id="vcb-label">${t('Value')}</span><input id="vcb-input" autocomplete="off" spellcheck="false" /></label>
      </footer>
    </div>
    <div id="toasts" aria-live="polite"></div>
    <div id="ctxmenu" hidden></div>
    <input type="file" id="file-open" accept=".igz,.json,.glb,.gltf,.stl,.obj" hidden />
`;
