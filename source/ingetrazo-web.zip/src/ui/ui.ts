// SPDX-License-Identifier: GPL-3.0-or-later
// IngeTrazo Web — menus, toolbar, tray (Entity Info, Materials, Outliner,
// View) and the context menu.
import { Color, SRGBColorSpace } from 'three';
import type { App } from '../app';
import type { Group } from '../core/scene';
import { formatArea, formatLength, settings, type LengthUnit } from '../core/units';
import { PaintTool } from '../tools/modify';
import type { StdView } from '../view/camera';
import { ICONS } from './icons';
import { t } from '../i18n';
import type { PanelSpec } from '../ext';

export type Action = { label: string; run: () => void; key?: string; enabled?: () => boolean; checked?: () => boolean };
export type MenuSpec = { label: string; items: (Action | '-')[] }[];

const el = <K extends keyof HTMLElementTagNameMap>(tag: K, attrs: Record<string, string> = {}, ...kids: (Node | string)[]) => {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === 'class') e.className = v;
    else if (k === 'html') e.innerHTML = v;
    else e.setAttribute(k, v);
  }
  e.append(...kids);
  return e;
};

// ---- Menus -------------------------------------------------------------------
export function buildMenus(spec: MenuSpec): void {
  const nav = document.getElementById('menus')!;
  nav.replaceChildren();
  let openMenu: HTMLElement | null = null;
  const close = () => {
    openMenu?.classList.remove('open');
    openMenu = null;
  };
  for (const m of spec) {
    const wrap = el('div', { class: 'menu' });
    const btn = el('button', { type: 'button', 'aria-haspopup': 'true' }, m.label);
    const list = el('div', { class: 'menu-list', role: 'menu' });
    const render = () => {
      list.replaceChildren(
        ...m.items.map((it) => {
          if (it === '-') return el('div', { class: 'menu-sep' });
          const b = el('button', { class: 'menu-item', role: 'menuitem', type: 'button' });
          const mark = it.checked ? (it.checked() ? '✓ ' : ' ') : '';
          b.append(el('span', {}, mark + it.label), el('kbd', {}, it.key ?? ''));
          if (it.enabled && !it.enabled()) b.disabled = true;
          b.addEventListener('click', () => {
            close();
            it.run();
          });
          return b;
        }),
      );
    };
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      if (openMenu === wrap) return close();
      close();
      render();
      wrap.classList.add('open');
      openMenu = wrap;
    });
    btn.addEventListener('mouseenter', () => {
      if (openMenu && openMenu !== wrap) {
        close();
        render();
        wrap.classList.add('open');
        openMenu = wrap;
      }
    });
    wrap.append(btn, list);
    nav.appendChild(wrap);
  }
  document.addEventListener('pointerdown', (e) => {
    if (openMenu && !openMenu.contains(e.target as Node)) close();
  });
}

// ---- Toolbar -----------------------------------------------------------------
export function buildToolbar(app: App, extTools: string[], extra: { icon: string; label: string; run: () => void }[]): void {
  const bar = document.getElementById('toolbar')!;
  const groups = [
    ['select'],
    ['line', 'rectangle', 'circle', 'polygon'],
    ['pushpull', 'move', 'rotate', 'eraser', 'paint', 'tape'],
    ...(extTools.length ? [extTools] : []),
    ['orbit', 'pan'],
  ];
  const buttons = new Map<string, HTMLButtonElement>();
  for (const [gi, ids] of groups.entries()) {
    if (gi) bar.appendChild(el('div', { class: 'tool-sep' }));
    for (const id of ids) {
      const tool = app.tools.get(id)!;
      const key = tool.shortcut === ' ' ? t('Space') : tool.shortcut.toUpperCase();
      const b = el('button', { class: 'tool-btn', type: 'button', title: `${tool.name}${key ? ` (${key})` : ''}`, 'aria-label': tool.name, html: ICONS[id] });
      b.addEventListener('click', () => app.setTool(id));
      buttons.set(id, b as HTMLButtonElement);
      bar.appendChild(b);
    }
  }
  bar.appendChild(el('div', { class: 'tool-sep' }));
  for (const x of extra) {
    const b = el('button', { class: 'tool-btn', type: 'button', title: x.label, 'aria-label': x.label, html: ICONS[x.icon] });
    b.addEventListener('click', x.run);
    bar.appendChild(b);
  }
  const sync = () => {
    for (const [id, b] of buttons) b.classList.toggle('active', app.tool?.id === id);
  };
  app.on((w) => w === 'tool' && sync());
  sync();
}

// ---- Tray --------------------------------------------------------------------
const PALETTE: [string, string][] = [
  ['#f4f2ec', t('White')],
  ['#c9c5bc', t('Light grey')],
  ['#8d8a84', t('Grey')],
  ['#3d3d3d', t('Anthracite')],
  ['#b5651d', t('Brick')],
  ['#cc7a4a', t('Terracotta')],
  ['#d9b77e', t('Sand')],
  ['#e8d9b5', t('Sillar')],
  ['#a0522d', t('Dark wood')],
  ['#c8a165', t('Light wood')],
  ['#9db6a0', t('Sage')],
  ['#4f7d4f', t('Green')],
  ['#6c8eb5', t('Blue grey')],
  ['#2f5f9e', t('Blue')],
  ['#8fc6e8', t('Glass')],
  ['#c23b22', t('Red')],
  ['#e0b22f', t('Yellow')],
  ['#d4cfc4', t('Concrete')],
  ['#7a6a58', t('Earth')],
  ['#5a4636', t('Bronze')],
  ['#b0b7bd', t('Steel')],
  ['#e9c6c0', t('Pink')],
  ['#6b4e8f', t('Violet')],
  ['#1f1f1f', t('Black')],
];

function rgbOf(hex: string): [number, number, number] {
  const c = new Color(hex);
  const out = { r: 0, g: 0, b: 0 };
  c.getRGB(out, SRGBColorSpace);
  return [out.r, out.g, out.b];
}
function hexOf(rgb: [number, number, number]): string {
  return `#${new Color().setRGB(rgb[0], rgb[1], rgb[2], SRGBColorSpace).getHexString(SRGBColorSpace)}`;
}

export function buildTray(
  app: App,
  view: { setStyle: (s: string) => void; style: () => string; setView: (v: StdView) => void },
  extPanels: { spec: PanelSpec; body?: HTMLElement; refresh: () => void }[] = [],
): void {
  const tray = document.getElementById('tray')!;
  const panel = (title: string, open = true) => {
    const d = el('details', { class: 'panel' });
    d.open = open;
    d.append(el('summary', {}, title));
    const body = el('div', { class: 'panel-body' });
    d.append(body);
    tray.appendChild(d);
    return body;
  };

  // Entity Info
  const info = panel(t('Entity Info'));

  // Extension panels sit right under Entity Info.
  for (const p of extPanels) {
    p.body = panel(p.spec.title, p.spec.open ?? true);
    let queued = false;
    app.on((w) => {
      if (w === 'tool' || w === 'view' || w === 'guides' || queued) return;
      queued = true;
      requestAnimationFrame(() => {
        queued = false;
        p.refresh();
      });
    });
    p.refresh();
  }
  const renderInfo = () => {
    const s = app.sel;
    const n = s.faces.size + s.edges.size + s.groups.size;
    const dl = el('dl', { class: 'kv' });
    const row = (k: string, v: string | Node) => dl.append(el('dt', {}, k), el('dd', {}, v));
    if (!n) {
      const m = app.model;
      let faces = m.root.faces.size;
      let edges = m.root.edges.size;
      for (const g of m.allGroups()) {
        faces += g.mesh.faces.size;
        edges += g.mesh.edges.size;
      }
      row(t('Document'), m.name);
      row(t('Faces'), String(faces));
      row(t('Edges'), String(edges));
      row(t('Groups'), String([...m.allGroups()].length));
      if (app.context) row(t('Editing'), app.context.name);
      info.replaceChildren(dl, el('p', { class: 'muted' }, t('Nothing selected.')));
      return;
    }
    if (s.groups.size === 1 && !s.faces.size && !s.edges.size) {
      const g = [...s.groups][0];
      const name = el('input', { type: 'text', value: g.name }) as HTMLInputElement;
      name.addEventListener('change', () => {
        const tx = app.history.begin(t('Rename')).structure();
        g.name = name.value.trim() || g.name;
        tx.commit();
        app.emit('document');
      });
      row(g.component ? t('Component') : t('Group'), name);
      const copies = app.model.instancesOf(g.mesh).length;
      if (g.component || copies > 1) row(t('Copies'), String(copies));
      row(t('Faces'), String(g.mesh.faces.size));
      const b = g.mesh.bounds();
      if (b) {
        const sz = b.max.clone().sub(b.min);
        row(t('Size'), `${formatLength(sz.x)} × ${formatLength(sz.y)} × ${formatLength(sz.z)}`);
      }
      const area = [...g.mesh.faces].reduce((a, f) => a + f.area(), 0);
      row(t('Face'), formatArea(area));
      const ifc = g.extra.ifc as { class?: string } | undefined;
      if (ifc?.class) row('IFC', String(ifc.class));
      const acts = el('div', { class: 'row' });
      const btn = (label: string, run: () => void) => {
        const x = el('button', { class: 'btn', type: 'button' }, label);
        x.addEventListener('click', run);
        acts.appendChild(x);
      };
      btn(t('Edit'), () => app.enterGroup(g));
      btn(t('Explode'), () => app.explode());
      if (copies > 1) btn(t('Make Unique'), () => app.makeUnique());
      btn(g.locked ? t('Unlock') : t('Lock'), () => {
        const tx = app.history.begin(t('Lock')).structure();
        g.locked = !g.locked;
        tx.commit();
        if (g.locked) app.clearSelection();
        renderInfo();
      });
      info.replaceChildren(dl, acts);
      return;
    }
    if (s.faces.size === 1 && n === s.faces.size + s.edges.size && s.edges.size <= [...s.faces][0].loop.length + 64) {
      const f = [...s.faces][0];
      row(t('Face'), formatArea(f.area()));
      const nn = f.normal();
      row(t('Normal'), `${nn.x.toFixed(2)}, ${nn.y.toFixed(2)}, ${nn.z.toFixed(2)}`);
      if (f.attrs.mat) row(t('Material'), String(f.attrs.mat));
      else if (f.attrs.color) {
        const sw = el('span', { class: 'swatch', style: `display:inline-block;width:16px;vertical-align:middle;background:${hexOf(f.attrs.color)}` });
        row(t('Colour'), sw);
      } else row(t('Material'), t('Default'));
      if (f.attrs.layer) row(t('Layer'), String(f.attrs.layer));
      if (f.holes.length) row(t('Holes'), String(f.holes.length));
      const acts = el('div', { class: 'row' });
      const rev = el('button', { class: 'btn', type: 'button' }, t('Reverse'));
      rev.addEventListener('click', () => app.reverseFaces());
      acts.append(rev);
      info.replaceChildren(dl, acts);
      return;
    }
    if (s.edges.size === 1 && n === 1) {
      const e = [...s.edges][0];
      row(t('Edge'), formatLength(e.length()));
      row(t('Faces'), String(e.faces.length));
      if (e.soft) row(t('Soft'), t('yes'));
      if (e.curve !== null) row(t('Curve'), t('{n} segments', { n: app.mesh.curveEdges(e).length }));
      info.replaceChildren(dl);
      return;
    }
    const area = [...s.faces].reduce((a, f) => a + f.area(), 0);
    const len = [...s.edges].reduce((a, e) => a + e.length(), 0);
    row(t('Selection'), t('{n} entities', { n }));
    if (s.faces.size) row(t('Faces'), `${s.faces.size} · ${formatArea(area)}`);
    if (s.edges.size) row(t('Edges'), `${s.edges.size} · ${formatLength(len)}`);
    if (s.groups.size) row(t('Groups'), String(s.groups.size));
    const acts = el('div', { class: 'row' });
    const g = el('button', { class: 'btn', type: 'button' }, t('Make Group'));
    g.addEventListener('click', () => app.makeGroup());
    acts.append(g);
    info.replaceChildren(dl, acts);
  };
  app.on((w) => (w === 'selection' || w === 'history' || w === 'document' || w === 'context') && renderInfo());
  renderInfo();

  // Materials
  const mats = panel(t('Materials'));
  const renderMats = () => {
    const cur = PaintTool.current;
    const grid = el('div', { class: 'swatches' });
    for (const [hex, name] of PALETTE) {
      const rgb = rgbOf(hex);
      const active = !cur.material && cur.color && hexOf(cur.color) === hexOf(rgb);
      const b = el('button', { class: `swatch${active ? ' active' : ''}`, type: 'button', title: name, style: `background:${hex}` });
      b.addEventListener('click', () => {
        PaintTool.current = { color: rgb };
        app.setTool('paint');
        renderMats();
      });
      grid.appendChild(b);
    }
    const custom = el('input', { type: 'color', value: cur.color ? hexOf(cur.color) : '#cc8855', title: t('Custom colour') }) as HTMLInputElement;
    custom.addEventListener('input', () => {
      PaintTool.current = { color: rgbOf(custom.value) };
      app.setTool('paint');
    });
    const list = el('div', { class: 'mat-list' });
    for (const m of app.model.materials.values()) {
      const tex = m.texture as { embed?: string } | undefined;
      const img = tex?.embed ? app.model.textures.get(tex.embed) : undefined;
      const sw = el('span', {
        class: 'swatch',
        style: img ? `background-image:url(${img.url})` : `background:${m.color ? hexOf(m.color) : '#ddd'}`,
      });
      const b = el('button', { class: `mat-row${cur.material === m.name ? ' active' : ''}`, type: 'button' }, sw, m.name);
      b.addEventListener('click', () => {
        PaintTool.current = { material: m.name, color: m.color };
        app.setTool('paint');
        renderMats();
      });
      list.appendChild(b);
    }
    mats.replaceChildren(
      grid,
      el('div', { class: 'row' }, el('label', { class: 'muted' }, `${t('Custom colour')} `), custom),
      app.model.materials.size ? el('div', { class: 'muted', style: 'margin-top:10px' }, t('In document')) : '',
      list,
      el('p', { class: 'muted' }, t('Alt-click with the Paint Bucket picks up a colour.')),
    );
  };
  app.on((w) => (w === 'document' || w === 'paint') && renderMats());
  renderMats();

  // Outliner
  const outl = panel(t('Groups & Components'), false);
  const renderOutline = () => {
    const mk = (groups: Group[]): HTMLUListElement => {
      const ul = el('ul', {}) as HTMLUListElement;
      for (const g of groups) {
        const li = el('li');
        const sel = app.sel.groups.has(g) || app.context === g;
        const b = el('button', { type: 'button', class: `${sel ? 'sel' : ''} ${g.hidden ? 'hidden-g' : ''}`, title: g.name }, `${g.component ? '◆' : '▢'} ${g.name}`);
        b.addEventListener('click', () => {
          if (g.parent !== app.context) {
            app.vp.setContext(g.parent);
            app.emit('context');
          }
          app.clearSelection();
          app.sel.groups.add(g);
          app.selectionChanged();
        });
        b.addEventListener('dblclick', () => app.enterGroup(g));
        li.appendChild(b);
        if (g.children.length) li.appendChild(mk(g.children));
        ul.appendChild(li);
      }
      return ul;
    };
    const root = mk(app.model.groups);
    root.className = 'outline';
    outl.replaceChildren(app.model.groups.length ? root : el('p', { class: 'muted' }, t('No groups.')));
  };
  let pending = false;
  app.on((w) => {
    if (w === 'selection' || w === 'history' || w === 'document' || w === 'context') {
      if (pending) return;
      pending = true;
      requestAnimationFrame(() => {
        pending = false;
        renderOutline();
      });
    }
  });
  renderOutline();

  // View
  const vbody = panel(t('View'));
  const renderView = () => {
    const styles: [string, string][] = [
      ['default', t('Default')],
      ['xray', t('X-Ray')],
      ['noedges', t('No Edges')],
    ];
    const r1 = el('div', { class: 'row' });
    for (const [id, label] of styles) {
      const b = el('button', { class: `btn${view.style() === id ? ' on' : ''}`, type: 'button' }, label);
      b.addEventListener('click', () => {
        view.setStyle(id);
        renderView();
      });
      r1.appendChild(b);
    }
    const r2 = el('div', { class: 'row' });
    const views: [StdView, string][] = [
      ['iso', t('Iso')],
      ['top', t('Top')],
      ['front', t('Front')],
      ['right', t('Right')],
      ['back', t('Back')],
      ['left', t('Left')],
    ];
    for (const [v, label] of views) {
      const b = el('button', { class: 'btn', type: 'button' }, label);
      b.addEventListener('click', () => view.setView(v));
      r2.appendChild(b);
    }
    const r3 = el('div', { class: 'row' });
    const par = el('button', { class: `btn${app.vp.rig.parallel ? ' on' : ''}`, type: 'button' }, t('Parallel Projection'));
    par.addEventListener('click', () => {
      app.vp.rig.setParallel(!app.vp.rig.parallel);
      app.vp.invalidate();
      renderView();
    });
    const unit = el('select', { title: t('Length unit') }) as HTMLSelectElement;
    for (const u of ['m', 'cm', 'mm']) {
      const o = el('option', { value: u }, u) as HTMLOptionElement;
      if (settings.unit === u) o.selected = true;
      unit.appendChild(o);
    }
    unit.addEventListener('change', () => {
      settings.unit = unit.value as LengthUnit;
      try {
        localStorage.setItem('igw-unit', settings.unit);
      } catch {
        /* ignore */
      }
      app.emit('selection');
    });
    r3.append(par, el('span', { class: 'muted' }, t('Unit')), unit);
    const clear = el('button', { class: 'btn', type: 'button' }, t('Delete guides'));
    clear.addEventListener('click', () => {
      app.guides = { points: [], lines: [] };
      app.emit('guides');
    });
    vbody.replaceChildren(r1, r2, r3, el('div', { class: 'row' }, clear));
  };
  app.on((w) => w === 'view' && renderView());
  renderView();
}

// ---- Context menu ------------------------------------------------------------------
export function showContextMenu(x: number, y: number, items: (Action | '-')[]): void {
  const menu = document.getElementById('ctxmenu')!;
  menu.replaceChildren(
    ...items
      .filter((it) => it === '-' || !it.enabled || it.enabled())
      .map((it) => {
        if (it === '-') return el('div', { class: 'menu-sep' });
        const b = el('button', { type: 'button' }, el('span', {}, it.label), el('kbd', {}, it.key ?? ''));
        b.addEventListener('click', () => {
          menu.hidden = true;
          it.run();
        });
        return b;
      }),
  );
  menu.hidden = false;
  const w = menu.offsetWidth;
  const h = menu.offsetHeight;
  menu.style.left = `${Math.min(x, window.innerWidth - w - 8)}px`;
  menu.style.top = `${Math.min(y, window.innerHeight - h - 8)}px`;
  const close = (e: Event) => {
    if (menu.contains(e.target as Node)) return;
    menu.hidden = true;
    document.removeEventListener('pointerdown', close, true);
  };
  setTimeout(() => document.addEventListener('pointerdown', close, true));
}

// ---- Dialogs -------------------------------------------------------------------------
export function dialog(title: string, body: Node | string, buttons: { label: string; value: string; primary?: boolean }[] = [{ label: t('Close'), value: 'ok' }]): Promise<string> {
  return new Promise((resolve) => {
    const d = el('dialog') as HTMLDialogElement;
    const actions = el('div', { class: 'dialog-actions' });
    for (const b of buttons) {
      const x = el('button', { class: `btn${b.primary ? ' on' : ''}`, type: 'button' }, b.label);
      x.addEventListener('click', () => {
        d.close(b.value);
      });
      actions.appendChild(x);
    }
    d.append(el('h2', {}, title), typeof body === 'string' ? el('div', { html: body }) : body, actions);
    d.addEventListener('close', () => {
      resolve(d.returnValue || 'cancel');
      d.remove();
    });
    document.body.appendChild(d);
    d.showModal();
  });
}
