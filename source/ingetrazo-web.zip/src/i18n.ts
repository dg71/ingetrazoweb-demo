// SPDX-License-Identifier: GPL-3.0-or-later
// IngeTrazo Web — user-interface languages: English (source and default),
// German, Spanish.
//
// Strings are written in English in the code and wrapped in ``t()``; the
// English text is the key into the German and Spanish dictionaries
// (src/locales/). Placeholders: ``t('{n} faces', { n: 3 })``. A missing
// translation falls back to English. Extensions add their own dictionaries
// with ``addTranslations``. Switching the language reloads the app.
import LOCALES from './locales';

export type Lang = 'de' | 'en' | 'es';
export type Dict = Record<string, string>;

export const LANGS: { id: Lang; name: string }[] = [
  { id: 'en', name: 'English' },
  { id: 'de', name: 'Deutsch' },
  { id: 'es', name: 'Español' },
];

const KEY = 'igw-lang';

/** The language chosen in the menu; English until one is chosen. */
function stored(): Lang {
  try {
    const s = localStorage.getItem(KEY);
    if (s === 'de' || s === 'en' || s === 'es') return s;
  } catch {
    /* storage blocked */
  }
  return 'en';
}

export const lang: Lang = typeof window === 'undefined' ? 'en' : stored();

const dicts: Record<'de' | 'es', Map<string, string>> = { de: new Map(), es: new Map() };

export function addTranslations(l: 'de' | 'es', dict: Dict): void {
  for (const [k, v] of Object.entries(dict)) dicts[l].set(k, v);
}

for (const part of LOCALES) {
  addTranslations('de', part.de);
  addTranslations('es', part.es);
}

/** The text in the current language; ``{name}`` placeholders filled from ``vars``. */
export function t(s: string, vars?: Record<string, string | number>): string {
  const tr = lang === 'en' ? s : (dicts[lang].get(s) ?? s);
  return vars ? tr.replace(/\{(\w+)\}/g, (m, k: string) => (k in vars ? String(vars[k]) : m)) : tr;
}

/** BCP-47 tag for number formatting (de-AT keeps the decimal comma). */
export function locale(): string {
  return lang === 'de' ? 'de-AT' : lang === 'es' ? 'es-ES' : 'en-GB';
}

export function setLang(l: Lang): void {
  try {
    localStorage.setItem(KEY, l);
  } catch {
    /* storage blocked */
  }
  location.reload();
}
