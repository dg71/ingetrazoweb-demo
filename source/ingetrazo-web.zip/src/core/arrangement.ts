// SPDX-License-Identifier: GPL-3.0-or-later
// IngeTrazo Web — planar arrangement: rebuild every face of one plane from
// its edges (the idea behind IngeTrazo core/cap_rebuild.py).
//
// All edges lying in the plane form a planar graph. Walking it with the
// "next = most clockwise turn" rule yields every bounded region (counter-
// clockwise cycles) and every component's outer boundary (clockwise cycles,
// which become holes of the region that contains them). Each region is then
// matched against the faces that were there before:
//   * covered by an old face  → the region becomes a face carrying its paint
//                                and orientation (an unchanged region keeps
//                                the very same Face object);
//   * bounded by a new edge   → a fresh face (closing a loop draws a face);
//   * otherwise               → stays empty (a hole the user punched).
import { Vector2, Vector3 } from 'three';
import { Edge, Face, type FaceAttrs, Mesh, Vertex } from './mesh';
import { Plane, interiorPoints, planeAxes, pointInRegion, pointInRegionLoose, project2, signedArea2 } from './plane';

export type RebuildOptions = {
  /** Regions whose outer boundary uses one of these may become new faces. */
  newEdges?: Set<Edge>;
  /** Coplanar seams to drop: the faces on both sides merge. */
  dissolve?: Set<Edge>;
  /** Paint for brand-new faces. */
  attrs?: FaceAttrs;
  /** Preferred normal direction for brand-new faces. */
  orientHint?: Vector3;
  /** Only look at the coplanar faces connected to the dissolved seams
   * (instead of every edge of the mesh): fast seam merging on big imports. */
  local?: boolean;
};

type Cycle = { verts: Vertex[]; area: number; pts: Vector2[] };

export function facesInPlane(mesh: Mesh, plane: Plane, seed?: Iterable<Edge>): Set<Face> {
  const out = new Set<Face>();
  const src = seed ? [...seed].flatMap((e) => e.faces) : [...mesh.faces];
  for (const f of src) {
    if (out.has(f)) continue;
    if (Math.abs(Math.abs(f.normal().dot(plane.n)) - 1) > 1e-5) continue;
    let ok = true;
    for (const lp of f.loops())
      for (const v of lp)
        if (!plane.contains(v.position)) {
          ok = false;
          break;
        }
    if (ok) out.add(f);
  }
  return out;
}

export function rebuildPlane(mesh: Mesh, plane: Plane, opts: RebuildOptions = {}): Face[] {
  const dissolve = opts.dissolve ?? new Set<Edge>();
  const newEdges = opts.newEdges ?? new Set<Edge>();
  const [u, v] = planeAxes(plane.n);

  const inPlane: Edge[] = [];
  if (opts.local && dissolve.size) {
    // The coplanar region around the seams, flooded across in-plane edges.
    const region = coplanarRegion(plane, dissolve);
    const seen = new Set<Edge>();
    for (const f of region)
      for (const [a, b] of f.sides()) {
        const e = mesh.findEdge(a, b);
        if (e && !seen.has(e) && !dissolve.has(e)) {
          seen.add(e);
          inPlane.push(e);
        }
      }
  } else {
    for (const e of mesh.edges) {
      if (dissolve.has(e)) continue;
      if (plane.contains(e.a) && plane.contains(e.b)) inPlane.push(e);
    }
  }
  const oldFaces = facesInPlane(mesh, plane, [...inPlane, ...dissolve]);

  const p2 = new Map<Vertex, Vector2>();
  const at = (x: Vertex) => {
    let q = p2.get(x);
    if (!q) {
      q = project2(x.position, u, v);
      p2.set(x, q);
    }
    return q;
  };

  // Graph adjacency (vertex → neighbour vertices).
  const graph = new Set<Edge>(inPlane);
  let cycles: Cycle[] = [];
  for (let pass = 0; pass < 64; pass++) {
    pruneDangling(graph);
    cycles = traverse(graph, at);
    const bridges = new Set<Edge>();
    for (const c of cycles) {
      const seen = new Set<Edge>();
      const n = c.verts.length;
      for (let i = 0; i < n; i++) {
        const e = mesh.findEdge(c.verts[i], c.verts[(i + 1) % n]);
        if (!e) continue;
        if (seen.has(e)) bridges.add(e);
        seen.add(e);
      }
    }
    if (!bridges.size) break;
    for (const b of bridges) graph.delete(b);
  }

  // Components (union-find over graph edges).
  const parent = new Map<Vertex, Vertex>();
  const find = (x: Vertex): Vertex => {
    let r = x;
    while (parent.get(r) && parent.get(r) !== r) r = parent.get(r)!;
    let c = x;
    while (parent.get(c) && parent.get(c) !== r) {
      const nx = parent.get(c)!;
      parent.set(c, r);
      c = nx;
    }
    return r;
  };
  for (const e of graph) {
    if (!parent.has(e.v0)) parent.set(e.v0, e.v0);
    if (!parent.has(e.v1)) parent.set(e.v1, e.v1);
    const a = find(e.v0);
    const b = find(e.v1);
    if (a !== b) parent.set(a, b);
  }

  const eps = 1e-12;
  const regions = cycles.filter((c) => c.area > eps).map((c) => ({ ...c, holes: [] as Cycle[] }));
  const outers = cycles.filter((c) => c.area < -eps);
  for (const c of outers) {
    const comp = find(c.verts[0]);
    let best: (typeof regions)[number] | null = null;
    for (const r of regions) {
      if (find(r.verts[0]) === comp) continue;
      if (best && r.area >= best.area) continue;
      if (pointInPolyLoose(c.pts[0], r.pts)) best = r;
    }
    if (best) best.holes.push(c);
  }

  // Old faces in 2D for the coverage test.
  const old = [...oldFaces].map((f) => ({
    face: f,
    outer: f.loop.map(at),
    holes: f.holes.map((h) => h.map(at)),
    sig: faceSig(f.loop, f.holes),
    sign: f.normal().dot(plane.n) >= 0 ? 1 : -1,
  }));

  const keep = new Set<Face>();
  const created: Face[] = [];
  const toAdd: { loop: Vertex[]; holes: Vertex[][]; attrs: FaceAttrs; interior: boolean; sign: number }[] = [];
  for (const r of regions) {
    const sig = faceSig(r.verts, r.holes.map((h) => h.verts));
    const same = old.find((o) => o.sig === sig);
    if (same) {
      keep.add(same.face);
      continue;
    }
    // Which old face covered this region? A single sample point can land
    // exactly on a seam that was just dissolved (on the boundary of both
    // faces it separated) and match neither: try several points, then
    // count the boundary as inside.
    const samples = interiorPoints(r.pts, r.holes.map((h) => h.pts));
    if (!samples.length) continue;
    let owner: (typeof old)[number] | undefined;
    for (const ip of samples) {
      owner = old.find((o) => pointInRegion(ip, o.outer, o.holes));
      if (owner) break;
    }
    if (!owner) owner = old.find((o) => pointInRegionLoose(samples[0], o.outer, o.holes));
    if (owner) {
      toAdd.push({
        loop: r.verts,
        holes: r.holes.map((h) => h.verts),
        attrs: owner.face.attrs,
        interior: owner.face.interior,
        sign: owner.sign,
      });
      continue;
    }
    if (!newEdges.size) continue;
    let touches = false;
    const n = r.verts.length;
    for (let i = 0; i < n && !touches; i++) {
      const e = mesh.findEdge(r.verts[i], r.verts[(i + 1) % n]);
      if (e && newEdges.has(e)) touches = true;
    }
    if (!touches) continue;
    const hint = opts.orientHint;
    toAdd.push({
      loop: r.verts,
      holes: r.holes.map((h) => h.verts),
      attrs: opts.attrs ?? {},
      interior: false,
      sign: hint && hint.dot(plane.n) < 0 ? -1 : 1,
    });
  }

  for (const o of old) if (!keep.has(o.face)) mesh.removeFace(o.face);
  for (const t of toAdd) {
    // Regions are CCW about plane.n, holes CW; a face facing -n flips both.
    const loop = t.sign > 0 ? t.loop.slice() : t.loop.slice().reverse();
    const holes = t.holes.map((h) => (t.sign > 0 ? h.slice() : h.slice().reverse()));
    const f = mesh.addFaceVerts(loop, holes);
    f.attrs = structuredClone(t.attrs);
    f.interior = t.interior;
    created.push(f);
  }

  if (dissolve.size) {
    const touched = new Set<Vertex>();
    for (const e of dissolve) {
      if (!mesh.edges.has(e)) continue;
      touched.add(e.v0);
      touched.add(e.v1);
      if (e.faces.length === 0) mesh.removeEdge(e);
    }
    for (const t of touched) mesh.collapseCollinear(t);
    mesh.pruneVertices(touched);
  }
  return created;
}

function inPlaneFace(f: Face, plane: Plane): boolean {
  if (Math.abs(Math.abs(f.normal().dot(plane.n)) - 1) > 1e-5) return false;
  for (const lp of f.loops()) for (const v of lp) if (!plane.contains(v.position)) return false;
  return true;
}

function coplanarRegion(plane: Plane, seeds: Iterable<Edge>): Set<Face> {
  const out = new Set<Face>();
  const stack: Face[] = [];
  for (const e of seeds) for (const f of e.faces) if (!out.has(f) && inPlaneFace(f, plane)) (out.add(f), stack.push(f));
  while (stack.length) {
    const f = stack.pop()!;
    for (const [a, b] of f.sides()) {
      for (const e of a.edges) {
        if (!e.has(b)) continue;
        for (const g of e.faces) if (!out.has(g) && inPlaneFace(g, plane)) (out.add(g), stack.push(g));
      }
    }
  }
  return out;
}

function pointInPolyLoose(p: Vector2, poly: Vector2[]): boolean {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const a = poly[i];
    const b = poly[j];
    if (a.y > p.y !== b.y > p.y) {
      const x = ((b.x - a.x) * (p.y - a.y)) / (b.y - a.y) + a.x;
      if (p.x < x) inside = !inside;
    }
  }
  return inside;
}

function faceSig(loop: Vertex[], holes: Vertex[][]): string {
  const s = (lp: Vertex[]) =>
    lp
      .map((x) => x.id)
      .sort((a, b) => a - b)
      .join('.');
  return [s(loop), ...holes.map(s).sort()].join('|');
}

function pruneDangling(graph: Set<Edge>): void {
  const deg = new Map<Vertex, number>();
  const inc = new Map<Vertex, Edge[]>();
  for (const e of graph) {
    for (const x of [e.v0, e.v1]) {
      deg.set(x, (deg.get(x) ?? 0) + 1);
      if (!inc.has(x)) inc.set(x, []);
      inc.get(x)!.push(e);
    }
  }
  const stack = [...deg.entries()].filter(([, d]) => d === 1).map(([x]) => x);
  while (stack.length) {
    const x = stack.pop()!;
    if (deg.get(x) !== 1) continue;
    const e = inc.get(x)!.find((c) => graph.has(c));
    if (!e) continue;
    graph.delete(e);
    deg.set(x, 0);
    const o = e.other(x);
    const d = (deg.get(o) ?? 1) - 1;
    deg.set(o, d);
    if (d === 1) stack.push(o);
  }
}

function traverse(graph: Set<Edge>, at: (v: Vertex) => Vector2): Cycle[] {
  // Outgoing neighbours sorted counter-clockwise by angle.
  const out = new Map<Vertex, Vertex[]>();
  for (const e of graph) {
    if (!out.has(e.v0)) out.set(e.v0, []);
    if (!out.has(e.v1)) out.set(e.v1, []);
    out.get(e.v0)!.push(e.v1);
    out.get(e.v1)!.push(e.v0);
  }
  for (const [x, list] of out) {
    const p = at(x);
    list.sort((a, b) => {
      const pa = at(a);
      const pb = at(b);
      return Math.atan2(pa.y - p.y, pa.x - p.x) - Math.atan2(pb.y - p.y, pb.x - p.x);
    });
  }
  const visited = new Set<string>();
  const hk = (a: Vertex, b: Vertex) => `${a.id}>${b.id}`;
  const cycles: Cycle[] = [];
  for (const [start, list] of out) {
    for (const first of list) {
      if (visited.has(hk(start, first))) continue;
      const verts: Vertex[] = [];
      let a = start;
      let b = first;
      let guard = 0;
      while (!visited.has(hk(a, b)) && guard++ < 1e6) {
        visited.add(hk(a, b));
        verts.push(a);
        const nb = out.get(b)!;
        const i = nb.indexOf(a);
        const next = nb[(i - 1 + nb.length) % nb.length];
        a = b;
        b = next;
      }
      if (verts.length >= 3) {
        const pts = verts.map(at);
        cycles.push({ verts, pts, area: signedArea2(pts) });
      }
    }
  }
  return cycles;
}
