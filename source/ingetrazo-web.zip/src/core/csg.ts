// SPDX-License-Identifier: GPL-3.0-or-later
// IngeTrazo Web — solids and holes (as in Tinkercad): the union of the
// solids minus the union of the holes, computed by the Manifold library
// (WASM, Apache-2.0) and turned back into faces of the modeller.
//
// Every part must be a closed solid (each edge shared by exactly two
// faces, faces oriented outward) — Push/Pull boxes and cylinders are.
// Face paint survives: every triangle carries the id of the face it came
// from; faces cut by a hole take the paint of the first solid.
import { Matrix4, Vector3 } from 'three';
import type { ManifoldToplevel, Manifold } from 'manifold-3d';
import wasmUrl from 'manifold-3d/manifold.wasm?url';
import { t } from '../i18n';
import { type FaceAttrs, Mesh, PAINT_KEYS, type Vertex } from './mesh';
import { dissolveSeams } from './ops';
import { triangulateFace } from './plane';

export type Part = { mesh: Mesh; matrix: Matrix4; name?: string };

let wasm: Promise<ManifoldToplevel> | null = null;

/** The WASM module, loaded on first use. */
export function manifold(): Promise<ManifoldToplevel> {
  if (!wasm) {
    wasm = import('manifold-3d').then(async ({ default: Module }) => {
      // In the browser the .wasm file is a bundled asset; under Node the
      // loader finds it next to its own script.
      const inBrowser = typeof window !== 'undefined' && typeof document !== 'undefined';
      const m = await Module(inBrowser ? { locateFile: () => wasmUrl } : undefined);
      m.setup();
      return m;
    });
  }
  return wasm;
}

export class CsgError extends Error {}

function paintOf(a: FaceAttrs): FaceAttrs {
  const out: FaceAttrs = {};
  for (const k of PAINT_KEYS) if (a[k] !== undefined) (out as Record<string, unknown>)[k] = structuredClone(a[k]);
  return out;
}

/** Triangles of a part in the target frame, every one tagged with a face id. */
function toManifold(w: ManifoldToplevel, part: Part, attrs: FaceAttrs[]): Manifold {
  const index = new Map<Vertex, number>();
  const pos: number[] = [];
  const tris: number[] = [];
  const ids: number[] = [];
  const flip = part.matrix.determinant() < 0;
  const p = new Vector3();
  const idx = (v: Vertex) => {
    let i = index.get(v);
    if (i === undefined) {
      i = index.size;
      index.set(v, i);
      p.copy(v.position).applyMatrix4(part.matrix);
      pos.push(p.x, p.y, p.z);
    }
    return i;
  };
  for (const f of part.mesh.faces) {
    if (f.interior) continue;
    const verts = [...f.loop, ...f.holes.flat()];
    const { tris: t } = triangulateFace(f);
    const id = attrs.length;
    attrs.push(paintOf(f.attrs));
    for (let i = 0; i + 2 < t.length; i += 3) {
      const a = idx(verts[t[i]]);
      const b = idx(verts[t[i + 1]]);
      const c = idx(verts[t[i + 2]]);
      if (flip) tris.push(a, c, b);
      else tris.push(a, b, c);
      ids.push(id);
    }
  }
  const mesh = new w.Mesh({
    numProp: 3,
    vertProperties: new Float32Array(pos),
    triVerts: new Uint32Array(tris),
    faceID: new Uint32Array(ids),
  });
  const fail = () => new CsgError(t('“{name}” is not a closed solid.', { name: part.name ?? t('Solid') }));
  let m: Manifold;
  try {
    m = new w.Manifold(mesh);
  } catch {
    throw fail();
  }
  if (m.status() !== 'NoError') {
    m.delete();
    throw fail();
  }
  return m;
}

/** Solids united, holes subtracted; the result in the parts' common frame. */
export async function combine(solids: Part[], holes: Part[]): Promise<Mesh> {
  if (!solids.length) throw new CsgError(t('At least one solid (not a hole) is required.'));
  const w = await manifold();
  const attrs: FaceAttrs[] = [];
  const live: Manifold[] = [];
  const keep = <T extends Manifold>(m: T) => (live.push(m), m);
  try {
    const s = solids.map((p) => keep(toManifold(w, p, attrs)));
    const firstPaint = attrs[0] ?? {};
    const holeStart = attrs.length;
    const h = holes.map((p) => keep(toManifold(w, p, attrs)));
    let r = s.length === 1 ? s[0] : keep(w.Manifold.union(s));
    if (h.length) r = keep(r.subtract(h.length === 1 ? h[0] : keep(w.Manifold.union(h))));
    // Hole walls take the solid's paint (the cut is the solid's material).
    for (let i = holeStart; i < attrs.length; i++) attrs[i] = structuredClone(firstPaint);
    return fromManifold(r, attrs);
  } finally {
    for (const m of live) m.delete();
  }
}

/** A Manifold solid as faces of the modeller (all faces get ``attrs[faceID]``). */
export function fromManifold(r: Manifold, attrs: FaceAttrs[] = []): Mesh {
  const g = r.getMesh();
  const out = new Mesh();
  const n = g.numProp;
  const P = (i: number) => new Vector3(g.vertProperties[i * n], g.vertProperties[i * n + 1], g.vertProperties[i * n + 2]);
  const source = new Map<unknown, number>();
  for (let t = 0; t < g.triVerts.length / 3; t++) {
    const v = [0, 1, 2].map((k) => out.vertex(P(g.triVerts[t * 3 + k])));
    if (v[0] === v[1] || v[1] === v[2] || v[0] === v[2]) continue;
    const a = v[0].position;
    if (new Vector3().crossVectors(v[1].position.clone().sub(a), v[2].position.clone().sub(a)).length() < 1e-12) continue;
    const f = out.addFaceVerts(v);
    const id = g.faceID ? g.faceID[t] : 0;
    Object.assign(f.attrs, structuredClone(attrs[id] ?? {}));
    source.set(f, id);
  }
  // Triangles back into faces: coplanar neighbours of the same paint merge.
  const same = (a: FaceAttrs, b: FaceAttrs) => JSON.stringify(paintOf(a)) === JSON.stringify(paintOf(b));
  dissolveSeams(out, [...out.edges], { local: true, accept: (f, h) => same(f.attrs, h.attrs) });
  // Curved walls (a cylinder's facets) read smooth.
  for (const e of out.edges) {
    if (e.faces.length !== 2) continue;
    if (e.faces[0].normal().dot(e.faces[1].normal()) > Math.cos((20 * Math.PI) / 180)) e.soft = true;
  }
  for (const v of [...out.vertices]) out.collapseCollinear(v);
  return out;
}
