// SPDX-License-Identifier: GPL-3.0-or-later
// IngeTrazo Web — portiert nach dem Vorbild von IngeTrazo core/mesh.py
// (Copyright (C) 2026 Marco Sumari Tellez and IngeTrazo contributors).
/**
 * Shared-vertex, non-manifold connectivity mesh.
 *
 * A Vertex is a first-class shared object: coincident positions weld to one
 * vertex on insert ("sticky" geometry). An Edge references two vertices and
 * keeps a radial list of incident faces (0, 1, 2 or more — non-manifold is
 * fine). A Face is a planar polygon bounded by an outer loop of shared
 * vertices plus optional hole loops. Moving a vertex moves every edge and face
 * that references it.
 */
import { Vector3 } from 'three';

/** Weld tolerance: positions within ~0.1 mm (metres) are the same vertex. */
export const WELD_TOL = 1e-4;
const KEY_SCALE = 1e4;

let curveCounter = 1;
export function nextCurveId(): number {
  return curveCounter++;
}
export function bumpCurveCounter(id: number): void {
  if (id >= curveCounter) curveCounter = id + 1;
}

/** Face attribute keys that make up its paint (how it looks). */
export const PAINT_KEYS = ['color', 'mat', 'texture', 'opacity', 'back'] as const;

export type FaceAttrs = {
  color?: [number, number, number];
  texture?: TextureAttr;
  mat?: string;
  opacity?: number;
  layer?: string;
  ifc?: Record<string, unknown>;
  hidden?: boolean;
  back?: boolean | { color?: [number, number, number]; texture?: TextureAttr };
  [k: string]: unknown;
};

export type TextureAttr = {
  sw?: number;
  sh?: number;
  rot?: number;
  uvw?: number[];
  embed?: string;
  path?: string;
  name?: string;
  [k: string]: unknown;
};

let vid = 1;

export class Vertex {
  readonly id = vid++;
  position: Vector3;
  edges = new Set<Edge>();
  constructor(p: Vector3) {
    this.position = p.clone();
  }
  faces(): Set<Face> {
    const out = new Set<Face>();
    for (const e of this.edges) for (const f of e.faces) out.add(f);
    return out;
  }
}

export class Edge {
  v0: Vertex;
  v1: Vertex;
  faces: Face[] = [];
  soft = false;
  hidden = false;
  curve: number | null = null;
  layer: string | null = null;
  constructor(v0: Vertex, v1: Vertex) {
    this.v0 = v0;
    this.v1 = v1;
  }
  get a(): Vector3 {
    return this.v0.position;
  }
  get b(): Vector3 {
    return this.v1.position;
  }
  other(v: Vertex): Vertex {
    return v === this.v0 ? this.v1 : this.v0;
  }
  has(v: Vertex): boolean {
    return v === this.v0 || v === this.v1;
  }
  length(): number {
    return this.v0.position.distanceTo(this.v1.position);
  }
  midpoint(): Vector3 {
    return this.v0.position.clone().add(this.v1.position).multiplyScalar(0.5);
  }
}

export class Face {
  loop: Vertex[];
  holes: Vertex[][];
  attrs: FaceAttrs = {};
  /** A face inside a solid (a kept slab), not on its boundary. */
  interior = false;
  constructor(loop: Vertex[], holes: Vertex[][] = []) {
    this.loop = loop.slice();
    this.holes = holes.map((h) => h.slice());
  }

  /** Newell's area-weighted normal (not normalised). */
  newell(): Vector3 {
    const loop = this.loop;
    const n = loop.length;
    let nx = 0;
    let ny = 0;
    let nz = 0;
    for (let i = 0; i < n; i++) {
      const c = loop[i].position;
      const d = loop[(i + 1) % n].position;
      nx += (c.y - d.y) * (c.z + d.z);
      ny += (c.z - d.z) * (c.x + d.x);
      nz += (c.x - d.x) * (c.y + d.y);
    }
    return new Vector3(nx, ny, nz);
  }

  normal(): Vector3 {
    if (this.loop.length < 3) return new Vector3(0, 0, 1);
    const n = this.newell();
    const len = n.length();
    if (len < 1e-12) return new Vector3(0, 0, 1);
    return n.divideScalar(len);
  }

  /** Area of the outer loop minus the holes. */
  area(): number {
    if (this.loop.length < 3) return 0;
    let a = 0.5 * this.newell().length();
    for (const h of this.holes) a -= 0.5 * new Face(h).newell().length();
    return Math.max(0, a);
  }

  centroid(): Vector3 {
    const c = new Vector3();
    for (const v of this.loop) c.add(v.position);
    return c.divideScalar(Math.max(1, this.loop.length));
  }

  *loops(): Generator<Vertex[]> {
    yield this.loop;
    for (const h of this.holes) yield h;
  }

  /** Every boundary vertex pair (outer + holes), in loop order. */
  *sides(): Generator<[Vertex, Vertex]> {
    for (const lp of this.loops()) {
      const n = lp.length;
      for (let i = 0; i < n; i++) yield [lp[i], lp[(i + 1) % n]];
    }
  }

  vertexSet(): Set<Vertex> {
    const s = new Set<Vertex>();
    for (const lp of this.loops()) for (const v of lp) s.add(v);
    return s;
  }
}

function cell(p: Vector3): [number, number, number] {
  return [Math.round(p.x * KEY_SCALE), Math.round(p.y * KEY_SCALE), Math.round(p.z * KEY_SCALE)];
}
function keyOf(x: number, y: number, z: number): string {
  return `${x},${y},${z}`;
}

/** Compact, identity-free snapshot of a mesh (undo, clipboard). */
export type MeshData = {
  pos: number[];
  edges: number[]; // v0, v1, flags(1 soft, 2 hidden), curve (-1 none)
  edgeLayers: (string | null)[];
  faces: { rings: number[][]; attrs: FaceAttrs; interior: boolean }[];
};

export class Mesh {
  vertices = new Set<Vertex>();
  edges = new Set<Edge>();
  faces = new Set<Face>();
  private registry = new Map<string, Vertex>();
  /** Bumped by every mutation; renderers cache against it. */
  version = 0;

  touch(): void {
    this.version++;
  }

  // ---- Vertices ----------------------------------------------------------
  private lookup(p: Vector3): Vertex | undefined {
    const [x, y, z] = cell(p);
    const hit = this.registry.get(keyOf(x, y, z));
    if (hit) return hit;
    for (let dx = -1; dx <= 1; dx++)
      for (let dy = -1; dy <= 1; dy++)
        for (let dz = -1; dz <= 1; dz++) {
          if (!dx && !dy && !dz) continue;
          const v = this.registry.get(keyOf(x + dx, y + dy, z + dz));
          if (v && v.position.distanceTo(p) <= WELD_TOL) return v;
        }
    return undefined;
  }

  /** The welded vertex at ``p`` — existing or newly created. */
  vertex(p: Vector3): Vertex {
    const hit = this.lookup(p);
    if (hit) return hit;
    const v = new Vertex(p);
    const [x, y, z] = cell(p);
    this.registry.set(keyOf(x, y, z), v);
    this.vertices.add(v);
    return v;
  }

  vertexAt(p: Vector3): Vertex | undefined {
    return this.lookup(p);
  }

  private unregister(v: Vertex): void {
    const [x, y, z] = cell(v.position);
    const k = keyOf(x, y, z);
    if (this.registry.get(k) === v) this.registry.delete(k);
  }
  private register(v: Vertex): Vertex | undefined {
    const [x, y, z] = cell(v.position);
    const k = keyOf(x, y, z);
    const prev = this.registry.get(k);
    if (prev && prev !== v) return prev;
    this.registry.set(k, v);
    return undefined;
  }

  // ---- Edges -------------------------------------------------------------
  findEdge(a: Vertex, b: Vertex): Edge | undefined {
    const [small, other] = a.edges.size <= b.edges.size ? [a, b] : [b, a];
    for (const e of small.edges) if (e.has(other)) return e;
    return undefined;
  }

  linkEdge(v0: Vertex, v1: Vertex): Edge {
    if (v0 === v1) throw new Error('degenerate edge');
    const hit = this.findEdge(v0, v1);
    if (hit) return hit;
    const e = new Edge(v0, v1);
    v0.edges.add(e);
    v1.edges.add(e);
    this.edges.add(e);
    this.touch();
    return e;
  }

  addEdge(a: Vector3, b: Vector3): Edge {
    return this.linkEdge(this.vertex(a), this.vertex(b));
  }

  /** Remove an edge and every face bounded by it. */
  removeEdge(e: Edge): void {
    for (const f of e.faces.slice()) this.removeFace(f);
    e.v0.edges.delete(e);
    e.v1.edges.delete(e);
    this.edges.delete(e);
    this.touch();
  }

  /** Drop vertices no edge uses any more. */
  pruneVertices(candidates?: Iterable<Vertex>): void {
    const list = candidates ? [...candidates] : [...this.vertices];
    for (const v of list) {
      if (v.edges.size === 0 && this.vertices.has(v)) {
        this.unregister(v);
        this.vertices.delete(v);
      }
    }
  }

  // ---- Faces -------------------------------------------------------------
  /** Add a face from vertex loops; boundary edges are created if missing. */
  addFaceVerts(loop: Vertex[], holes: Vertex[][] = []): Face {
    const f = new Face(loop, holes);
    for (const [a, b] of f.sides()) {
      const e = this.linkEdge(a, b);
      e.faces.push(f);
    }
    this.faces.add(f);
    this.touch();
    return f;
  }

  addFace(loop: Vector3[], holes: Vector3[][] = []): Face {
    const lv = dedupeLoop(loop.map((p) => this.vertex(p)));
    const hv = holes.map((h) => dedupeLoop(h.map((p) => this.vertex(p)))).filter((h) => h.length >= 3);
    return this.addFaceVerts(lv, hv);
  }

  /** Drop a face, detaching it from its edges (the edges stay). */
  removeFace(f: Face): void {
    if (!this.faces.has(f)) return;
    for (const [a, b] of f.sides()) {
      const e = this.findEdge(a, b);
      if (e) {
        const i = e.faces.indexOf(f);
        if (i >= 0) e.faces.splice(i, 1);
      }
    }
    this.faces.delete(f);
    this.touch();
  }

  /** Reverse a face's orientation in place. */
  reverseFace(f: Face): void {
    f.loop.reverse();
    for (const h of f.holes) h.reverse();
    this.touch();
  }

  // ---- Topology edits ----------------------------------------------------
  /** Split ``e`` at ``p`` (a point on it); returns the middle vertex. */
  splitEdge(e: Edge, p: Vector3): Vertex {
    const mid = this.vertex(p);
    if (mid === e.v0 || mid === e.v1) return mid;
    const { v0, v1 } = e;
    const faces = e.faces.slice();
    const flags = { soft: e.soft, hidden: e.hidden, curve: e.curve, layer: e.layer };
    v0.edges.delete(e);
    v1.edges.delete(e);
    this.edges.delete(e);
    const e1 = this.linkEdge(v0, mid);
    const e2 = this.linkEdge(mid, v1);
    for (const ne of [e1, e2]) Object.assign(ne, flags);
    for (const f of faces) {
      for (const lp of f.loops()) insertBetween(lp, v0, v1, mid);
      if (!e1.faces.includes(f)) e1.faces.push(f);
      if (!e2.faces.includes(f)) e2.faces.push(f);
    }
    this.touch();
    return mid;
  }

  /** Move a set of vertices by ``delta``; coincident results weld. */
  translate(verts: Iterable<Vertex>, delta: Vector3): void {
    const list = [...verts];
    for (const v of list) this.unregister(v);
    for (const v of list) v.position.add(delta);
    for (const v of list) this.reregister(v);
    this.touch();
  }

  /** Re-key moved vertices, welding into any vertex that now coincides. */
  reregister(v: Vertex): void {
    if (!this.vertices.has(v)) return;
    const hit = this.lookup(v.position);
    if (hit && hit !== v) {
      this.weld(hit, v);
      return;
    }
    this.register(v);
  }

  /** Apply ``fn`` to positions of ``verts`` (rotate/scale), then re-key. */
  transformVertices(verts: Iterable<Vertex>, fn: (p: Vector3) => void): void {
    const list = [...verts];
    for (const v of list) this.unregister(v);
    for (const v of list) fn(v.position);
    for (const v of list) this.reregister(v);
    this.touch();
  }

  /** Merge ``dup`` into ``keep``: every reference to dup now names keep. */
  weld(keep: Vertex, dup: Vertex): void {
    if (keep === dup) return;
    const dupFaces = dup.faces();
    for (const e of [...dup.edges]) {
      const other = e.other(dup);
      dup.edges.delete(e);
      this.edges.delete(e);
      other.edges.delete(e);
      if (other === keep) {
        // Collapsed to a point: faces lose the side, handled below.
        continue;
      }
      const existing = this.findEdge(keep, other);
      if (existing) {
        for (const f of e.faces) if (!existing.faces.includes(f)) existing.faces.push(f);
      } else {
        const ne = new Edge(keep, other);
        ne.faces = e.faces;
        ne.soft = e.soft;
        ne.hidden = e.hidden;
        ne.curve = e.curve;
        ne.layer = e.layer;
        keep.edges.add(ne);
        other.edges.add(ne);
        this.edges.add(ne);
      }
    }
    for (const f of dupFaces) {
      let touched = false;
      for (const lp of f.loops()) {
        for (let i = 0; i < lp.length; i++)
          if (lp[i] === dup) {
            lp[i] = keep;
            touched = true;
          }
      }
      if (touched) {
        f.loop = dedupeLoop(f.loop);
        f.holes = f.holes.map(dedupeLoop).filter((h) => h.length >= 3);
        if (f.loop.length < 3) {
          this.removeFaceLoose(f);
        }
      }
    }
    this.unregister(dup);
    this.vertices.delete(dup);
    this.register(keep);
    this.touch();
  }

  private removeFaceLoose(f: Face): void {
    for (const e of this.edges) {
      const i = e.faces.indexOf(f);
      if (i >= 0) e.faces.splice(i, 1);
    }
    this.faces.delete(f);
  }

  /** Collapse a degree-2 vertex between two collinear edges. */
  collapseCollinear(v: Vertex): boolean {
    if (v.edges.size !== 2) return false;
    const [e1, e2] = [...v.edges];
    const a = e1.other(v);
    const b = e2.other(v);
    if (a === b) return false;
    const d1 = a.position.clone().sub(v.position);
    const d2 = b.position.clone().sub(v.position);
    if (d1.length() < 1e-9 || d2.length() < 1e-9) return false;
    if (d1.normalize().dot(d2.normalize()) > -1 + 1e-9) return false;
    if (this.findEdge(a, b)) return false;
    const fs1 = new Set(e1.faces);
    if (e2.faces.length !== fs1.size || e2.faces.some((f) => !fs1.has(f))) return false;
    if (e1.soft !== e2.soft || e1.hidden !== e2.hidden) return false;
    const faces = e1.faces.slice();
    const flags = { soft: e1.soft, hidden: e1.hidden, curve: e1.curve, layer: e1.layer };
    for (const e of [e1, e2]) {
      e.v0.edges.delete(e);
      e.v1.edges.delete(e);
      this.edges.delete(e);
    }
    const ne = this.linkEdge(a, b);
    Object.assign(ne, flags);
    for (const f of faces) {
      for (const lp of f.loops()) {
        const i = lp.indexOf(v);
        if (i >= 0) lp.splice(i, 1);
      }
      ne.faces.push(f);
    }
    this.unregister(v);
    this.vertices.delete(v);
    this.touch();
    return true;
  }

  // ---- Snapshots ---------------------------------------------------------
  toData(): MeshData {
    const index = new Map<Vertex, number>();
    const pos: number[] = [];
    const id = (v: Vertex) => {
      let i = index.get(v);
      if (i === undefined) {
        i = index.size;
        index.set(v, i);
        pos.push(v.position.x, v.position.y, v.position.z);
      }
      return i;
    };
    const edges: number[] = [];
    const edgeLayers: (string | null)[] = [];
    for (const e of this.edges) {
      edges.push(id(e.v0), id(e.v1), (e.soft ? 1 : 0) | (e.hidden ? 2 : 0), e.curve ?? -1);
      edgeLayers.push(e.layer);
    }
    const faces: MeshData['faces'] = [];
    for (const f of this.faces) {
      faces.push({
        rings: [...f.loops()].map((lp) => lp.map(id)),
        attrs: structuredClone(f.attrs),
        interior: f.interior,
      });
    }
    return { pos, edges, edgeLayers, faces };
  }

  /** Replace the whole content from a snapshot. */
  loadData(d: MeshData): void {
    this.clear();
    const vs: Vertex[] = [];
    for (let i = 0; i < d.pos.length; i += 3) vs.push(this.vertex(new Vector3(d.pos[i], d.pos[i + 1], d.pos[i + 2])));
    for (let i = 0, k = 0; i < d.edges.length; i += 4, k++) {
      const a = vs[d.edges[i]];
      const b = vs[d.edges[i + 1]];
      if (a === b) continue;
      const e = this.linkEdge(a, b);
      e.soft = (d.edges[i + 2] & 1) !== 0;
      e.hidden = (d.edges[i + 2] & 2) !== 0;
      e.curve = d.edges[i + 3] >= 0 ? d.edges[i + 3] : null;
      e.layer = d.edgeLayers[k] ?? null;
    }
    for (const fd of d.faces) {
      const rings = fd.rings.map((r) => dedupeLoop(r.map((i) => vs[i])));
      if (rings[0].length < 3) continue;
      const f = this.addFaceVerts(rings[0], rings.slice(1).filter((h) => h.length >= 3));
      f.attrs = structuredClone(fd.attrs);
      f.interior = fd.interior;
    }
    this.touch();
  }

  clear(): void {
    this.vertices.clear();
    this.edges.clear();
    this.faces.clear();
    this.registry.clear();
    this.touch();
  }

  isEmpty(): boolean {
    return this.edges.size === 0 && this.faces.size === 0;
  }

  /** Edges of ``f`` (outer + holes). */
  faceEdges(f: Face): Edge[] {
    const out: Edge[] = [];
    for (const [a, b] of f.sides()) {
      const e = this.findEdge(a, b);
      if (e) out.push(e);
    }
    return out;
  }

  /** Faces forming the same curved surface (joined across soft edges). */
  surfaceOf(f: Face): Face[] {
    const seen = new Set<Face>([f]);
    const stack = [f];
    while (stack.length) {
      const g = stack.pop()!;
      for (const e of this.faceEdges(g)) {
        if (!e.soft) continue;
        for (const h of e.faces)
          if (!seen.has(h)) {
            seen.add(h);
            stack.push(h);
          }
      }
    }
    return [...seen];
  }

  /** Edges sharing ``e``'s curve id (a whole drawn circle/arc). */
  curveEdges(e: Edge): Edge[] {
    if (e.curve === null) return [e];
    const out: Edge[] = [];
    const seen = new Set<Edge>([e]);
    const stack = [e];
    while (stack.length) {
      const c = stack.pop()!;
      out.push(c);
      for (const v of [c.v0, c.v1])
        for (const n of v.edges)
          if (!seen.has(n) && n.curve === e.curve) {
            seen.add(n);
            stack.push(n);
          }
    }
    return out;
  }

  bounds(): { min: Vector3; max: Vector3 } | null {
    if (!this.vertices.size) return null;
    const min = new Vector3(Infinity, Infinity, Infinity);
    const max = new Vector3(-Infinity, -Infinity, -Infinity);
    for (const v of this.vertices) {
      min.min(v.position);
      max.max(v.position);
    }
    return { min, max };
  }
}

/** Insert ``mid`` between adjacent ``a``/``b`` wherever they sit in ``lp``. */
function insertBetween(lp: Vertex[], a: Vertex, b: Vertex, mid: Vertex): void {
  const n = lp.length;
  for (let i = 0; i < n; i++) {
    const p = lp[i];
    const q = lp[(i + 1) % n];
    if ((p === a && q === b) || (p === b && q === a)) {
      lp.splice(i + 1, 0, mid);
      return;
    }
  }
}

/** Remove consecutive duplicates (including wrap-around). */
export function dedupeLoop(lp: Vertex[]): Vertex[] {
  const out: Vertex[] = [];
  for (const v of lp) if (out[out.length - 1] !== v) out.push(v);
  while (out.length > 1 && out[0] === out[out.length - 1]) out.pop();
  return out;
}
