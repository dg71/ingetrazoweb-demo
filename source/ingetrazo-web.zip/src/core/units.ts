// SPDX-License-Identifier: GPL-3.0-or-later
// IngeTrazo Web — lengths are stored in metres (as in IngeTrazo core/units.py);
// typed values understand unit suffixes and both decimal separators.
// Output follows the UI language: decimal point in English, comma in German
// and Spanish.
import { locale } from '../i18n';

export type LengthUnit = 'm' | 'cm' | 'mm';

const FACTOR: Record<string, number> = {
  m: 1,
  cm: 0.01,
  mm: 0.001,
  km: 1000,
  in: 0.0254,
  '"': 0.0254,
  ft: 0.3048,
  "'": 0.3048,
};

/** A number string written with "." as decimal separator, in the UI's notation. */
export function localNum(s: string): string {
  return locale().startsWith('en') ? s : s.replace('.', ',');
}

export const settings = {
  unit: 'm' as LengthUnit,
  precision: 3,
};

export function formatLength(metres: number, unit: LengthUnit = settings.unit): string {
  const v = metres / FACTOR[unit];
  const dec = unit === 'mm' ? Math.max(0, settings.precision - 3) : unit === 'cm' ? Math.max(1, settings.precision - 2) : settings.precision;
  let s = v.toFixed(dec);
  if (s.includes('.')) s = s.replace(/0+$/, '').replace(/\.$/, '');
  return `${localNum(s)} ${unit}`;
}

export function formatArea(m2: number): string {
  let s = m2.toFixed(3);
  s = s.replace(/0+$/, '').replace(/\.$/, '');
  return `${localNum(s)} m²`;
}

export function formatAngle(deg: number): string {
  return `${localNum((Math.round(deg * 100) / 100).toString())}°`;
}

/** Parse one length: "2.5", "2,5", "250cm", "2500 mm", "-30cm". Metres. */
export function parseLength(text: string, unit: LengthUnit = settings.unit): number | null {
  const t = text.trim().replace(',', '.').toLowerCase();
  const m = /^([-+]?\d*\.?\d+(?:e[-+]?\d+)?)\s*(mm|cm|km|m|in|ft|"|')?$/.exec(t);
  if (!m) return null;
  const v = Number(m[1]);
  if (!Number.isFinite(v)) return null;
  return v * FACTOR[m[2] ?? unit];
}

/** Split a VCB entry into values: ";" always separates; "," separates when
 * ``count`` > 1 values are expected (then "2,5" is two values, like IngeTrazo's
 * `200,100`); otherwise "," is a decimal comma. */
export function splitValues(text: string, count: number): string[] {
  if (text.includes(';')) return text.split(';').map((s) => s.trim());
  if (count > 1 && text.includes(',')) return text.split(',').map((s) => s.trim());
  return [text.trim()];
}

export function parseAngle(text: string): number | null {
  const t = text.trim().replace(',', '.').replace('°', '');
  const slope = /^([-+]?\d*\.?\d+)\s*:\s*(\d*\.?\d+)$/.exec(t);
  if (slope) return (Math.atan2(Number(slope[1]), Number(slope[2])) * 180) / Math.PI;
  const v = Number(t);
  return Number.isFinite(v) && t !== '' ? v : null;
}
