// SPDX-License-Identifier: GPL-3.0-or-later
// IngeTrazo Web — the document: a root mesh plus a tree of groups and
// component instances (component copies share one Mesh).
import { Matrix4, Vector3 } from 'three';
import { t } from '../i18n';
import { Mesh } from './mesh';

let groupCounter = 1;

export class Group {
  mesh: Mesh;
  /** Placement in the parent's frame (identity for a classic group). */
  matrix = new Matrix4();
  children: Group[] = [];
  parent: Group | null = null;
  name: string;
  uid = crypto.randomUUID ? crypto.randomUUID() : String(Math.random()).slice(2);
  component = false;
  hidden = false;
  locked = false;
  material: { color?: [number, number, number]; [k: string]: unknown } | null = null;
  /** Keys this build does not edit (layer, ifc, billboard, axes…), kept
   * verbatim so a round trip through the web app loses nothing. */
  extra: Record<string, unknown> = {};

  constructor(mesh?: Mesh, name?: string) {
    this.mesh = mesh ?? new Mesh();
    this.name = name ?? t('Group {n}', { n: groupCounter++ });
  }

  worldMatrix(): Matrix4 {
    const m = this.matrix.clone();
    let p = this.parent;
    while (p) {
      m.premultiply(p.matrix);
      p = p.parent;
    }
    return m;
  }

  adopt(kids: Iterable<Group>): void {
    for (const k of kids) {
      k.parent = this;
      this.children.push(k);
    }
  }
}

export function reserveGroupName(name: string): void {
  const m = /(\d+)$/.exec(name);
  if (m) groupCounter = Math.max(groupCounter, Number(m[1]) + 1);
}

export type MaterialDef = {
  name: string;
  color?: [number, number, number];
  texture?: Record<string, unknown>;
  opacity?: number;
  [k: string]: unknown;
};

export type TextureImage = { member: string; name: string; bytes: Uint8Array; url: string; mime: string };

export class Model {
  root = new Mesh();
  groups: Group[] = [];
  /** Component definitions kept with no copy placed. */
  kept: Group[] = [];
  materials = new Map<string, MaterialDef>();
  /** Embedded images by member path (``textures/<hash>-<name>``). */
  textures = new Map<string, TextureImage>();
  /** Scene keys this build keeps but does not edit. */
  extra: Record<string, unknown> = {};
  name = t('Untitled');
  /** Bumped when the group tree changes (add/remove/reparent/matrix). */
  structure = 0;

  touch(): void {
    this.structure++;
  }

  *allGroups(): Generator<Group> {
    const stack = [...this.groups];
    while (stack.length) {
      const g = stack.shift()!;
      yield g;
      stack.push(...g.children);
    }
  }

  childrenOf(parent: Group | null): Group[] {
    return parent ? parent.children : this.groups;
  }

  bounds(): { min: Vector3; max: Vector3 } | null {
    const min = new Vector3(Infinity, Infinity, Infinity);
    const max = new Vector3(-Infinity, -Infinity, -Infinity);
    let any = false;
    const eat = (mesh: Mesh, m: Matrix4 | null) => {
      for (const v of mesh.vertices) {
        const p = m ? v.position.clone().applyMatrix4(m) : v.position;
        min.min(p);
        max.max(p);
        any = true;
      }
    };
    eat(this.root, null);
    for (const g of this.allGroups()) if (!g.hidden) eat(g.mesh, g.worldMatrix());
    return any ? { min, max } : null;
  }

  clear(): void {
    this.root.clear();
    this.groups = [];
    this.kept = [];
    this.materials.clear();
    for (const t of this.textures.values()) URL.revokeObjectURL(t.url);
    this.textures.clear();
    this.extra = {};
    this.name = t('Untitled');
    this.touch();
  }

  /** Every group that uses ``mesh`` (component instances share one). */
  instancesOf(mesh: Mesh): Group[] {
    return [...this.allGroups()].filter((g) => g.mesh === mesh);
  }
}
