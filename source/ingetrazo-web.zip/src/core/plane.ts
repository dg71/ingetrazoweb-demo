// SPDX-License-Identifier: GPL-3.0-or-later
// IngeTrazo Web — plane helpers, 2D projection, triangulation.
import { ShapeUtils, Vector2, Vector3 } from 'three';
import type { Face } from './mesh';

export const PLANE_TOL = 2e-4;

export class Plane {
  n: Vector3;
  d: number;
  constructor(n: Vector3, d: number) {
    this.n = n.clone().normalize();
    this.d = d;
  }
  static fromPointNormal(p: Vector3, n: Vector3): Plane {
    const nn = n.clone().normalize();
    return new Plane(nn, nn.dot(p));
  }
  static ofFace(f: Face): Plane {
    return Plane.fromPointNormal(f.loop[0].position, f.normal());
  }
  dist(p: Vector3): number {
    return this.n.dot(p) - this.d;
  }
  contains(p: Vector3, tol = PLANE_TOL): boolean {
    return Math.abs(this.dist(p)) <= tol;
  }
  /** The same plane with a canonical normal sign (for de-duplication). */
  canonical(): Plane {
    const { x, y, z } = this.n;
    const big = Math.abs(x) > 1e-6 ? x : Math.abs(y) > 1e-6 ? y : z;
    return big < 0 ? new Plane(this.n.clone().negate(), -this.d) : this;
  }
  key(): string {
    const c = this.canonical();
    const r = (v: number) => Math.round(v * 1e4);
    return `${r(c.n.x)},${r(c.n.y)},${r(c.n.z)},${r(c.d)}`;
  }
  /** Intersection with a ray; null when parallel or behind. */
  intersectRay(origin: Vector3, dir: Vector3): Vector3 | null {
    const den = this.n.dot(dir);
    if (Math.abs(den) < 1e-12) return null;
    const t = (this.d - this.n.dot(origin)) / den;
    if (t < 0) return null;
    return origin.clone().addScaledVector(dir, t);
  }
}

/** Two orthonormal in-plane axes (u = world X projected, or Y). */
export function planeAxes(n: Vector3): [Vector3, Vector3] {
  const nn = n.clone().normalize();
  let ref = new Vector3(1, 0, 0);
  let u = ref.clone().addScaledVector(nn, -ref.dot(nn));
  if (u.length() < 0.1) {
    ref = new Vector3(0, 1, 0);
    u = ref.clone().addScaledVector(nn, -ref.dot(nn));
  }
  u.normalize();
  const v = new Vector3().crossVectors(nn, u).normalize();
  return [u, v];
}

export function project2(p: Vector3, u: Vector3, v: Vector3): Vector2 {
  return new Vector2(p.dot(u), p.dot(v));
}

export function signedArea2(pts: Vector2[]): number {
  let a = 0;
  for (let i = 0, n = pts.length; i < n; i++) {
    const p = pts[i];
    const q = pts[(i + 1) % n];
    a += p.x * q.y - q.x * p.y;
  }
  return a / 2;
}

/** Strict-ish point in polygon (even-odd). */
export function pointInPoly(p: Vector2, poly: Vector2[]): boolean {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const a = poly[i];
    const b = poly[j];
    if (a.y > p.y !== b.y > p.y) {
      const x = ((b.x - a.x) * (p.y - a.y)) / (b.y - a.y) + a.x;
      if (p.x < x) inside = !inside;
    }
  }
  return inside;
}

export function onPolyBoundary(p: Vector2, poly: Vector2[], tol = 1e-6): boolean {
  for (let i = 0, n = poly.length; i < n; i++) {
    if (distToSeg2(p, poly[i], poly[(i + 1) % n]) <= tol) return true;
  }
  return false;
}

export function distToSeg2(p: Vector2, a: Vector2, b: Vector2): number {
  const abx = b.x - a.x;
  const aby = b.y - a.y;
  const len2 = abx * abx + aby * aby;
  let t = len2 > 0 ? ((p.x - a.x) * abx + (p.y - a.y) * aby) / len2 : 0;
  t = Math.max(0, Math.min(1, t));
  const dx = a.x + t * abx - p.x;
  const dy = a.y + t * aby - p.y;
  return Math.sqrt(dx * dx + dy * dy);
}

/** Point in a polygon with holes (strictly inside the outer, outside holes). */
export function pointInRegion(p: Vector2, outer: Vector2[], holes: Vector2[][]): boolean {
  if (!pointInPoly(p, outer)) return false;
  for (const h of holes) if (pointInPoly(p, h)) return false;
  return true;
}

/** Triangulate a 2D polygon with holes; returns index triples into
 * the concatenation [outer, ...holes]. */
export function triangulate2(outer: Vector2[], holes: Vector2[][]): number[][] {
  if (outer.length < 3) return [];
  if (outer.length === 3 && !holes.length) return [[0, 1, 2]];
  try {
    return ShapeUtils.triangulateShape(outer, holes);
  } catch {
    return [];
  }
}

/** A point strictly inside a polygon with holes (centroid of the largest
 * triangle of its triangulation). */
export function interiorPoint(outer: Vector2[], holes: Vector2[][]): Vector2 | null {
  const all = [...outer, ...holes.flat()];
  const tris = triangulate2(outer, holes);
  let best: Vector2 | null = null;
  let bestA = 0;
  for (const [i, j, k] of tris) {
    const a = all[i];
    const b = all[j];
    const c = all[k];
    const area = Math.abs((b.x - a.x) * (c.y - a.y) - (c.x - a.x) * (b.y - a.y));
    if (area > bestA) {
      bestA = area;
      best = new Vector2((a.x + b.x + c.x) / 3, (a.y + b.y + c.y) / 3);
    }
  }
  return best;
}

/** Points strictly inside a polygon with holes, best first: the centroids
 * of its triangles by size, each nudged toward one corner so that none
 * falls exactly on a line through the polygon (such as a dissolved seam). */
export function interiorPoints(outer: Vector2[], holes: Vector2[][], max = 8): Vector2[] {
  const all = [...outer, ...holes.flat()];
  const tris = triangulate2(outer, holes)
    .map(([i, j, k]) => {
      const a = all[i];
      const b = all[j];
      const c = all[k];
      return { a, b, c, area: Math.abs((b.x - a.x) * (c.y - a.y) - (c.x - a.x) * (b.y - a.y)) };
    })
    .filter((t) => t.area > 1e-14)
    .sort((x, y) => y.area - x.area)
    .slice(0, max);
  const out: Vector2[] = [];
  for (const { a, b, c } of tris) {
    out.push(new Vector2((a.x + b.x + c.x) / 3, (a.y + b.y + c.y) / 3));
    // Off-centre too (weights 0.6/0.25/0.15): not on any median.
    out.push(new Vector2(0.6 * a.x + 0.25 * b.x + 0.15 * c.x, 0.6 * a.y + 0.25 * b.y + 0.15 * c.y));
  }
  return out;
}

/** Inside or on the boundary (within ``tol``) of a polygon with holes. */
export function pointInRegionLoose(p: Vector2, outer: Vector2[], holes: Vector2[][], tol = 1e-6): boolean {
  if (onPolyBoundary(p, outer, tol)) return true;
  for (const h of holes) if (onPolyBoundary(p, h, tol)) return true;
  return pointInRegion(p, outer, holes);
}

/** Triangulate a face in 3D. ``tris`` indexes ``verts`` (outer then holes). */
export function triangulateFace(f: Face): { verts: Vector3[]; tris: number[] } {
  return triangulatePolygon(
    f.loop.map((x) => x.position),
    f.holes.map((h) => h.map((x) => x.position)),
    f.normal(),
  );
}

export function newellNormal(pts: Vector3[]): Vector3 {
  const n = new Vector3();
  for (let i = 0; i < pts.length; i++) {
    const c = pts[i];
    const d = pts[(i + 1) % pts.length];
    n.x += (c.y - d.y) * (c.z + d.z);
    n.y += (c.z - d.z) * (c.x + d.x);
    n.z += (c.x - d.x) * (c.y + d.y);
  }
  return n.lengthSq() > 0 ? n.normalize() : new Vector3(0, 0, 1);
}

export function triangulatePolygon(
  outer: Vector3[],
  holes: Vector3[][] = [],
  normal?: Vector3,
): { verts: Vector3[]; tris: number[] } {
  const n = normal ?? newellNormal(outer);
  const [u, v] = planeAxes(n);
  const o2 = outer.map((p) => project2(p, u, v));
  const h2 = holes.map((h) => h.map((p) => project2(p, u, v)));
  const verts = [...outer, ...holes.flat()];
  const tris = triangulate2(o2, h2).flat();
  // ShapeUtils may flip winding — make triangles follow the face normal.
  for (let i = 0; i < tris.length; i += 3) {
    const a = verts[tris[i]];
    const b = verts[tris[i + 1]];
    const c = verts[tris[i + 2]];
    const tn = new Vector3().crossVectors(b.clone().sub(a), c.clone().sub(a));
    if (tn.dot(n) < 0) {
      const t = tris[i + 1];
      tris[i + 1] = tris[i + 2];
      tris[i + 2] = t;
    }
  }
  return { verts, tris };
}

/** .skp texture projection basis for a face normal (see IngeTrazo
 * core/texture.py:projection_basis). */
export function projectionBasis(n: Vector3): [Vector3, Vector3] {
  const nn = n.clone().normalize();
  let xx = -nn.y;
  let xy = nn.x;
  const lx = Math.sqrt(xx * xx + xy * xy);
  if (lx < 1e-3) {
    return nn.z > 0
      ? [new Vector3(1, 0, 0), new Vector3(0, 1, 0)]
      : [new Vector3(-1, 0, 0), new Vector3(0, 1, 0)];
  }
  xx /= lx;
  xy /= lx;
  return [new Vector3(xx, xy, 0), new Vector3(-nn.z * xy, nn.z * xx, nn.x * xy - nn.y * xx)];
}

/** Closest points between segment p0-p1 and q0-q1: params s,t in [0,1]. */
export function closestSegSeg(p0: Vector3, p1: Vector3, q0: Vector3, q1: Vector3) {
  const d1 = p1.clone().sub(p0);
  const d2 = q1.clone().sub(q0);
  const r = p0.clone().sub(q0);
  const a = d1.dot(d1);
  const e = d2.dot(d2);
  const f = d2.dot(r);
  let s: number;
  let t: number;
  if (a <= 1e-18 && e <= 1e-18) return { s: 0, t: 0, dist: r.length() };
  if (a <= 1e-18) {
    s = 0;
    t = clamp01(f / e);
  } else {
    const c = d1.dot(r);
    if (e <= 1e-18) {
      t = 0;
      s = clamp01(-c / a);
    } else {
      const b = d1.dot(d2);
      const den = a * e - b * b;
      s = den !== 0 ? clamp01((b * f - c * e) / den) : 0;
      t = (b * s + f) / e;
      if (t < 0) {
        t = 0;
        s = clamp01(-c / a);
      } else if (t > 1) {
        t = 1;
        s = clamp01((b - c) / a);
      }
    }
  }
  const cp = p0.clone().addScaledVector(d1, s);
  const cq = q0.clone().addScaledVector(d2, t);
  return { s, t, dist: cp.distanceTo(cq), point: cp };
}

export function clamp01(x: number): number {
  return x < 0 ? 0 : x > 1 ? 1 : x;
}

/** Parameter of the projection of p on segment a-b and the distance. */
export function pointSeg(p: Vector3, a: Vector3, b: Vector3): { t: number; dist: number } {
  const ab = b.clone().sub(a);
  const len2 = ab.lengthSq();
  const t = len2 > 0 ? p.clone().sub(a).dot(ab) / len2 : 0;
  const tc = clamp01(t);
  return { t, dist: a.clone().addScaledVector(ab, tc).distanceTo(p) };
}
