// SPDX-License-Identifier: GPL-3.0-or-later
// IngeTrazo Web — geometry operations: draw (with auto faces), erase,
// push/pull, move/copy. Behaviour modelled on IngeTrazo's tools/ and core/.
import { Matrix4, Vector3 } from 'three';
import { t } from '../i18n';
import { rebuildPlane, facesInPlane } from './arrangement';
import { Edge, Face, type FaceAttrs, Mesh, PAINT_KEYS, Vertex, nextCurveId } from './mesh';
import { Plane, closestSegSeg, pointSeg } from './plane';

const TOL = 1e-4;

export type DrawOptions = {
  /** Plane the drawing lies in (rectangle, circle): always tried for faces. */
  plane?: Plane;
  /** Preferred direction for the normal of new faces. */
  orientHint?: Vector3;
  soft?: boolean;
  /** Tag the segments as one curve (circle/arc). */
  curve?: boolean;
  layer?: string | null;
};

export type DrawResult = { edges: Set<Edge>; faces: Face[] };

/**
 * Insert line segments: split at existing vertices / crossing edges, weld,
 * then close every new loop into a face (and subdivide faces drawn on).
 */
export function drawSegments(mesh: Mesh, segs: [Vector3, Vector3][], opts: DrawOptions = {}): DrawResult {
  const created = new Set<Edge>();
  const curve = opts.curve ? nextCurveId() : null;
  for (const [a, b] of segs) {
    if (a.distanceTo(b) < TOL) continue;
    for (const e of insertSegment(mesh, a, b)) {
      if (opts.soft) e.soft = true;
      if (curve !== null) e.curve = curve;
      if (opts.layer) e.layer = opts.layer;
      created.add(e);
    }
  }
  const faces = closeFaces(mesh, created, opts);
  return { edges: created, faces };
}

/** Add one segment, splitting it and the edges it meets. */
export function insertSegment(mesh: Mesh, a: Vector3, b: Vector3): Edge[] {
  const ab = b.clone().sub(a);
  const len = ab.length();
  const ts: number[] = [0, 1];
  const splits: [Edge, Vector3][] = [];
  for (const e of mesh.edges) {
    // Endpoints of the new segment landing inside an existing edge.
    for (const p of [a, b]) {
      const ps = pointSeg(p, e.a, e.b);
      if (ps.dist < TOL && ps.t > 1e-9 && ps.t < 1 - 1e-9 && p.distanceTo(e.a) > TOL && p.distanceTo(e.b) > TOL)
        splits.push([e, p.clone()]);
    }
    // Existing vertices on the new segment.
    for (const v of [e.v0, e.v1]) {
      const ps = pointSeg(v.position, a, b);
      if (ps.dist < TOL && ps.t * len > TOL && (1 - ps.t) * len > TOL) ts.push(ps.t);
    }
    // Proper crossings.
    const c = closestSegSeg(a, b, e.a, e.b);
    if (c.dist < TOL && c.point) {
      const sIn = c.s * len > TOL && (1 - c.s) * len > TOL;
      const elen = e.length();
      const tIn = c.t * elen > TOL && (1 - c.t) * elen > TOL;
      if (sIn && tIn && !parallel(ab, e.b.clone().sub(e.a))) {
        ts.push(c.s);
        splits.push([e, c.point.clone()]);
      }
    }
  }
  for (const [e, p] of splits) {
    if (!mesh.edges.has(e)) {
      // Already split: find the piece that holds p.
      const piece = findEdgeThrough(mesh, p);
      if (piece) mesh.splitEdge(piece, p);
      continue;
    }
    mesh.splitEdge(e, p);
  }
  ts.sort((x, y) => x - y);
  const pts: Vector3[] = [];
  for (const t of ts) {
    const p = a.clone().addScaledVector(ab, t);
    if (!pts.length || pts[pts.length - 1].distanceTo(p) > TOL) pts.push(p);
  }
  const out: Edge[] = [];
  for (let i = 0; i + 1 < pts.length; i++) {
    const v0 = mesh.vertex(pts[i]);
    const v1 = mesh.vertex(pts[i + 1]);
    if (v0 === v1) continue;
    out.push(mesh.linkEdge(v0, v1));
  }
  return out;
}

function findEdgeThrough(mesh: Mesh, p: Vector3): Edge | undefined {
  for (const e of mesh.edges) {
    const ps = pointSeg(p, e.a, e.b);
    if (ps.dist < TOL && p.distanceTo(e.a) > TOL && p.distanceTo(e.b) > TOL) return e;
  }
  return undefined;
}

function parallel(d1: Vector3, d2: Vector3): boolean {
  return new Vector3().crossVectors(d1.clone().normalize(), d2.clone().normalize()).length() < 1e-9;
}

/** Find the planes new edges can close faces in, and rebuild each. */
export function closeFaces(mesh: Mesh, created: Set<Edge>, opts: DrawOptions = {}): Face[] {
  const planes = new Map<string, Plane>();
  const add = (p: Plane) => {
    const k = p.key();
    if (!planes.has(k)) planes.set(k, p);
  };
  if (opts.plane) add(opts.plane);
  for (const e of created) {
    if (!mesh.edges.has(e)) continue;
    const dir = e.b.clone().sub(e.a).normalize();
    for (const v of [e.v0, e.v1]) {
      for (const f of v.faces()) {
        const pl = Plane.ofFace(f);
        if (pl.contains(e.a) && pl.contains(e.b)) add(pl);
      }
      for (const g of v.edges) {
        if (g === e) continue;
        const gd = g.other(v).position.clone().sub(v.position).normalize();
        const n = new Vector3().crossVectors(dir, gd);
        if (n.length() < 1e-6) continue;
        add(Plane.fromPointNormal(v.position, n));
      }
    }
  }
  const out: Face[] = [];
  for (const pl of planes.values()) {
    const hint = orientFor(pl, opts.orientHint);
    out.push(...rebuildPlane(mesh, pl, { newEdges: created, orientHint: hint }));
  }
  return out.filter((f) => mesh.faces.has(f));
}

export type NearPlanarResult = { face: Face | null; deviation: number; cycle: number };

/**
 * A loop the user closed whose corners are not exactly in one plane (drawn
 * against slanted or separately built walls, or in free space) closes no
 * face through the exact planar arrangement. When the loop through one of
 * the new edges is *nearly* planar — off by at most ``maxDev`` or a share
 * ``rel`` of its size — close it anyway as a face over that loop.
 * Returns the deviation found, so the caller can tell the user.
 */
export function closeNearPlanar(
  mesh: Mesh,
  created: Iterable<Edge>,
  opts: { maxDev?: number; rel?: number; orientHint?: Vector3 } = {},
): NearPlanarResult {
  const maxDev = opts.maxDev ?? 0.05;
  const rel = opts.rel ?? 0.02;
  let best: NearPlanarResult = { face: null, deviation: Infinity, cycle: 0 };
  for (const e of created) {
    if (!mesh.edges.has(e)) continue;
    const loop = shortestCycle(e);
    if (!loop || loop.length < 4) continue; // triangles are always planar
    const pts = loop.map((v) => v.position);
    const n = newell(pts);
    if (n.length() < 1e-12) continue;
    n.normalize();
    const c = pts.reduce((a, p) => a.add(p), new Vector3()).divideScalar(pts.length);
    const dev = Math.max(...pts.map((p) => Math.abs(n.dot(p.clone().sub(c)))));
    let size = 0;
    for (const p of pts) size = Math.max(size, p.distanceTo(c));
    if (dev < best.deviation) best = { face: null, deviation: dev, cycle: loop.length };
    if (dev > Math.min(maxDev, rel * 2 * size)) continue;
    if (existingFaceOn(loop)) continue;
    // Orientation: horizontal-ish faces look up, others toward the hint.
    const hint = Math.abs(n.z) > 0.999 ? new Vector3(0, 0, 1) : opts.orientHint;
    const verts = hint && n.dot(hint) < 0 ? loop.slice().reverse() : loop;
    const face = mesh.addFaceVerts(verts);
    return { face, deviation: dev, cycle: loop.length };
  }
  return best;
}

function newell(pts: Vector3[]): Vector3 {
  const n = new Vector3();
  for (let i = 0; i < pts.length; i++) {
    const a = pts[i];
    const b = pts[(i + 1) % pts.length];
    n.x += (a.y - b.y) * (a.z + b.z);
    n.y += (a.z - b.z) * (a.x + b.x);
    n.z += (a.x - b.x) * (a.y + b.y);
  }
  return n;
}

/** Shortest loop of edges through ``e`` (breadth-first, up to 64 edges). */
function shortestCycle(e: Edge): Vertex[] | null {
  const start = e.v1;
  const goal = e.v0;
  const prev = new Map<Vertex, Vertex>();
  const seen = new Set<Vertex>([start]);
  let frontier = [start];
  for (let depth = 0; depth < 64 && frontier.length; depth++) {
    const next: Vertex[] = [];
    for (const v of frontier)
      for (const x of v.edges) {
        if (x === e) continue;
        const w = x.other(v);
        if (seen.has(w)) continue;
        seen.add(w);
        prev.set(w, v);
        if (w === goal) {
          const path = [goal];
          let c = goal;
          while (c !== start) {
            c = prev.get(c)!;
            path.push(c);
          }
          return path; // goal … start, closed by e
        }
        next.push(w);
      }
    frontier = next;
  }
  return null;
}

function existingFaceOn(loop: Vertex[]): boolean {
  const set = new Set(loop);
  for (const f of loop[0].faces()) if (f.loop.length === loop.length && f.loop.every((v) => set.has(v))) return true;
  return false;
}

/** Horizontal faces look up; others follow the hint (the camera). */
function orientFor(pl: Plane, hint?: Vector3): Vector3 | undefined {
  if (Math.abs(pl.n.z) > 0.999) return new Vector3(0, 0, 1);
  return hint;
}

function coplanarSame(f: Face, g: Face): boolean {
  return f.normal().dot(g.normal()) > 1 - 1e-6 && Plane.ofFace(f).contains(g.loop[0].position);
}

/**
 * Erase edges the way a modeller does: an edge between two coplanar faces
 * merges them; any other edge takes its faces with it.
 */
export function eraseEdges(mesh: Mesh, edges: Iterable<Edge>): void {
  const seams = new Map<string, { plane: Plane; edges: Set<Edge> }>();
  const touched = new Set<Vertex>();
  for (const e of edges) {
    if (!mesh.edges.has(e)) continue;
    touched.add(e.v0);
    touched.add(e.v1);
    if (e.faces.length === 2 && coplanarSame(e.faces[0], e.faces[1])) {
      const pl = Plane.ofFace(e.faces[0]);
      const k = pl.key();
      if (!seams.has(k)) seams.set(k, { plane: pl, edges: new Set() });
      seams.get(k)!.edges.add(e);
      continue;
    }
    mesh.removeEdge(e);
  }
  for (const { plane, edges: d } of seams.values()) rebuildPlane(mesh, plane, { dissolve: d });
  for (const v of touched) if (mesh.vertices.has(v)) mesh.collapseCollinear(v);
  mesh.pruneVertices(touched);
}

/** Delete faces only (their edges stay). */
export function deleteFaces(mesh: Mesh, faces: Iterable<Face>): void {
  for (const f of faces) mesh.removeFace(f);
}

/** Dissolve coplanar seams among ``candidates`` (same plane, same facing).
 * ``accept`` can veto a seam (e.g. faces painted differently); ``local``
 * rebuilds only the faces around the seams (big imports). */
export function dissolveSeams(
  mesh: Mesh,
  candidates: Iterable<Edge>,
  opts: { accept?: (f: Face, g: Face) => boolean; local?: boolean } = {},
): void {
  const seams = new Map<string, { plane: Plane; edges: Set<Edge> }>();
  for (const e of candidates) {
    if (!mesh.edges.has(e) || e.faces.length !== 2) continue;
    const [f, g] = e.faces;
    if (f.interior || g.interior || !coplanarSame(f, g)) continue;
    if (opts.accept && !opts.accept(f, g)) continue;
    const pl = Plane.ofFace(f);
    const k = pl.key();
    if (!seams.has(k)) seams.set(k, { plane: pl, edges: new Set() });
    seams.get(k)!.edges.add(e);
  }
  for (const { plane, edges } of seams.values()) rebuildPlane(mesh, plane, { dissolve: edges, local: opts.local });
}

function paintOf(attrs: FaceAttrs): FaceAttrs {
  const out: FaceAttrs = {};
  for (const k of PAINT_KEYS) if (attrs[k] !== undefined) (out as Record<string, unknown>)[k] = structuredClone(attrs[k]);
  if (attrs.layer) out.layer = attrs.layer;
  return out;
}

export type PushResult = { ok: boolean; message?: string; cap?: Face };

/**
 * Push/Pull ``face`` by ``dist`` along its normal.
 *
 * * Stretch: a face whose every neighbour contains the push direction (a
 *   box top) just slides — the walls stretch with it.
 * * Free face: the base stays (turned to face outward) and a box grows.
 * * Bordered face: the base is consumed — pulling out grows the solid,
 *   pushing in carves a recess; coplanar seams merge afterwards.
 * * ``copy`` (Ctrl): the base stays where it is, a new segment stacks on it.
 */
export function pushPull(mesh: Mesh, face: Face, dist: number, copy = false): PushResult {
  if (!mesh.faces.has(face) || Math.abs(dist) < TOL) return { ok: false };
  const n = face.normal();
  const dv = n.clone().multiplyScalar(dist);
  if (!copy) {
    const st = canStretch(mesh, face, n, dist);
    if (st === 'collapse') return { ok: false, message: t('Push/Pull would collapse the geometry.') };
    if (st === 'yes') {
      mesh.translate(face.vertexSet(), dv);
      return { ok: true, cap: face };
    }
  }
  const loops = [face.loop.slice(), ...face.holes.map((h) => h.slice())];
  const pos = loops.map((lp) => lp.map((v) => v.position.clone()));
  const paint = paintOf(face.attrs);
  const bordered = mesh.faceEdges(face).some((e) => e.faces.length > 1);
  const baseEdges = mesh.faceEdges(face);
  // Edge flags per loop side, so the cap repeats them and the walls of a
  // curve read smooth (soft verticals between segments of one curve).
  const sideFlags = loops.map((lp) =>
    lp.map((v, i) => {
      const e = mesh.findEdge(v, lp[(i + 1) % lp.length]);
      return { curve: e?.curve ?? null, soft: e?.soft ?? false, layer: e?.layer ?? null };
    }),
  );

  if (copy) {
    if (bordered) face.interior = true;
  } else if (!bordered) {
    if (dist > 0) mesh.reverseFace(face);
  } else {
    mesh.removeFace(face);
  }

  const capLoops = pos.map((lp) => lp.map((p) => p.clone().add(dv)));
  let cap = mesh.addFace(capLoops[0], capLoops.slice(1));
  if (!bordered && dist < 0 && !copy) {
    mesh.reverseFace(cap);
  }
  cap.attrs = structuredClone(face.attrs);
  const inward = bordered && !copy && dist < 0;
  const verticals: Edge[] = [];
  pos.forEach((lp, li) => {
    const m = lp.length;
    const flags = sideFlags[li];
    for (let i = 0; i < m; i++) {
      const ce = mesh.findEdge(mesh.vertex(capLoops[li][i]), mesh.vertex(capLoops[li][(i + 1) % m]));
      if (ce) {
        ce.curve = flags[i].curve;
        ce.soft = flags[i].soft;
        ce.layer = flags[i].layer;
      }
    }
    for (let i = 0; i < m; i++) {
      const a = lp[i];
      const b = lp[(i + 1) % m];
      const a2 = a.clone().add(dv);
      const b2 = b.clone().add(dv);
      // Walls face out of the region when material grows (and for a free
      // face either way); a recess carved into a solid faces them inward.
      const quad = inward ? [a, b, b2, a2] : dist > 0 ? [a, b, b2, a2] : [a, a2, b2, b];
      const w = mesh.addFace(quad);
      w.attrs = structuredClone(paint);
      const ve = mesh.findEdge(mesh.vertex(a), mesh.vertex(a2));
      if (ve) {
        const prev = flags[(i - 1 + m) % m];
        if (prev.curve !== null && prev.curve === flags[i].curve) ve.soft = true;
        else verticals.push(ve);
      }
    }
  });
  dissolveSeams(mesh, [...baseEdges, ...verticals]);
  const capVerts = new Set<Vertex>();
  for (const lp of capLoops) for (const p of lp) {
    const v = mesh.vertexAt(p);
    if (v) capVerts.add(v);
  }
  for (const lp of pos) for (const p of lp) {
    const v = mesh.vertexAt(p);
    if (v) mesh.collapseCollinear(v);
  }
  // The cap may have been merged away: find what now lies there.
  if (!mesh.faces.has(cap)) {
    const pl = Plane.fromPointNormal(capLoops[0][0], n);
    const found = [...facesInPlane(mesh, pl)].find((f) => [...capVerts].every((v) => f.vertexSet().has(v)));
    if (found) cap = found;
  }
  return { ok: true, cap };
}

/** Can ``face`` slide along ``n`` dragging its neighbours (box top)? */
function canStretch(mesh: Mesh, face: Face, n: Vector3, dist: number): 'yes' | 'no' | 'collapse' {
  const verts = face.vertexSet();
  const neighbours = new Set<Face>();
  for (const e of mesh.faceEdges(face)) {
    const others = e.faces.filter((f) => f !== face);
    if (!others.length) return 'no';
    for (const f of others) neighbours.add(f);
  }
  for (const v of verts) for (const f of v.faces()) if (f !== face) neighbours.add(f);
  const p0 = face.loop[0].position;
  let lo = -Infinity;
  let hi = Infinity;
  for (const f of neighbours) {
    if (Math.abs(f.normal().dot(n)) > 1e-6) return 'no';
    let below = false;
    let above = false;
    let maxBelow = -Infinity;
    let minAbove = Infinity;
    for (const lp of f.loops())
      for (const v of lp) {
        if (verts.has(v)) continue;
        const s = n.dot(v.position.clone().sub(p0));
        if (s < -TOL) {
          below = true;
          maxBelow = Math.max(maxBelow, s);
        } else if (s > TOL) {
          above = true;
          minAbove = Math.min(minAbove, s);
        } else return 'no';
      }
    if (below && above) return 'no';
    if (below) lo = Math.max(lo, maxBelow);
    if (above) hi = Math.min(hi, minAbove);
  }
  if (dist <= lo + TOL || dist >= hi - TOL) return 'collapse';
  return 'yes';
}

/** Vertices used by a selection of faces and edges. */
export function verticesOf(faces: Iterable<Face>, edges: Iterable<Edge>): Set<Vertex> {
  const out = new Set<Vertex>();
  for (const f of faces) for (const v of f.vertexSet()) out.add(v);
  for (const e of edges) {
    out.add(e.v0);
    out.add(e.v1);
  }
  return out;
}

/** Copy faces and loose edges by a transform; returns the new entities. */
export function copyGeometry(
  src: Mesh,
  dst: Mesh,
  faces: Iterable<Face>,
  edges: Iterable<Edge>,
  m: Matrix4,
): { faces: Face[]; edges: Edge[] } {
  const outF: Face[] = [];
  const outE: Edge[] = [];
  const tp = (v: Vertex) => v.position.clone().applyMatrix4(m);
  const flip = m.determinant() < 0;
  for (const f of faces) {
    let loop = f.loop.map(tp);
    let holes = f.holes.map((h) => h.map(tp));
    if (flip) {
      loop = loop.reverse();
      holes = holes.map((h) => h.reverse());
    }
    if (loop.length < 3) continue;
    const g = dst.addFace(loop, holes);
    g.attrs = structuredClone(f.attrs);
    g.interior = f.interior;
    outF.push(g);
    for (const [a, b] of f.sides()) {
      const se = src.findEdge(a, b);
      const de = dst.findEdge(dst.vertex(tp(a)), dst.vertex(tp(b)));
      if (se && de) copyFlags(se, de);
    }
  }
  for (const e of edges) {
    const pa = tp(e.v0);
    const pb = tp(e.v1);
    if (pa.distanceTo(pb) < TOL) continue;
    const de = dst.addEdge(pa, pb);
    copyFlags(e, de);
    outE.push(de);
  }
  return { faces: outF, edges: outE };
}

function copyFlags(from: Edge, to: Edge): void {
  to.soft = from.soft;
  to.hidden = from.hidden;
  to.curve = from.curve;
  to.layer = from.layer;
}

/** The selection closure: faces plus the edges bounding them plus loose edges. */
export function closure(mesh: Mesh, faces: Iterable<Face>, edges: Iterable<Edge>): { faces: Set<Face>; edges: Set<Edge> } {
  const fs = new Set<Face>([...faces].filter((f) => mesh.faces.has(f)));
  const es = new Set<Edge>([...edges].filter((e) => mesh.edges.has(e)));
  for (const f of fs) for (const e of mesh.faceEdges(f)) es.add(e);
  return { faces: fs, edges: es };
}

/** Remove selected geometry from ``mesh`` (after it was copied elsewhere):
 * faces go, edges go unless they still bound a remaining face. */
export function extract(mesh: Mesh, faces: Set<Face>, edges: Set<Edge>): void {
  for (const f of faces) mesh.removeFace(f);
  const touched = new Set<Vertex>();
  for (const e of edges) {
    if (!mesh.edges.has(e) || e.faces.length) continue;
    touched.add(e.v0);
    touched.add(e.v1);
    mesh.removeEdge(e);
  }
  mesh.pruneVertices(touched);
}

/** Points of a regular polygon (circle) in a plane. */
export function circlePoints(center: Vector3, normal: Vector3, radiusPoint: Vector3, segments: number): Vector3[] {
  const n = normal.clone().normalize();
  const r = radiusPoint.clone().sub(center);
  r.addScaledVector(n, -r.dot(n));
  const rad = r.length();
  if (rad < TOL) return [];
  const u = r.clone().normalize();
  const v = new Vector3().crossVectors(n, u);
  const out: Vector3[] = [];
  for (let i = 0; i < segments; i++) {
    const t = (i / segments) * Math.PI * 2;
    out.push(center.clone().addScaledVector(u, Math.cos(t) * rad).addScaledVector(v, Math.sin(t) * rad));
  }
  return out;
}

export function loopSegments(pts: Vector3[]): [Vector3, Vector3][] {
  return pts.map((p, i) => [p, pts[(i + 1) % pts.length]] as [Vector3, Vector3]);
}
