// SPDX-License-Identifier: GPL-3.0-or-later
// IngeTrazo Web — undo/redo by snapshots of the meshes a command touched
// (plus the group tree when it changes shape).
import { Matrix4 } from 'three';
import type { Mesh, MeshData } from './mesh';
import type { Group, Model } from './scene';

type GroupState = {
  parent: Group | null;
  children: Group[];
  matrix: Matrix4;
  hidden: boolean;
  locked: boolean;
  name: string;
  material: Group['material'];
  extra: Group['extra'];
};
type StructState = { top: Group[]; groups: Map<Group, GroupState> };

function captureStruct(model: Model): StructState {
  const groups = new Map<Group, GroupState>();
  for (const g of model.allGroups())
    groups.set(g, {
      parent: g.parent,
      children: g.children.slice(),
      matrix: g.matrix.clone(),
      hidden: g.hidden,
      locked: g.locked,
      name: g.name,
      material: g.material ? structuredClone(g.material) : null,
      extra: structuredClone(g.extra),
    });
  return { top: model.groups.slice(), groups };
}

function restoreStruct(model: Model, s: StructState): void {
  model.groups = s.top.slice();
  for (const [g, st] of s.groups) {
    g.parent = st.parent;
    g.children = st.children.slice();
    g.matrix.copy(st.matrix);
    g.hidden = st.hidden;
    g.locked = st.locked;
    g.name = st.name;
    g.material = st.material ? structuredClone(st.material) : null;
    g.extra = structuredClone(st.extra);
  }
  model.touch();
}

type Entry = {
  label: string;
  meshes: { mesh: Mesh; before: MeshData; after: MeshData }[];
  struct?: { before: StructState; after: StructState };
};

export class Transaction {
  private before = new Map<Mesh, MeshData>();
  private structBefore?: StructState;
  done = false;
  constructor(
    private history: History,
    readonly label: string,
  ) {}

  /** Snapshot ``mesh`` before it changes (idempotent). */
  track(...meshes: Mesh[]): this {
    for (const m of meshes) if (!this.before.has(m)) this.before.set(m, m.toData());
    return this;
  }

  /** Snapshot the group tree (create/explode/move groups). */
  structure(): this {
    if (!this.structBefore) this.structBefore = captureStruct(this.history.model);
    return this;
  }

  commit(): void {
    if (this.done) return;
    this.done = true;
    const entry: Entry = {
      label: this.label,
      meshes: [...this.before].map(([mesh, before]) => ({ mesh, before, after: mesh.toData() })),
    };
    if (this.structBefore) entry.struct = { before: this.structBefore, after: captureStruct(this.history.model) };
    this.history.push(entry);
  }

  /** Put everything back as it was and record nothing. */
  rollback(): void {
    if (this.done) return;
    this.done = true;
    for (const [mesh, before] of this.before) mesh.loadData(before);
    if (this.structBefore) restoreStruct(this.history.model, this.structBefore);
  }
}

export class History {
  private undoStack: Entry[] = [];
  private redoStack: Entry[] = [];
  /** Called after any change (commit, undo, redo). */
  onChange: () => void = () => {};
  limit = 100;

  constructor(public model: Model) {}

  begin(label: string): Transaction {
    return new Transaction(this, label);
  }

  push(e: Entry): void {
    this.undoStack.push(e);
    if (this.undoStack.length > this.limit) this.undoStack.shift();
    this.redoStack = [];
    this.onChange();
  }

  get canUndo(): boolean {
    return this.undoStack.length > 0;
  }
  get canRedo(): boolean {
    return this.redoStack.length > 0;
  }
  get undoLabel(): string | undefined {
    return this.undoStack[this.undoStack.length - 1]?.label;
  }
  get redoLabel(): string | undefined {
    return this.redoStack[this.redoStack.length - 1]?.label;
  }

  undo(): boolean {
    const e = this.undoStack.pop();
    if (!e) return false;
    for (const m of e.meshes) m.mesh.loadData(m.before);
    if (e.struct) restoreStruct(this.model, e.struct.before);
    this.redoStack.push(e);
    this.onChange();
    return true;
  }

  redo(): boolean {
    const e = this.redoStack.pop();
    if (!e) return false;
    for (const m of e.meshes) m.mesh.loadData(m.after);
    if (e.struct) restoreStruct(this.model, e.struct.after);
    this.undoStack.push(e);
    this.onChange();
    return true;
  }

  clear(): void {
    this.undoStack = [];
    this.redoStack = [];
    this.onChange();
  }
}
