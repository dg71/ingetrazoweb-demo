// SPDX-License-Identifier: GPL-3.0-or-later
// IngeTrazo Web — extensions loaded at run time.
//
// An extension is one ES module whose default export is an ``Extension``.
// It is built with ``three`` and ``ingetrazo-web`` left external (bare
// imports); the loader points those imports at the app's own copies, so the
// extension shares one three.js and the modeller's classes with the app.
//
// Installed extensions are kept in the browser (localStorage): a URL, or the
// module source when it came from a file. ``?ext=<url>`` loads one for this
// visit only (handy while developing an extension).
import * as THREE from 'three';
import type { Extension } from './ext';
import { t } from './i18n';

export type Installed = { name: string; url?: string; code?: string };

const KEY = 'igw-extensions';

let host: Record<string, unknown> | null = null;

/** The modules an extension may import: ``three`` and ``ingetrazo-web``. */
export function provideHost(lib: Record<string, unknown>): void {
  host = { three: THREE, 'ingetrazo-web': lib };
}

const shims = new Map<string, string>();

function shimUrl(name: string): string {
  let url = shims.get(name);
  if (!url) {
    const mod = host?.[name] as Record<string, unknown> | undefined;
    if (!mod) throw new Error(t('Module “{name}” is not available to extensions.', { name }));
    (globalThis as Record<string, unknown>).__igwHost = host;
    const names = Object.keys(mod).filter((k) => /^[A-Za-z_$][\w$]*$/.test(k) && k !== 'default');
    const src =
      `const M = globalThis.__igwHost[${JSON.stringify(name)}];\n` +
      names.map((k) => `export const ${k} = M.${k};`).join('\n') +
      '\nexport default M;\n';
    url = URL.createObjectURL(new Blob([src], { type: 'text/javascript' }));
    shims.set(name, url);
  }
  return url;
}

/** Load one extension from its module source. */
export async function loadFromCode(code: string): Promise<Extension> {
  if (!host) throw new Error(t('This app does not load extensions.'));
  const rewritten = code.replace(/(\bfrom\s*|\bimport\s*\(?\s*)(['"])(three|ingetrazo-web)\2/g, (_m, pre: string, q: string, name: string) => `${pre}${q}${shimUrl(name)}${q}`);
  const url = URL.createObjectURL(new Blob([rewritten], { type: 'text/javascript' }));
  try {
    const mod = await import(/* @vite-ignore */ url);
    const ext = (mod.default ?? mod.extension) as Extension | undefined;
    if (!ext || typeof ext.setup !== 'function' || !ext.id) throw new Error(t('The module does not export an extension ({code}).', { code: 'export default { id, name, setup }' }));
    return ext;
  } finally {
    URL.revokeObjectURL(url);
  }
}

export async function fetchCode(url: string): Promise<string> {
  const res = await fetch(url, { cache: 'no-cache' });
  if (!res.ok) throw new Error(`${url}: HTTP ${res.status}`);
  return res.text();
}

export function installed(): Installed[] {
  try {
    return JSON.parse(localStorage.getItem(KEY) ?? '[]') as Installed[];
  } catch {
    return [];
  }
}

function store(list: Installed[]): void {
  localStorage.setItem(KEY, JSON.stringify(list));
}

/** Check that it loads, then remember it (same name replaces). */
export async function install(src: { url?: string; code?: string }): Promise<Extension> {
  const code = src.code ?? (await fetchCode(src.url!));
  const ext = await loadFromCode(code);
  const list = installed().filter((x) => x.name !== ext.name);
  list.push(src.url ? { name: ext.name, url: src.url } : { name: ext.name, code });
  store(list);
  return ext;
}

export function uninstall(name: string): void {
  store(installed().filter((x) => x.name !== name));
}

/** Everything installed plus ``?ext=`` URLs; a broken one is skipped. */
export async function loadAll(): Promise<{ extensions: Extension[]; errors: string[] }> {
  const extensions: Extension[] = [];
  const errors: string[] = [];
  const sources: Installed[] = [...installed()];
  for (const u of new URLSearchParams(location.search).getAll('ext')) sources.push({ name: u, url: u });
  for (const s of sources) {
    try {
      const ext = await loadFromCode(s.code ?? (await fetchCode(s.url!)));
      if (!extensions.some((e) => e.id === ext.id)) extensions.push(ext);
    } catch (e) {
      console.error(`Erweiterung ${s.name}`, e);
      errors.push(`${s.name}: ${(e as Error).message}`);
    }
  }
  return { extensions, errors };
}
