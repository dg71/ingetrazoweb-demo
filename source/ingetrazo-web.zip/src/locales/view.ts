// Translations for the view area (English key → German / Spanish).
import type { Dict } from '../i18n';

const de: Dict = {
  "TOP": "OBEN",
  "BOTTOM": "UNTEN",
  "FRONT": "VORNE",
  "BACK": "HINTEN",
  "RIGHT": "RECHTS",
  "LEFT": "LINKS",
  "Top view": "Ansicht oben",
  "Bottom view": "Ansicht unten",
  "Front view": "Ansicht vorne",
  "Back view": "Ansicht hinten",
  "Right view": "Ansicht rechts",
  "Left view": "Ansicht links",
  "top": "oben",
  "bottom": "unten",
  "front": "vorne",
  "back": "hinten",
  "right": "rechts",
  "left": "links",
  "Oblique view {a} {b}": "Schrägansicht {a} {b}",
  "Oblique view {a} {b} {c}": "Schrägansicht {a} {b} {c}",
  "View cube": "Orientierungswürfel",
  "Iso view": "Iso-Ansicht",
};

const es: Dict = {
  "TOP": "ARRIBA",
  "BOTTOM": "ABAJO",
  "FRONT": "FRENTE",
  "BACK": "ATRÁS",
  "RIGHT": "DER.",
  "LEFT": "IZQ.",
  "Top view": "Vista superior",
  "Bottom view": "Vista inferior",
  "Front view": "Vista frontal",
  "Back view": "Vista posterior",
  "Right view": "Vista derecha",
  "Left view": "Vista izquierda",
  "top": "arriba",
  "bottom": "abajo",
  "front": "frente",
  "back": "atrás",
  "right": "derecha",
  "left": "izquierda",
  "Oblique view {a} {b}": "Vista oblicua {a}-{b}",
  "Oblique view {a} {b} {c}": "Vista oblicua {a}-{b}-{c}",
  "View cube": "Cubo de orientación",
  "Iso view": "Vista isométrica",
};

export default { de, es };
