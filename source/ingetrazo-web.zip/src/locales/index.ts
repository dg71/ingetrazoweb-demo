import type { Dict } from '../i18n';
import start from './start';
import tools from './tools';
import ui from './ui';
import view from './view';

const LOCALES: { de: Dict; es: Dict }[] = [start, ui, view, tools];
export default LOCALES;
