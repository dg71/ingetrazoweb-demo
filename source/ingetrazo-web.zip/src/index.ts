// SPDX-License-Identifier: GPL-3.0-or-later
// IngeTrazo Web as a library: the shell plus the building blocks an
// extension needs (geometry, document, tools, units, UI helpers).
export { startApp, type StartOptions } from './start';
export type { Extension, ExtensionApi, PanelSpec, SnapPoint } from './ext';
export { App } from './app';
export { Mesh, Face, Edge, Vertex, type FaceAttrs } from './core/mesh';
export { Group, Model } from './core/scene';
export { Plane } from './core/plane';
export * as ops from './core/ops';
export * as units from './core/units';
export { Tool, type PointerInfo } from './tools/base';
export { showSnap, planeBasis } from './tools/draw';
export { cloneGroup } from './tools/modify';
export { dialog, type Action } from './ui/ui';
export { loadIgz, saveIgz } from './io/igz';
export { interiorPoints, pointInRegion } from './core/plane';
export { combine as combineSolids, CsgError, type Part } from './core/csg';
export { isHole } from './app';
export { t, lang, locale, addTranslations, LANGS, type Lang } from './i18n';
