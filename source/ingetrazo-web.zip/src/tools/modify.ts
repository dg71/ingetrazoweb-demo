// SPDX-License-Identifier: GPL-3.0-or-later
// IngeTrazo Web — modifying tools: Push/Pull, Move, Rotate, Eraser, Paint,
// Tape Measure, Orbit, Pan.
import { Matrix4, Vector2, Vector3 } from 'three';
import { t } from '../i18n';
import { type Edge, type Face, Mesh } from '../core/mesh';
import { closure, copyGeometry, eraseEdges, pushPull, verticesOf } from '../core/ops';
import { Plane } from '../core/plane';
import { Group } from '../core/scene';
import { formatAngle, formatLength, parseAngle, parseLength } from '../core/units';
import { type PointerInfo, Tool } from './base';
import { planeBasis, showSnap } from './draw';
import { AXES, type Snap } from './inference';

// ---------------------------------------------------------------------------
export class PushPullTool extends Tool {
  readonly id = 'pushpull';
  readonly name = t('Push/Pull');
  readonly shortcut = 'p';
  vcbLabel = t('Distance');
  private face: Face | null = null;
  private normal = new Vector3();
  private start = new Vector3();
  private dist = 0;
  private hoverFace: Face | null = null;
  private copy = false;
  private lastDist: number | null = null;

  hint(): string {
    return this.face
      ? `${t('Drag and click, or type a distance.')} ${this.copy ? t('Copy mode (Ctrl).') : t('Ctrl = copy (stack a storey).')}`
      : t('Click a face to pull it out or push it in. Double-click repeats the last distance.');
  }

  private loopsWorld(f: Face): Vector3[][] {
    const w = this.app.vp.contextWorld();
    return [...f.loops()].map((lp) => lp.map((v) => v.position.clone().applyMatrix4(w)));
  }

  move(p: PointerInfo): void {
    super.move(p);
    const app = this.app;
    const vp = app.vp;
    if (!this.face) {
      const hit = vp.pick(p.x, p.y);
      this.hoverFace = hit?.face ?? null;
      if (this.hoverFace) {
        const loops = this.loopsWorld(this.hoverFace);
        vp.setPreview(
          loops.flatMap((lp) => lp.map((a, i) => ({ a, b: lp[(i + 1) % lp.length], color: '#1f6feb', width: 2 }))),
          [{ pts: loops[0], opacity: 0.18 }],
        );
      } else vp.setPreview([]);
      vp.setMarker(null);
      vp.setTip(null);
      return;
    }
    const s = app.inference.find(p.x, p.y, { ref: this.start, lock: this.normal, guides: app.guides });
    this.dist = s.point.clone().sub(this.start).dot(this.normal);
    showSnap(app, s, p);
    if (s.kind === 'axis') vp.setTip(null);
    this.preview();
  }

  private preview(): void {
    const vp = this.app.vp;
    const loops = this.loopsWorld(this.face!);
    const dv = this.normal.clone().multiplyScalar(this.dist);
    const lines = [];
    for (const lp of loops) {
      for (let i = 0; i < lp.length; i++) {
        const a = lp[i];
        const b = lp[(i + 1) % lp.length];
        lines.push({ a: a.clone().add(dv), b: b.clone().add(dv), color: '#1f6feb', width: 2 });
        lines.push({ a, b: a.clone().add(dv), color: '#1f6feb', width: 1 });
      }
    }
    vp.setPreview(lines, [{ pts: loops[0].map((q) => q.clone().add(dv)), opacity: 0.22 }]);
    this.app.showValue(formatLength(this.dist));
  }

  down(p: PointerInfo): void {
    if (p.button !== 0) return;
    const vp = this.app.vp;
    if (!this.face) {
      const hit = vp.pick(p.x, p.y);
      if (!hit?.face || !hit.normal) return;
      this.face = hit.face;
      this.normal = hit.normal.clone().normalize();
      this.start = hit.point.clone();
      this.dist = 0;
      this.app.setHint();
      return;
    }
    this.commit(this.dist);
  }

  private commit(worldDist: number, face = this.face, normal = this.normal): void {
    const app = this.app;
    if (!face || Math.abs(worldDist) < 1e-5) {
      this.reset();
      return;
    }
    const lv = app.toLocalDir(normal.clone().multiplyScalar(worldDist));
    const local = lv.length() * Math.sign(lv.dot(face.normal()) || 1);
    const tx = app.history.begin(t('Push/Pull')).track(app.mesh);
    const r = pushPull(app.mesh, face, local, this.copy);
    if (!r.ok) {
      tx.rollback();
      if (r.message) app.toast(r.message, 'warn');
    } else {
      tx.commit();
      this.lastDist = worldDist;
    }
    this.reset();
  }

  dbl(p: PointerInfo): void {
    if (this.face || this.lastDist === null) return;
    const hit = this.app.vp.pick(p.x, p.y);
    if (hit?.face && hit.normal) this.commit(this.lastDist, hit.face, hit.normal.clone().normalize());
  }

  value(text: string): boolean {
    if (!this.face) return false;
    const d = parseLength(text);
    if (d === null) return false;
    // A negative value reverses the current direction.
    this.commit(d * (Math.sign(this.dist) || 1));
    return true;
  }

  key(e: KeyboardEvent): boolean {
    if (e.key === 'Control' || e.key === 'Meta') {
      this.copy = !this.copy;
      this.app.setHint();
      return true;
    }
    return false;
  }

  private reset(): void {
    this.face = null;
    this.dist = 0;
    this.app.vp.clearPreview();
    this.app.setHint();
    this.refresh();
  }

  cancel(): boolean {
    if (!this.face) return false;
    this.reset();
    return true;
  }
}

// ---------------------------------------------------------------------------
/** Shared by Move and Rotate: what the selection is and how to preview it. */
abstract class TransformTool extends Tool {
  protected groups: { g: Group; base: Matrix4 }[] = [];
  protected faces: Set<Face> = new Set();
  protected edges: Set<Edge> = new Set();
  protected copy = false;

  /** Take the selection, or the entity under the cursor when empty. */
  protected grab(p: PointerInfo): boolean {
    const app = this.app;
    if (app.selectionEmpty()) {
      const hit = app.vp.pick(p.x, p.y);
      const eh = app.vp.pickEdge(p.x, p.y, 6, hit);
      if (eh) app.sel.edges.add(eh.edge);
      else if (hit?.face) {
        for (const f of app.mesh.surfaceOf(hit.face)) app.sel.faces.add(f);
      } else if (hit?.group) app.sel.groups.add(hit.group);
      else return false;
      app.selectionChanged();
    }
    const { faces, edges } = closure(app.mesh, app.sel.faces, app.sel.edges);
    this.faces = faces;
    this.edges = edges;
    this.groups = [...app.sel.groups].map((g) => ({ g, base: g.matrix.clone() }));
    return true;
  }

  /** Apply a world-space transform as a live preview. */
  protected previewWorld(mw: Matrix4): void {
    const app = this.app;
    const ctx = app.vp.contextWorld();
    const ml = new Matrix4().copy(ctx).invert().multiply(mw).multiply(ctx);
    if (!this.copy) {
      for (const { g, base } of this.groups) g.matrix.copy(ml.clone().multiply(base));
      if (this.groups.length) app.model.touch();
    } else {
      for (const { g, base } of this.groups) g.matrix.copy(base);
    }
    const lines = [];
    for (const e of this.edges) {
      const a = e.a.clone().applyMatrix4(ctx).applyMatrix4(mw);
      const b = e.b.clone().applyMatrix4(ctx).applyMatrix4(mw);
      lines.push({ a, b, color: '#1f6feb', width: 1.5 });
    }
    if (this.copy)
      for (const { g } of this.groups) {
        const bb = g.mesh.bounds();
        if (!bb) continue;
        const gw = g.worldMatrix();
        const cs = [];
        for (let i = 0; i < 8; i++)
          cs.push(new Vector3(i & 1 ? bb.max.x : bb.min.x, i & 2 ? bb.max.y : bb.min.y, i & 4 ? bb.max.z : bb.min.z).applyMatrix4(gw).applyMatrix4(mw));
        const idx = [0, 1, 1, 3, 3, 2, 2, 0, 4, 5, 5, 7, 7, 6, 6, 4, 0, 4, 1, 5, 2, 6, 3, 7];
        for (let i = 0; i < idx.length; i += 2) lines.push({ a: cs[idx[i]], b: cs[idx[i + 1]], color: '#1f6feb', width: 1.5 });
      }
    this.extraLines = lines;
  }
  protected extraLines: { a: Vector3; b: Vector3; color: string; width: number }[] = [];

  protected restore(): void {
    for (const { g, base } of this.groups) g.matrix.copy(base);
    if (this.groups.length) this.app.model.touch();
  }

  /** Commit a world-space transform. */
  protected apply(label: string, mw: Matrix4, repeat = 1): void {
    const app = this.app;
    const ctx = app.vp.contextWorld();
    const ml = new Matrix4().copy(ctx).invert().multiply(mw).multiply(ctx);
    this.restore();
    const tx = app.history.begin(label).track(app.mesh);
    if (this.groups.length) tx.structure();
    const mesh = app.mesh;
    if (this.copy) {
      const loose = [...this.edges].filter((e) => !e.faces.some((f) => this.faces.has(f)));
      let step = new Matrix4();
      const newSel = { faces: [] as Face[], edges: [] as Edge[], groups: [] as Group[] };
      for (let i = 0; i < repeat; i++) {
        step = ml.clone().multiply(step);
        const out = copyGeometry(mesh, mesh, this.faces, loose, step);
        newSel.faces.push(...out.faces);
        newSel.edges.push(...out.edges);
        for (const { g } of this.groups) {
          const c = cloneGroup(g);
          c.matrix.premultiply(step);
          c.parent = app.context;
          app.contextGroups.push(c);
          newSel.groups.push(c);
        }
      }
      app.model.touch();
      tx.commit();
      app.clearSelection();
      for (const f of newSel.faces) {
        app.sel.faces.add(f);
        for (const e of mesh.faceEdges(f)) app.sel.edges.add(e);
      }
      for (const e of newSel.edges) app.sel.edges.add(e);
      for (const g of newSel.groups) app.sel.groups.add(g);
      app.selectionChanged();
      return;
    }
    for (const { g, base } of this.groups) g.matrix.copy(ml.clone().multiply(base));
    if (this.groups.length) app.model.touch();
    const verts = verticesOf(this.faces, this.edges);
    if (verts.size) mesh.transformVertices(verts, (p) => p.applyMatrix4(ml));
    if (ml.determinant() < 0) for (const f of this.faces) mesh.reverseFace(f);
    tx.commit();
    app.vp.selectionChanged();
  }
}

export function cloneGroup(g: Group): Group {
  const c = new Group(g.mesh, g.name);
  c.matrix.copy(g.matrix);
  c.component = g.component;
  c.material = g.material ? structuredClone(g.material) : null;
  c.extra = structuredClone(g.extra);
  if (!g.component) {
    // A copied group gets its own geometry; component copies share theirs.
    const m = new Mesh();
    m.loadData(g.mesh.toData());
    c.mesh = m;
  }
  for (const k of g.children) {
    const kk = cloneGroup(k);
    kk.parent = c;
    c.children.push(kk);
  }
  return c;
}

export class MoveTool extends TransformTool {
  readonly id = 'move';
  readonly name = t('Move');
  readonly shortcut = 'm';
  vcbLabel = t('Distance');
  private from: Vector3 | null = null;
  private delta = new Vector3();
  private hover: Snap | null = null;
  private lastCopy: { delta: Vector3 } | null = null;

  hint(): string {
    return this.from
      ? `${t('Click the target point or type a distance.')} ${this.copy ? t('Copy mode — then “3x” for an array.') : t('Ctrl = copy.')}`
      : t('Grab the selection (or the object under the cursor) at its base point.');
  }

  move(p: PointerInfo): void {
    super.move(p);
    const app = this.app;
    const s = app.inference.find(p.x, p.y, { ref: this.from, lock: this.from ? this.lock : null, guides: app.guides });
    this.hover = s;
    showSnap(app, s, p);
    if (!this.from) return;
    this.delta = s.point.clone().sub(this.from);
    this.previewWorld(new Matrix4().makeTranslation(this.delta.x, this.delta.y, this.delta.z));
    const color = s.kind === 'axis' ? s.color : '#444';
    app.vp.setPreview([{ a: this.from, b: s.point, color, width: 1.5, dashed: true }, ...this.extraLines]);
    app.showValue(formatLength(this.delta.length()));
  }

  down(p: PointerInfo): void {
    if (p.button !== 0) return;
    if (!this.from) {
      if (!this.grab(p)) return;
      this.move(p);
      this.from = this.hover!.point.clone();
      this.lastCopy = null;
      this.app.setHint();
      return;
    }
    this.finish();
  }

  private finish(repeat = 1): void {
    if (this.delta.length() > 1e-6) {
      this.apply(this.copy ? t('Copy') : t('Move'), new Matrix4().makeTranslation(this.delta.x, this.delta.y, this.delta.z), repeat);
      if (this.copy) this.lastCopy = { delta: this.delta.clone() };
    } else this.restore();
    this.from = null;
    this.app.vp.clearPreview();
    this.app.setHint();
  }

  value(text: string): boolean {
    const arr = /^\s*[x*]?\s*(\d+)\s*[x*]?\s*$/i.exec(text);
    if (!this.from && this.lastCopy && arr && /[x*]/i.test(text)) {
      // Array after a copy: undo the single copy and redo it n times.
      const n = Number(arr[1]);
      if (n < 1) return false;
      this.app.history.undo();
      this.app.clearSelection();
      return this.redoArray(n);
    }
    if (!this.from) return false;
    const d = parseLength(text);
    if (d === null) return false;
    const dir = this.delta.length() > 1e-9 ? this.delta.clone().normalize() : (this.lock ?? new Vector3(1, 0, 0));
    this.delta = dir.multiplyScalar(d);
    this.finish();
    return true;
  }

  private redoArray(n: number): boolean {
    const lc = this.lastCopy!;
    this.copy = true;
    this.delta = lc.delta.clone();
    this.from = new Vector3();
    // The selection before the copy was restored by undo.
    this.app.pruneSelection();
    this.finish(n);
    return true;
  }

  key(e: KeyboardEvent): boolean {
    if (e.key === 'Control' || e.key === 'Meta') {
      this.copy = !this.copy;
      this.app.setHint();
      this.refresh();
      return true;
    }
    if (e.key === 'Shift' && this.from && this.hover && !this.lock) {
      const d = this.hover.point.clone().sub(this.from);
      if (d.length() > 1e-6) this.lock = this.hover.axis?.clone() ?? d.normalize();
      this.refresh();
      return true;
    }
    return this.arrowLock(e);
  }

  keyUp(e: KeyboardEvent): boolean {
    if (e.key === 'Shift' && this.lock) {
      this.lock = null;
      this.refresh();
      return true;
    }
    return false;
  }

  cancel(): boolean {
    if (!this.from) return false;
    this.restore();
    this.from = null;
    this.app.vp.clearPreview();
    this.app.setHint();
    return true;
  }

  deactivate(): void {
    if (this.from) this.cancel();
    super.deactivate();
  }
}

export class RotateTool extends TransformTool {
  readonly id = 'rotate';
  readonly name = t('Rotate');
  readonly shortcut = 'q';
  vcbLabel = t('Angle');
  private center: Vector3 | null = null;
  private axis = new Vector3(0, 0, 1);
  private refDir: Vector3 | null = null;
  private angle = 0;

  hint(): string {
    if (!this.center) return t('Click the pivot point (the face beneath sets the rotation plane). Arrow keys choose the axis.');
    if (!this.refDir) return t('Click the start direction.');
    return `${t('Click or type the rotation angle (degrees, or a slope such as 3:12).')} ${this.copy ? t('Copy mode.') : t('Ctrl = copy.')}`;
  }

  move(p: PointerInfo): void {
    super.move(p);
    const app = this.app;
    const vp = app.vp;
    if (!this.center) {
      const s = app.inference.find(p.x, p.y, { guides: app.guides });
      showSnap(app, s, p);
      if (!this.lock) this.axis = s.normal && s.face ? s.normal.clone().normalize() : new Vector3(0, 0, 1);
      this.protractor(s.point, null);
      return;
    }
    const plane = Plane.fromPointNormal(this.center, this.axis);
    const s = app.inference.find(p.x, p.y, { ref: this.center, plane, guides: app.guides });
    showSnap(app, s, p);
    const q = s.point.clone().addScaledVector(plane.n, -plane.dist(s.point));
    const { origin, dir } = vp.ray(p.x, p.y);
    const onPlane = s.kind === 'ground' || s.kind === 'free' || s.kind === 'face' ? plane.intersectRay(origin, dir) ?? q : q;
    const v = onPlane.clone().sub(this.center);
    if (!this.refDir) {
      this.protractor(this.center, v.length() > 1e-6 ? v.clone().normalize() : null);
      return;
    }
    if (v.length() < 1e-9) return;
    let ang = signedAngle(this.refDir, v.normalize(), this.axis);
    const deg = (ang * 180) / Math.PI;
    const snapDeg = Math.round(deg / 15) * 15;
    if (Math.abs(deg - snapDeg) < 2.5) ang = (snapDeg * Math.PI) / 180;
    this.angle = ang;
    this.previewRotation();
  }

  private rotation(ang = this.angle): Matrix4 {
    const c = this.center!;
    return new Matrix4()
      .makeTranslation(c.x, c.y, c.z)
      .multiply(new Matrix4().makeRotationAxis(this.axis, ang))
      .multiply(new Matrix4().makeTranslation(-c.x, -c.y, -c.z));
  }

  private previewRotation(): void {
    this.previewWorld(this.rotation());
    const r = this.radius();
    const cur = this.refDir!.clone().applyAxisAngle(this.axis, this.angle);
    this.protractor(this.center!, this.refDir, [
      { a: this.center!, b: this.center!.clone().addScaledVector(this.refDir!, r * 1.2), color: '#444', width: 1.5 },
      { a: this.center!, b: this.center!.clone().addScaledVector(cur, r * 1.2), color: '#c50', width: 2 },
      ...this.extraLines,
    ]);
    this.app.showValue(formatAngle((this.angle * 180) / Math.PI));
  }

  private radius(): number {
    return this.app.vp.rig.pixelSize(this.center ?? undefined) * 60;
  }

  private protractor(at: Vector3, ref: Vector3 | null, extra: { a: Vector3; b: Vector3; color: string; width: number }[] = []): void {
    const r = this.app.vp.rig.pixelSize(at) * 60;
    const [u, v] = planeBasis(this.axis);
    const color = AXES.find((a) => Math.abs(a.dir.dot(this.axis)) > 0.999)?.color ?? '#a0a';
    const lines = [];
    const n = 48;
    for (let i = 0; i < n; i++) {
      const t0 = (i / n) * Math.PI * 2;
      const t1 = ((i + 1) / n) * Math.PI * 2;
      lines.push({
        a: at.clone().addScaledVector(u, Math.cos(t0) * r).addScaledVector(v, Math.sin(t0) * r),
        b: at.clone().addScaledVector(u, Math.cos(t1) * r).addScaledVector(v, Math.sin(t1) * r),
        color,
        width: 2,
      });
    }
    for (let i = 0; i < 24; i++) {
      const a = (i / 24) * Math.PI * 2;
      const d = u.clone().multiplyScalar(Math.cos(a)).addScaledVector(v, Math.sin(a));
      lines.push({ a: at.clone().addScaledVector(d, r * 0.88), b: at.clone().addScaledVector(d, r), color, width: 1 });
    }
    if (ref && !this.refDir) lines.push({ a: at, b: at.clone().addScaledVector(ref, r * 1.2), color: '#444', width: 1.5 });
    this.app.vp.setPreview([...lines, ...extra]);
  }

  down(p: PointerInfo): void {
    if (p.button !== 0) return;
    const app = this.app;
    if (!this.center) {
      if (!this.grab(p)) {
        app.toast(t('Select something to rotate first.'), 'warn');
        return;
      }
      const s = app.inference.find(p.x, p.y, { guides: app.guides });
      this.center = s.point.clone();
      app.setHint();
      return;
    }
    if (!this.refDir) {
      const plane = Plane.fromPointNormal(this.center, this.axis);
      const s = app.inference.find(p.x, p.y, { ref: this.center, plane });
      const q = s.point.clone().addScaledVector(plane.n, -plane.dist(s.point));
      const v = q.sub(this.center);
      if (v.length() < 1e-6) return;
      this.refDir = v.normalize();
      app.setHint();
      return;
    }
    this.finish();
  }

  private finish(): void {
    if (Math.abs(this.angle) > 1e-9) this.apply(this.copy ? t('Rotate (Copy)') : t('Rotate'), this.rotation());
    else this.restore();
    this.reset();
  }

  value(text: string): boolean {
    if (!this.refDir) return false;
    const deg = parseAngle(text);
    if (deg === null) return false;
    this.angle = (deg * Math.PI) / 180;
    this.finish();
    return true;
  }

  key(e: KeyboardEvent): boolean {
    if (e.key === 'Control' || e.key === 'Meta') {
      this.copy = !this.copy;
      this.app.setHint();
      return true;
    }
    if (!this.center && e.key.startsWith('Arrow')) {
      const d = e.key === 'ArrowRight' ? new Vector3(1, 0, 0) : e.key === 'ArrowLeft' ? new Vector3(0, 1, 0) : new Vector3(0, 0, 1);
      this.lock = d;
      this.axis = d.clone();
      this.refresh();
      return true;
    }
    return false;
  }

  private reset(): void {
    this.center = null;
    this.refDir = null;
    this.angle = 0;
    this.lock = null;
    this.app.vp.clearPreview();
    this.app.setHint();
  }

  cancel(): boolean {
    if (!this.center) return false;
    this.restore();
    this.reset();
    return true;
  }

  deactivate(): void {
    if (this.center) this.cancel();
    super.deactivate();
  }
}

function signedAngle(a: Vector3, b: Vector3, n: Vector3): number {
  const cross = new Vector3().crossVectors(a, b);
  return Math.atan2(cross.dot(n), a.dot(b));
}

// ---------------------------------------------------------------------------
export class EraserTool extends Tool {
  readonly id = 'eraser';
  readonly name = t('Eraser');
  readonly shortcut = 'e';
  private marked = new Set<Edge>();
  private markedGroups = new Set<Group>();
  private active = false;
  private mode: 'erase' | 'hide' | 'soften' = 'erase';

  hint(): string {
    return t('Click or drag over edges. Shift = hide, Ctrl = soften. Erasing an edge between coplanar faces merges them.');
  }

  down(p: PointerInfo): void {
    if (p.button !== 0) return;
    this.active = true;
    this.mode = p.shift ? 'hide' : p.ctrl ? 'soften' : 'erase';
    this.marked.clear();
    this.markedGroups.clear();
    this.collect(p);
  }

  move(p: PointerInfo): void {
    super.move(p);
    if (this.active) this.collect(p);
    else {
      const eh = this.app.vp.pickEdge(p.x, p.y, 8, this.app.vp.pick(p.x, p.y));
      this.show(eh ? [eh.edge] : []);
    }
  }

  private collect(p: PointerInfo): void {
    const app = this.app;
    const hit = app.vp.pick(p.x, p.y);
    const eh = app.vp.pickEdge(p.x, p.y, 8, hit);
    if (eh) for (const e of app.mesh.curveEdges(eh.edge)) this.marked.add(e);
    else if (hit?.group && this.mode === 'erase') this.markedGroups.add(hit.group);
    this.show([...this.marked]);
  }

  private show(edges: Edge[]): void {
    const w = this.app.vp.contextWorld();
    this.app.vp.setPreview(
      edges.map((e) => ({ a: e.a.clone().applyMatrix4(w), b: e.b.clone().applyMatrix4(w), color: this.active && this.mode !== 'erase' ? '#a0a' : '#e22', width: 3 })),
    );
  }

  up(): void {
    if (!this.active) return;
    this.active = false;
    const app = this.app;
    if (!this.marked.size && !this.markedGroups.size) return;
    const label = this.mode === 'hide' ? t('Hide Edges') : this.mode === 'soften' ? t('Soften Edges') : t('Erase');
    const tx = app.history.begin(label).track(app.mesh);
    if (this.mode === 'erase') {
      eraseEdges(app.mesh, this.marked);
      if (this.markedGroups.size) {
        tx.structure();
        const list = app.contextGroups;
        for (const g of this.markedGroups) {
          const i = list.indexOf(g);
          if (i >= 0) list.splice(i, 1);
        }
        app.model.touch();
      }
    } else {
      for (const e of this.marked) {
        if (this.mode === 'hide') e.hidden = true;
        else e.soft = true;
      }
      app.mesh.touch();
    }
    tx.commit();
    this.marked.clear();
    this.markedGroups.clear();
    app.vp.setPreview([]);
  }

  cancel(): boolean {
    if (!this.active) return false;
    this.active = false;
    this.marked.clear();
    this.app.vp.setPreview([]);
    return true;
  }
}

// ---------------------------------------------------------------------------
export type Paint = { color?: [number, number, number]; material?: string };

export class PaintTool extends Tool {
  readonly id = 'paint';
  readonly name = t('Paint Bucket');
  readonly shortcut = 'b';
  cursor = 'cell';
  static current: Paint = { color: [0.8, 0.55, 0.35] };

  hint(): string {
    return t('Click a face or group. Alt = sample paint, Ctrl = connected matching faces, Shift = all matching faces.');
  }

  private paintAttrs(): Record<string, unknown> {
    const cur = PaintTool.current;
    if (cur.material) {
      const m = this.app.model.materials.get(cur.material);
      if (m) {
        const out: Record<string, unknown> = { mat: m.name };
        if (m.color) out.color = m.color.slice();
        if (m.texture) out.texture = structuredClone(m.texture);
        if (m.opacity !== undefined) out.opacity = m.opacity;
        return out;
      }
    }
    return cur.color ? { color: cur.color.slice() } : {};
  }

  down(p: PointerInfo): void {
    if (p.button !== 0) return;
    const app = this.app;
    const hit = app.vp.pick(p.x, p.y);
    if (!hit) return;
    if (p.alt) {
      const f = hit.ownerFace;
      PaintTool.current = f?.attrs.mat ? { material: f.attrs.mat } : { color: f?.attrs.color ? [...f.attrs.color] : undefined };
      app.emit('paint');
      return;
    }
    const paint = this.paintAttrs();
    if (hit.group) {
      const tx = app.history.begin(t('Paint')).structure();
      hit.group.material = paint.color ? { color: paint.color as [number, number, number] } : null;
      app.model.touch();
      tx.commit();
      return;
    }
    if (!hit.face) return;
    const mesh = app.mesh;
    let targets: Face[];
    if (app.sel.faces.has(hit.face)) targets = [...app.sel.faces];
    else if (p.shift || p.ctrl) {
      const key = paintKey(hit.face);
      if (p.shift) targets = [...mesh.faces].filter((f) => paintKey(f) === key);
      else {
        const seen = new Set<Face>([hit.face]);
        const stack = [hit.face];
        while (stack.length) {
          const f = stack.pop()!;
          for (const e of mesh.faceEdges(f))
            for (const g of e.faces)
              if (!seen.has(g) && paintKey(g) === key) {
                seen.add(g);
                stack.push(g);
              }
        }
        targets = [...seen];
      }
    } else targets = mesh.surfaceOf(hit.face);
    const tx = app.history.begin(t('Paint')).track(mesh);
    for (const f of targets) {
      delete f.attrs.color;
      delete f.attrs.texture;
      delete f.attrs.mat;
      delete f.attrs.opacity;
      Object.assign(f.attrs, structuredClone(paint));
    }
    mesh.touch();
    tx.commit();
  }
}

function paintKey(f: Face): string {
  return JSON.stringify([f.attrs.color ?? null, f.attrs.texture?.embed ?? f.attrs.texture?.path ?? null, f.attrs.mat ?? null]);
}

// ---------------------------------------------------------------------------
export class TapeTool extends Tool {
  readonly id = 'tape';
  readonly name = t('Tape Measure');
  readonly shortcut = 't';
  vcbLabel = t('Length');
  private start: Snap | null = null;
  private hover: Snap | null = null;

  hint(): string {
    return this.start
      ? t('Click the second point: measures and places a guide line (from an edge) or a guide point.')
      : t('Click the start point. Double-click an edge to place a guide line on it.');
  }

  move(p: PointerInfo): void {
    super.move(p);
    const app = this.app;
    const s = app.inference.find(p.x, p.y, { ref: this.start?.point ?? null, guides: app.guides, lock: this.lock });
    this.hover = s;
    showSnap(app, s, p);
    if (!this.start) return;
    let end = s.point;
    if (this.start.kind === 'edge' && this.start.edge) end = s.point;
    app.vp.setPreview([{ a: this.start.point, b: end, color: '#111', width: 1.5, dashed: true }]);
    app.vp.setLabels([{ at: this.start.point.clone().lerp(end, 0.5), text: formatLength(this.start.point.distanceTo(end)) }]);
    app.showValue(formatLength(this.start.point.distanceTo(end)));
  }

  down(p: PointerInfo): void {
    if (p.button !== 0) return;
    this.move(p);
    if (!this.hover) return;
    if (!this.start) {
      this.start = this.hover;
      this.app.setHint();
      return;
    }
    this.finish(this.hover.point);
  }

  private finish(end: Vector3): void {
    const app = this.app;
    const st = this.start!;
    const d = st.point.distanceTo(end);
    if (st.kind === 'edge' && st.edge) {
      const owner = app.vp.visibleInstances().find((i) => i.mesh.edges.has(st.edge!));
      const w = owner?.world ?? new Matrix4();
      const dir = st.edge.b.clone().applyMatrix4(w).sub(st.edge.a.clone().applyMatrix4(w)).normalize();
      app.guides.lines.push({ a: end.clone(), dir });
    } else {
      app.guides.points.push(end.clone());
      app.guides.lines.push({ a: st.point.clone(), dir: end.clone().sub(st.point).normalize() });
    }
    app.emit('guides');
    app.toast(t('Measured: {d}', { d: formatLength(d) }));
    this.start = null;
    app.vp.clearPreview();
    app.setHint();
  }

  value(text: string): boolean {
    if (!this.start || !this.hover) return false;
    const len = parseLength(text);
    if (len === null) return false;
    const dir = this.hover.point.clone().sub(this.start.point);
    if (dir.length() < 1e-9) return false;
    this.finish(this.start.point.clone().addScaledVector(dir.normalize(), len));
    return true;
  }

  key(e: KeyboardEvent): boolean {
    return this.arrowLock(e);
  }

  cancel(): boolean {
    if (!this.start) return false;
    this.start = null;
    this.app.vp.clearPreview();
    this.app.setHint();
    return true;
  }
}

// ---------------------------------------------------------------------------
export class OrbitTool extends Tool {
  readonly id = 'orbit';
  readonly name = t('Orbit');
  readonly shortcut = 'o';
  cursor = 'grab';
  private prev: Vector2 | null = null;
  private pivot: Vector3 | undefined;
  hint(): string {
    return t('Drag to orbit around the point under the cursor. Shift = pan.');
  }
  down(p: PointerInfo): void {
    this.prev = new Vector2(p.x, p.y);
    this.pivot = this.app.vp.pick(p.x, p.y, { anyContext: true })?.point;
  }
  move(p: PointerInfo): void {
    if (!this.prev) return;
    const d = new Vector2(p.x, p.y).sub(this.prev);
    this.prev.set(p.x, p.y);
    if (p.shift) this.app.vp.rig.pan(d.x, d.y, this.pivot);
    else this.app.vp.rig.orbit(d.x, d.y, this.pivot);
    this.app.vp.invalidate();
  }
  up(): void {
    this.prev = null;
  }
}

export class PanTool extends Tool {
  readonly id = 'pan';
  readonly name = t('Pan (view)');
  readonly shortcut = 'h';
  cursor = 'move';
  private prev: Vector2 | null = null;
  private at: Vector3 | undefined;
  hint(): string {
    return t('Drag to pan the view.');
  }
  down(p: PointerInfo): void {
    this.prev = new Vector2(p.x, p.y);
    this.at = this.app.vp.pick(p.x, p.y, { anyContext: true })?.point;
  }
  move(p: PointerInfo): void {
    if (!this.prev) return;
    const d = new Vector2(p.x, p.y).sub(this.prev);
    this.prev.set(p.x, p.y);
    this.app.vp.rig.pan(d.x, d.y, this.at);
    this.app.vp.invalidate();
  }
  up(): void {
    this.prev = null;
  }
}
