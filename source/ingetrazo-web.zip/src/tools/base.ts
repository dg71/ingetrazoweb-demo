// SPDX-License-Identifier: GPL-3.0-or-later
// IngeTrazo Web — tool protocol (modelled on IngeTrazo tools/base.py).
import { Vector3 } from 'three';
import type { App } from '../app';

export type PointerInfo = {
  x: number;
  y: number;
  button: number;
  shift: boolean;
  ctrl: boolean;
  alt: boolean;
};

export abstract class Tool {
  abstract readonly id: string;
  abstract readonly name: string;
  readonly shortcut: string = '';
  /** Label of the Value Control Box; empty = the tool takes no typed value. */
  vcbLabel = '';
  cursor = 'crosshair';
  /** Locked inference direction (Shift / arrow keys). */
  lock: Vector3 | null = null;
  protected last: PointerInfo | null = null;

  constructor(protected app: App) {}

  activate(): void {}
  deactivate(): void {
    this.app.vp.clearPreview();
    this.lock = null;
  }
  down(_p: PointerInfo): void {}
  move(p: PointerInfo): void {
    this.last = p;
  }
  up(_p: PointerInfo): void {}
  dbl(_p: PointerInfo): void {}
  /** Return true when the key was handled. */
  key(_e: KeyboardEvent): boolean {
    return false;
  }
  keyUp(_e: KeyboardEvent): boolean {
    return false;
  }
  /** A value typed into the VCB (Enter). Return true when accepted. */
  value(_text: string): boolean {
    return false;
  }
  /** Esc. Return false when there was nothing to cancel. */
  cancel(): boolean {
    return false;
  }
  hint(): string {
    return '';
  }
  /** Re-run the hover logic (after a camera move). */
  refresh(): void {
    if (this.last) this.move(this.last);
  }

  /** Arrow keys lock axes; Shift is handled by the tools that use it. */
  protected arrowLock(e: KeyboardEvent): boolean {
    const dirs: Record<string, Vector3> = {
      ArrowRight: new Vector3(1, 0, 0),
      ArrowLeft: new Vector3(0, 1, 0),
      ArrowUp: new Vector3(0, 0, 1),
      ArrowDown: new Vector3(0, 0, 1),
    };
    const d = dirs[e.key];
    if (!d) return false;
    this.lock = this.lock && this.lock.equals(d) ? null : d;
    this.refresh();
    return true;
  }
}
