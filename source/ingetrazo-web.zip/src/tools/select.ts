// SPDX-License-Identifier: GPL-3.0-or-later
// IngeTrazo Web — Select: click, Ctrl adds, Shift toggles; double-click a
// face takes its edges, triple-click everything connected; double-click a
// group edits it. Drag left→right = window, right→left = crossing.
import { Vector2, Vector3 } from 'three';
import { t } from '../i18n';
import type { Edge, Face } from '../core/mesh';
import type { Group } from '../core/scene';
import { type PointerInfo, Tool } from './base';

export class SelectTool extends Tool {
  readonly id = 'select';
  readonly name = t('Select');
  readonly shortcut = ' ';
  cursor = 'default';
  private dragStart: Vector2 | null = null;
  private dragging = false;
  private box: HTMLDivElement | null = null;
  private lastClick = { t: 0, n: 0, key: '' };

  hint(): string {
    return t('Click to select. Ctrl adds, Shift toggles. Double-click a group to edit it.');
  }

  down(p: PointerInfo): void {
    if (p.button !== 0) return;
    this.dragStart = new Vector2(p.x, p.y);
    this.dragging = false;
  }

  move(p: PointerInfo): void {
    super.move(p);
    if (!this.dragStart) return;
    const cur = new Vector2(p.x, p.y);
    if (!this.dragging && cur.distanceTo(this.dragStart) > 4) this.dragging = true;
    if (this.dragging) this.drawBox(this.dragStart, cur);
  }

  up(p: PointerInfo): void {
    if (!this.dragStart) return;
    const start = this.dragStart;
    this.dragStart = null;
    if (this.dragging) {
      this.dragging = false;
      this.box?.remove();
      this.box = null;
      this.boxSelect(start, new Vector2(p.x, p.y), p);
      return;
    }
    this.click(p);
  }

  private drawBox(a: Vector2, b: Vector2): void {
    if (!this.box) {
      this.box = document.createElement('div');
      this.box.className = 'select-box';
      this.app.vp.html.appendChild(this.box);
    }
    const crossing = b.x < a.x;
    this.box.classList.toggle('crossing', crossing);
    Object.assign(this.box.style, {
      left: `${Math.min(a.x, b.x)}px`,
      top: `${Math.min(a.y, b.y)}px`,
      width: `${Math.abs(b.x - a.x)}px`,
      height: `${Math.abs(b.y - a.y)}px`,
    });
  }

  private pickAt(p: PointerInfo): { face?: Face; edge?: Edge; group?: Group } {
    const vp = this.app.vp;
    const hit = vp.pick(p.x, p.y);
    const eh = vp.pickEdge(p.x, p.y, 6, hit);
    if (eh) return { edge: eh.edge };
    if (hit?.face) return { face: hit.face };
    if (hit?.group) return { group: hit.group };
    return {};
  }

  private click(p: PointerInfo): void {
    const app = this.app;
    const s = app.sel;
    const hit = this.pickAt(p);
    const key = hit.face ? 'f' : hit.edge ? 'e' : hit.group ? 'g' : '';
    const now = performance.now();
    const n = now - this.lastClick.t < 380 && this.lastClick.key === key ? this.lastClick.n + 1 : 1;
    this.lastClick = { t: now, n, key };

    if (!hit.face && !hit.edge && !hit.group) {
      if (!p.ctrl && !p.shift) {
        if (app.selectionEmpty() && app.context && n === 1) app.exitContext();
        else app.clearSelection();
      }
      return;
    }
    if (hit.group && n >= 2) {
      app.enterGroup(hit.group);
      return;
    }
    let faces: Face[] = [];
    let edges: Edge[] = [];
    const groups: Group[] = [];
    const mesh = app.mesh;
    if (hit.face) {
      faces = mesh.surfaceOf(hit.face);
      if (n === 2) for (const f of faces) edges.push(...mesh.faceEdges(f));
      if (n >= 3) ({ faces, edges } = connected(mesh, hit.face));
    } else if (hit.edge) {
      edges = mesh.curveEdges(hit.edge);
      if (n === 2) {
        for (const e of edges) faces.push(...e.faces);
        for (const f of faces) edges.push(...mesh.faceEdges(f));
      }
      if (n >= 3) {
        const anyFace = hit.edge.faces[0];
        if (anyFace) ({ faces, edges } = connected(mesh, anyFace));
        else edges = connectedEdges(hit.edge);
      }
    } else if (hit.group) groups.push(hit.group);

    if (!p.ctrl && !p.shift) {
      s.faces.clear();
      s.edges.clear();
      s.groups.clear();
    }
    const toggle = p.shift && n === 1;
    const apply = <T>(set: Set<T>, items: T[]) => {
      for (const it of items) {
        if (toggle && set.has(it)) set.delete(it);
        else set.add(it);
      }
    };
    apply(s.faces, faces);
    apply(s.edges, edges);
    apply(s.groups, groups);
    app.selectionChanged();
  }

  dbl(_p: PointerInfo): void {
    // Handled through click counting (works the same for touch/pen).
  }

  private boxSelect(a: Vector2, b: Vector2, p: PointerInfo): void {
    const app = this.app;
    const vp = app.vp;
    const crossing = b.x < a.x;
    const lo = new Vector2(Math.min(a.x, b.x), Math.min(a.y, b.y));
    const hi = new Vector2(Math.max(a.x, b.x), Math.max(a.y, b.y));
    const inside = (q: Vector3) => {
      if (!vp.inFront(q)) return false;
      const s = vp.toScreen(q);
      return s.x >= lo.x && s.x <= hi.x && s.y >= lo.y && s.y <= hi.y;
    };
    const world = vp.contextWorld();
    const s = app.sel;
    if (!p.ctrl && !p.shift) {
      s.faces.clear();
      s.edges.clear();
      s.groups.clear();
    }
    const mesh = app.mesh;
    const vin = new Map<object, boolean>();
    for (const v of mesh.vertices) vin.set(v, inside(v.position.clone().applyMatrix4(world)));
    for (const e of mesh.edges) {
      if (e.hidden) continue;
      const ia = vin.get(e.v0)!;
      const ib = vin.get(e.v1)!;
      const take = crossing ? ia || ib || segCrossesRect(vp.toScreen(e.a.clone().applyMatrix4(world)), vp.toScreen(e.b.clone().applyMatrix4(world)), lo, hi) : ia && ib;
      if (take) s.edges.add(e);
    }
    for (const f of mesh.faces) {
      if (f.attrs.hidden) continue;
      const vs = [...f.vertexSet()];
      const all = vs.every((v) => vin.get(v));
      const any = vs.some((v) => vin.get(v));
      if (all || (crossing && (any || mesh.faceEdges(f).some((e) => s.edges.has(e))))) s.faces.add(f);
    }
    for (const g of app.contextGroups) {
      if (g.hidden || g.locked) continue;
      const bb = g.mesh.bounds();
      if (!bb) continue;
      const gw = g.worldMatrix();
      const cs: Vector3[] = [];
      for (let i = 0; i < 8; i++)
        cs.push(new Vector3(i & 1 ? bb.max.x : bb.min.x, i & 2 ? bb.max.y : bb.min.y, i & 4 ? bb.max.z : bb.min.z).applyMatrix4(gw));
      const all = cs.every(inside);
      const any = cs.some(inside);
      if (all || (crossing && any)) s.groups.add(g);
    }
    app.selectionChanged();
  }

  key(e: KeyboardEvent): boolean {
    if (e.key === 'Escape') {
      if (!this.app.selectionEmpty()) this.app.clearSelection();
      else this.app.exitContext();
      return true;
    }
    return false;
  }

  cancel(): boolean {
    if (this.box) {
      this.box.remove();
      this.box = null;
      this.dragStart = null;
      return true;
    }
    return false;
  }
}

function connected(mesh: import('../core/mesh').Mesh, start: Face): { faces: Face[]; edges: Edge[] } {
  const faces = new Set<Face>([start]);
  const edges = new Set<Edge>();
  const stack: Face[] = [start];
  while (stack.length) {
    const f = stack.pop()!;
    for (const e of mesh.faceEdges(f)) {
      edges.add(e);
      for (const g of e.faces)
        if (!faces.has(g)) {
          faces.add(g);
          stack.push(g);
        }
    }
  }
  // Loose edges hanging off the connected faces.
  for (const e of [...edges])
    for (const v of [e.v0, e.v1]) for (const x of v.edges) if (!x.faces.length) for (const y of connectedEdges(x)) edges.add(y);
  return { faces: [...faces], edges: [...edges] };
}

function connectedEdges(start: Edge): Edge[] {
  const seen = new Set<Edge>([start]);
  const stack = [start];
  while (stack.length) {
    const e = stack.pop()!;
    for (const v of [e.v0, e.v1])
      for (const x of v.edges)
        if (!seen.has(x)) {
          seen.add(x);
          stack.push(x);
        }
  }
  return [...seen];
}

function segCrossesRect(a: Vector2, b: Vector2, lo: Vector2, hi: Vector2): boolean {
  const steps = 16;
  for (let i = 0; i <= steps; i++) {
    const x = a.x + ((b.x - a.x) * i) / steps;
    const y = a.y + ((b.y - a.y) * i) / steps;
    if (x >= lo.x && x <= hi.x && y >= lo.y && y <= hi.y) return true;
  }
  return false;
}
