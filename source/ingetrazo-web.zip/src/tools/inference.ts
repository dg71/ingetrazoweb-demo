// SPDX-License-Identifier: GPL-3.0-or-later
// IngeTrazo Web — inference engine: endpoint, midpoint, on-edge, on-face,
// and axis inference from a reference point (magnetic, like IngeTrazo's
// tools/line.py `magnetic_axis_deg`), with Shift locking a direction.
import { Matrix4, Vector2, Vector3 } from 'three';
import { t } from '../i18n';
import type { Edge, Face } from '../core/mesh';
import { Plane } from '../core/plane';
import type { Viewport } from '../view/viewport';

export type SnapKind = 'endpoint' | 'midpoint' | 'edge' | 'face' | 'axis' | 'ground' | 'free' | 'close' | 'guide';

export type Snap = {
  point: Vector3;
  kind: SnapKind;
  label: string;
  color: string;
  /** Face under the cursor (any context) and its world normal. */
  face?: Face;
  inContext?: boolean;
  normal?: Vector3;
  edge?: Edge;
  axis?: Vector3;
};

export const AXES: { dir: Vector3; name: string; color: string }[] = [
  { dir: new Vector3(1, 0, 0), name: t('Red Axis'), color: '#d22' },
  { dir: new Vector3(0, 1, 0), name: t('Green Axis'), color: '#1a1' },
  { dir: new Vector3(0, 0, 1), name: t('Blue Axis'), color: '#23d' },
];

const SNAP_PX = 12;
const AXIS_PX = 14;

export type SnapOptions = {
  ref?: Vector3 | null;
  /** Locked direction (Shift). */
  lock?: Vector3 | null;
  /** Fallback plane when nothing is hit (default: ground or plane through ref). */
  plane?: Plane | null;
  /** Extra points that snap (e.g. the chain's first point → "close"). */
  extra?: { point: Vector3; kind: SnapKind; label: string; color: string }[];
  /** Guide points / lines of the Tape Measure. */
  guides?: { points: Vector3[]; lines: { a: Vector3; dir: Vector3 }[] };
  noAxis?: boolean;
};

export class Inference {
  /** Extension snap points (world coordinates), e.g. T-nuts. */
  providers: (() => { point: Vector3; label: string; color?: string }[])[] = [];
  constructor(private vp: Viewport) {}

  find(x: number, y: number, opts: SnapOptions = {}): Snap {
    const vp = this.vp;
    const mouse = new Vector2(x, y);
    const { origin, dir } = vp.ray(x, y);
    const hit = vp.pick(x, y, { anyContext: true });
    const ctxHit = vp.pick(x, y);

    // 1. Points: endpoints and midpoints of visible geometry.
    let best: Snap | null = null;
    let bestPx = SNAP_PX;
    const consider = (p: Vector3, kind: SnapKind, label: string, color: string, extra?: Partial<Snap>) => {
      if (!vp.inFront(p)) return;
      if (hit && p.distanceTo(vp.rig.position) > hit.distance * 1.01 + 0.01) return; // hidden behind a face
      const d = vp.toScreen(p).distanceTo(mouse);
      if (d < bestPx) {
        bestPx = d;
        best = { point: p.clone(), kind, label, color, ...extra };
      }
    };
    for (const e of opts.extra ?? []) {
      const d = vp.toScreen(e.point).distanceTo(mouse);
      if (d < SNAP_PX + 4) return { ...e, point: e.point.clone() };
    }
    for (const inst of vp.visibleInstances()) {
      const mesh = inst.mesh;
      if (mesh.vertices.size > 60000) continue;
      const world = inst.world;
      const sphere = mesh.bounds();
      if (sphere && !this.nearScreen(sphere.min, sphere.max, world, mouse)) continue;
      for (const v of mesh.vertices) {
        if (!v.edges.size) continue;
        let hard = false;
        for (const e of v.edges)
          if (!e.soft && !e.hidden) {
            hard = true;
            break;
          }
        if (!hard) continue;
        consider(v.position.clone().applyMatrix4(world), 'endpoint', t('Endpoint'), '#1a1');
      }
      for (const e of mesh.edges) {
        if (e.soft || e.hidden) continue;
        consider(e.midpoint().applyMatrix4(world), 'midpoint', t('Midpoint'), '#0aa');
      }
    }
    for (const p of opts.guides?.points ?? []) consider(p, 'guide', t('Guide Point'), '#111');
    for (const fn of this.providers) for (const sp of fn()) consider(sp.point, 'endpoint', sp.label, sp.color ?? '#a50');

    const ref = opts.ref ?? null;
    // 2. Locked direction: stay on the locked line; a snapped point only
    //    decides how far along it (its projection onto the line).
    if (ref && opts.lock) {
      const d = opts.lock.clone().normalize();
      const snapped = best as Snap | null;
      const p = snapped
        ? ref.clone().addScaledVector(d, snapped.point.clone().sub(ref).dot(d))
        : closestOnLine(ref, d, origin, dir);
      const ax = AXES.find((a) => Math.abs(a.dir.dot(d)) > 0.9999);
      const base = ax ? t('On {axis} (locked)', { axis: ax.name }) : t('Locked');
      return {
        point: p,
        kind: 'axis',
        label: snapped ? t('{base} · to {target}', { base, target: snapped.label }) : base,
        color: ax?.color ?? '#a0a',
        axis: d,
      };
    }
    if (best) return this.withFace(best, hit, ctxHit, opts);

    // 3. On edge (any instance), with axis inference winning near an axis.
    let edgeSnap: Snap | null = null;
    const eh = this.edgeAnyContext(x, y, hit);
    if (eh) edgeSnap = { point: eh.point, kind: 'edge', label: t('On Edge'), color: '#d22', edge: eh.edge };

    let axisSnap: Snap | null = null;
    if (ref && !opts.noAxis) {
      let bestAx = AXIS_PX;
      for (const a of AXES) {
        const p = closestOnLine(ref, a.dir, origin, dir);
        if (p.distanceTo(ref) < 1e-6 || !vp.inFront(p)) continue;
        const d = vp.toScreen(p).distanceTo(mouse);
        if (d < bestAx) {
          bestAx = d;
          axisSnap = { point: p, kind: 'axis', label: t('On {axis}', { axis: a.name }), color: a.color, axis: a.dir.clone() };
        }
      }
    }
    for (const l of opts.guides?.lines ?? []) {
      const p = closestOnLine(l.a, l.dir, origin, dir);
      if (vp.toScreen(p).distanceTo(mouse) < SNAP_PX && !edgeSnap)
        edgeSnap = { point: p, kind: 'guide', label: t('On Guide'), color: '#111' };
    }
    if (edgeSnap && axisSnap) {
      // An axis line crossing the edge: the intersection is the point.
      const ax = axisSnap.axis!;
      if (edgeSnap.edge) {
        const e = edgeSnap.edge;
        const owner = this.ownerWorld(e);
        const a = e.a.clone().applyMatrix4(owner);
        const b = e.b.clone().applyMatrix4(owner);
        const q = closestBetweenLines(ref!, ax, a, b.clone().sub(a).normalize());
        if (q && vp.toScreen(q).distanceTo(mouse) < SNAP_PX)
          return this.withFace({ ...axisSnap, point: q, label: `${axisSnap.label} · ${t('On Edge')}` }, hit, ctxHit, opts);
      }
      return this.withFace(axisSnap, hit, ctxHit, opts);
    }
    if (edgeSnap) return this.withFace(edgeSnap, hit, ctxHit, opts);
    if (axisSnap) return this.withFace(axisSnap, hit, ctxHit, opts);

    // 4. On face.
    if (hit) {
      return {
        point: hit.point.clone(),
        kind: 'face',
        label: hit.owner === vp.context ? t('On Face') : t('In Group'),
        color: '#23d',
        face: hit.ownerFace,
        normal: hit.normal,
        inContext: !!ctxHit?.face,
      };
    }

    // 5. Fallback plane.
    let plane = opts.plane ?? null;
    if (!plane) {
      if (ref) {
        plane = new Plane(new Vector3(0, 0, 1), ref.z);
        // Looking almost horizontally: a vertical plane facing the camera.
        if (Math.abs(dir.z) < 0.08) {
          const n = new Vector3(dir.x, dir.y, 0).normalize();
          plane = Plane.fromPointNormal(ref, n);
        }
      } else plane = new Plane(new Vector3(0, 0, 1), 0);
    }
    const p = plane.intersectRay(origin, dir);
    if (p && vp.inFront(p) && p.distanceTo(origin) < 1e5)
      return { point: p, kind: 'ground', label: plane.n.z > 0.999 && Math.abs(plane.d) < 1e-9 ? t('On Ground') : '', color: '#888' };
    return { point: origin.clone().addScaledVector(dir, 10), kind: 'free', label: '', color: '#888' };
  }

  private withFace(s: Snap, hit: ReturnType<Viewport['pick']>, ctxHit: ReturnType<Viewport['pick']>, _o: SnapOptions): Snap {
    if (hit && !s.face && hit.point.distanceTo(s.point) < Math.max(0.02, hit.distance * 0.02)) {
      s.face = hit.ownerFace;
      s.normal = hit.normal;
      s.inContext = !!ctxHit?.face;
    }
    return s;
  }

  private ownerWorld(e: Edge): Matrix4 {
    for (const inst of this.vp.visibleInstances()) if (inst.mesh.edges.has(e)) return inst.world;
    return new Matrix4();
  }

  private edgeAnyContext(x: number, y: number, hit: ReturnType<Viewport['pick']>): { edge: Edge; point: Vector3 } | null {
    const vp = this.vp;
    const mouse = new Vector2(x, y);
    let best: { edge: Edge; point: Vector3; px: number } | null = null;
    for (const inst of vp.visibleInstances()) {
      const mesh = inst.mesh;
      if (mesh.edges.size > 80000) continue;
      const b = mesh.bounds();
      if (b && !this.nearScreen(b.min, b.max, inst.world, mouse)) continue;
      for (const e of mesh.edges) {
        if (e.soft || e.hidden) continue;
        const a = e.a.clone().applyMatrix4(inst.world);
        const bb = e.b.clone().applyMatrix4(inst.world);
        if (!vp.inFront(a) || !vp.inFront(bb)) continue;
        const sa = vp.toScreen(a);
        const sb = vp.toScreen(bb);
        const d = sb.clone().sub(sa);
        const len2 = d.lengthSq();
        let t = len2 > 0 ? mouse.clone().sub(sa).dot(d) / len2 : 0;
        t = Math.max(0, Math.min(1, t));
        const px = sa.clone().addScaledVector(d, t).distanceTo(mouse);
        if (px > 7 || (best && px >= best.px)) continue;
        // The 3D point on the edge closest to the cursor ray.
        const { origin, dir } = vp.ray(x, y);
        const q = closestBetweenLines(origin, dir, a, bb.clone().sub(a).normalize());
        let point = a.clone().lerp(bb, t);
        if (q) {
          const qs = bb.clone().sub(a);
          const tt = Math.max(0, Math.min(1, q.clone().sub(a).dot(qs) / qs.lengthSq()));
          point = a.clone().lerp(bb, tt);
        }
        if (hit && point.distanceTo(vp.rig.position) > hit.distance * 1.01 + 0.01) continue;
        best = { edge: e, point, px };
      }
    }
    return best;
  }

  private nearScreen(min: Vector3, max: Vector3, world: Matrix4, mouse: Vector2): boolean {
    const lo = new Vector2(Infinity, Infinity);
    const hi = new Vector2(-Infinity, -Infinity);
    for (let i = 0; i < 8; i++) {
      const p = new Vector3(i & 1 ? max.x : min.x, i & 2 ? max.y : min.y, i & 4 ? max.z : min.z).applyMatrix4(world);
      if (!this.vp.inFront(p)) return true;
      const s = this.vp.toScreen(p);
      lo.min(s);
      hi.max(s);
    }
    const m = SNAP_PX + 2;
    return mouse.x >= lo.x - m && mouse.x <= hi.x + m && mouse.y >= lo.y - m && mouse.y <= hi.y + m;
  }
}

/** Point on the line (p, d) closest to the ray (o, r). */
export function closestOnLine(p: Vector3, d: Vector3, o: Vector3, r: Vector3): Vector3 {
  const q = closestBetweenLines(o, r, p, d.clone().normalize());
  if (!q) return p.clone();
  const dd = d.clone().normalize();
  return p.clone().addScaledVector(dd, q.clone().sub(p).dot(dd));
}

/** On line 2 (p2 + t·d2), the point closest to line 1 (p1 + s·d1). */
export function closestBetweenLines(p1: Vector3, d1: Vector3, p2: Vector3, d2: Vector3): Vector3 | null {
  const r = p1.clone().sub(p2);
  const a = d1.dot(d1);
  const b = d1.dot(d2);
  const c = d2.dot(d2);
  const d = d1.dot(r);
  const e = d2.dot(r);
  const den = a * c - b * b;
  if (Math.abs(den) < 1e-12) return null;
  const t = (a * e - b * d) / den;
  return p2.clone().addScaledVector(d2, t);
}
