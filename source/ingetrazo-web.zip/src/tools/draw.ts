// SPDX-License-Identifier: GPL-3.0-or-later
// IngeTrazo Web — drawing tools: Line, Rectangle, Circle, Polygon.
import { Vector2, Vector3 } from 'three';
import { t } from '../i18n';
import type { App } from '../app';
import { circlePoints, closeNearPlanar, drawSegments, loopSegments } from '../core/ops';
import { Plane } from '../core/plane';
import { formatLength, localNum, parseLength, splitValues } from '../core/units';
import { type PointerInfo, Tool } from './base';
import type { Snap } from './inference';

/** Shared: snap marker + tooltip for a snap result. */
export function showSnap(app: App, s: Snap, p: PointerInfo): void {
  const vp = app.vp;
  const shape = s.kind === 'midpoint' ? 'diamond' : s.kind === 'endpoint' || s.kind === 'close' ? 'square' : 'dot';
  vp.setMarker(s.kind === 'ground' || s.kind === 'free' ? null : s.point, s.color, shape);
  vp.setTip(s.label || null, new Vector2(p.x, p.y));
}

/** Small deviations read better in millimetres. */
function devText(d: number): string {
  return d < 0.1 ? `${localNum((d * 1000).toFixed(1))} mm` : formatLength(d);
}

/** In-plane axes for a drawing plane normal (world X/Y on the ground). */
export function planeBasis(n: Vector3): [Vector3, Vector3] {
  if (Math.abs(n.z) > 0.9999) return [new Vector3(1, 0, 0), new Vector3(0, 1, 0).multiplyScalar(Math.sign(n.z) || 1)];
  const u = new Vector3().crossVectors(new Vector3(0, 0, 1), n).normalize();
  const v = new Vector3().crossVectors(n, u).normalize();
  return [u, v];
}

abstract class DrawTool extends Tool {
  /** Commit world-space segments into the active mesh. */
  protected commit(label: string, segs: [Vector3, Vector3][], opts: { plane?: Plane; curve?: boolean } = {}) {
    const app = this.app;
    const tx = app.history.begin(label).track(app.mesh);
    const local = segs.map(([a, b]) => [app.toLocal(a), app.toLocal(b)] as [Vector3, Vector3]);
    let plane: Plane | undefined;
    if (opts.plane) {
      const p0 = app.toLocal(opts.plane.n.clone().multiplyScalar(opts.plane.d));
      plane = Plane.fromPointNormal(p0, app.toLocalDir(opts.plane.n));
    }
    const cam = app.vp.rig.position;
    const mid = segs[0][0];
    const hint = app.toLocalDir(cam.clone().sub(mid).normalize());
    const res = drawSegments(app.mesh, local, { plane, orientHint: plane && plane.n.dot(hint) < 0 ? plane.n.clone().negate() : hint, curve: opts.curve });
    tx.commit();
    return res;
  }
}

export class LineTool extends DrawTool {
  readonly id = 'line';
  readonly name = t('Line');
  readonly shortcut = 'l';
  vcbLabel = t('Length');
  private start: Vector3 | null = null;
  private first: Vector3 | null = null;
  private hover: Snap | null = null;

  hint(): string {
    return this.start
      ? t('Click the next point or type a length. Shift locks the direction, arrow keys lock an axis, Esc finishes.')
      : t('Click the start point.');
  }

  move(p: PointerInfo): void {
    super.move(p);
    const app = this.app;
    const s = app.inference.find(p.x, p.y, {
      ref: this.start,
      lock: this.start ? this.lock : null,
      guides: app.guides,
      extra:
        this.first && this.start && !this.first.equals(this.start)
          ? [{ point: this.first, kind: 'close', label: t('Close'), color: '#1a1' }]
          : [],
    });
    this.hover = s;
    showSnap(this.app, s, p);
    if (this.start) {
      const color = s.kind === 'axis' ? s.color : '#222';
      app.vp.setPreview([{ a: this.start, b: s.point, color, width: 2 }]);
      app.showValue(formatLength(this.start.distanceTo(s.point)));
    } else app.vp.setPreview([]);
  }

  key(e: KeyboardEvent): boolean {
    if (e.key === 'Shift' && this.start && this.hover && !this.lock) {
      const d = this.hover.point.clone().sub(this.start);
      if (d.length() > 1e-6) {
        this.lock = this.hover.axis?.clone() ?? d.normalize();
        this.refresh();
      }
      return true;
    }
    return this.arrowLock(e);
  }

  keyUp(e: KeyboardEvent): boolean {
    if (e.key === 'Shift' && this.lock) {
      this.lock = null;
      this.refresh();
      return true;
    }
    return false;
  }

  down(p: PointerInfo): void {
    if (p.button !== 0) return;
    this.move(p);
    const s = this.hover;
    if (!s) return;
    if (!this.start) {
      this.start = s.point.clone();
      this.first = s.point.clone();
      this.app.setHint();
      return;
    }
    this.segmentTo(s.point, s.kind === 'close');
  }

  private segmentTo(end: Vector3, closing: boolean): void {
    if (!this.start || end.distanceTo(this.start) < 1e-4) return;
    const res = this.commit(t('Line'), [[this.start, end]]);
    if (!res.faces.length) {
      // A closed loop whose corners are slightly off one plane: close it
      // anyway, or say why no face appears.
      const app = this.app;
      const tx = app.history.begin(t('Close Face')).track(app.mesh);
      const cam = app.toLocalDir(app.vp.rig.position.clone().sub(end).normalize());
      const near = closeNearPlanar(app.mesh, res.edges, { orientHint: cam });
      if (near.face) {
        tx.commit();
        res.faces.push(near.face);
        if (near.deviation > 2e-4) app.toast(t('Face closed (corners deviate from a plane by {d}).', { d: devText(near.deviation) }));
      } else {
        tx.rollback();
        if (Number.isFinite(near.deviation) && (closing || near.deviation < 0.3))
          app.toast(t('No face: the outline is not planar (deviation {d}).', { d: devText(near.deviation) }), 'warn');
      }
    }
    if (closing || res.faces.length) {
      this.reset();
      return;
    }
    this.start = end.clone();
    this.lock = null;
    this.refresh();
  }

  value(text: string): boolean {
    if (!this.start || !this.hover) return false;
    const len = parseLength(text);
    if (len === null) return false;
    const dir = this.hover.point.clone().sub(this.start);
    if (dir.length() < 1e-9) return false;
    dir.normalize();
    this.segmentTo(this.start.clone().addScaledVector(dir, len), false);
    return true;
  }

  dbl(): void {
    this.reset();
  }

  private reset(): void {
    this.start = null;
    this.first = null;
    this.lock = null;
    this.app.vp.setPreview([]);
    this.app.setHint();
    this.refresh();
  }

  cancel(): boolean {
    if (!this.start) return false;
    this.reset();
    return true;
  }
}

/** Common to Rectangle/Circle/Polygon: a first click fixes a point and a plane. */
abstract class PlaneTool extends DrawTool {
  protected anchor: Vector3 | null = null;
  protected normal = new Vector3(0, 0, 1);
  protected hover: Snap | null = null;
  protected cur: Vector3 | null = null;

  protected planeFrom(s: Snap): Vector3 {
    if (s.normal && (s.kind === 'face' || s.face)) return s.normal.clone().normalize();
    return new Vector3(0, 0, 1);
  }

  protected planeNow(): Plane {
    return Plane.fromPointNormal(this.anchor!, this.normal);
  }

  move(p: PointerInfo): void {
    super.move(p);
    const app = this.app;
    if (!this.anchor) {
      const s = app.inference.find(p.x, p.y, { guides: app.guides });
      this.hover = s;
      showSnap(this.app, s, p);
      this.normal = this.planeFrom(s);
      return;
    }
    const plane = this.planeNow();
    const s = app.inference.find(p.x, p.y, { ref: this.anchor, plane, guides: app.guides, noAxis: true });
    this.hover = s;
    // Keep the point in the drawing plane.
    let q = s.point.clone().addScaledVector(plane.n, -plane.dist(s.point));
    if (s.kind === 'face' || s.kind === 'ground' || s.kind === 'free') {
      const { origin, dir } = app.vp.ray(p.x, p.y);
      const hitp = plane.intersectRay(origin, dir);
      if (hitp && s.kind !== 'face') q = hitp;
    }
    this.cur = q;
    showSnap(this.app, s, p);
    this.preview();
  }

  protected abstract preview(): void;

  down(p: PointerInfo): void {
    if (p.button !== 0) return;
    this.move(p);
    if (!this.anchor) {
      if (!this.hover) return;
      this.anchor = this.hover.point.clone();
      this.app.setHint();
      return;
    }
    this.finish();
  }

  protected abstract finish(): void;

  protected reset(): void {
    this.anchor = null;
    this.cur = null;
    this.app.vp.setPreview([]);
    this.app.vp.setLabels([]);
    this.app.setHint();
  }

  cancel(): boolean {
    if (!this.anchor) return false;
    this.reset();
    return true;
  }
}

export class RectangleTool extends PlaneTool {
  readonly id = 'rectangle';
  readonly name = t('Rectangle');
  readonly shortcut = 'r';
  vcbLabel = t('Dimensions');
  private dims: [number, number] = [0, 0];

  hint(): string {
    return this.anchor
      ? t('Click the opposite corner or type width;height (e.g. 4;3 or 400cm;3m).')
      : t('Click the first corner (on the ground or on a face).');
  }

  private corners(du: number, dv: number): Vector3[] {
    const [u, v] = planeBasis(this.normal);
    const a = this.anchor!;
    return [a.clone(), a.clone().addScaledVector(u, du), a.clone().addScaledVector(u, du).addScaledVector(v, dv), a.clone().addScaledVector(v, dv)];
  }

  protected preview(): void {
    if (!this.anchor || !this.cur) return;
    const [u, v] = planeBasis(this.normal);
    const d = this.cur.clone().sub(this.anchor);
    this.dims = [d.dot(u), d.dot(v)];
    const cs = this.corners(...this.dims);
    const sq = Math.abs(Math.abs(this.dims[0]) - Math.abs(this.dims[1])) < 0.02 * Math.max(Math.abs(this.dims[0]), 1e-6);
    this.app.vp.setPreview(
      cs.map((c, i) => ({ a: c, b: cs[(i + 1) % 4], color: sq ? '#c50' : '#222', width: 2 })),
      [{ pts: cs, opacity: 0.12 }],
    );
    this.app.showValue(`${formatLength(Math.abs(this.dims[0]))}; ${formatLength(Math.abs(this.dims[1]))}`);
    if (sq) this.app.vp.setTip(t('Square'));
  }

  protected finish(): void {
    const [du, dv] = this.dims;
    if (Math.abs(du) < 1e-4 || Math.abs(dv) < 1e-4) return;
    const cs = this.corners(du, dv);
    this.commit(t('Rectangle'), loopSegments(cs), { plane: this.planeNow() });
    this.reset();
  }

  value(text: string): boolean {
    if (!this.anchor) return false;
    const parts = splitValues(text, 2);
    if (parts.length !== 2) return false;
    const w = parseLength(parts[0]);
    const h = parseLength(parts[1]);
    if (w === null || h === null) return false;
    this.dims = [w * (Math.sign(this.dims[0]) || 1), h * (Math.sign(this.dims[1]) || 1)];
    this.finish();
    return true;
  }
}

export class CircleTool extends PlaneTool {
  readonly id: string = 'circle';
  readonly name: string = t('Circle');
  readonly shortcut: string = 'c';
  vcbLabel = t('Radius');
  segments = 24;
  protected polygon = false;

  hint(): string {
    return this.anchor
      ? t('Click or type the radius. “{n}s” changes the number of segments.', { n: this.segments })
      : t('Click the centre ({n} segments).', { n: this.segments });
  }

  protected points(radius?: number): Vector3[] {
    if (!this.anchor || !this.cur) return [];
    let rp = this.cur;
    if (radius !== undefined) {
      const d = this.cur.clone().sub(this.anchor);
      if (d.length() < 1e-9) d.copy(planeBasis(this.normal)[0]);
      rp = this.anchor.clone().addScaledVector(d.normalize(), radius);
    }
    return circlePoints(this.anchor, this.normal, rp, this.segments);
  }

  protected preview(): void {
    const pts = this.points();
    if (!pts.length) return;
    this.app.vp.setPreview(
      [...pts.map((c, i) => ({ a: c, b: pts[(i + 1) % pts.length], color: '#222', width: 2 })), { a: this.anchor!, b: this.cur!, color: '#888', width: 1, dashed: true }],
      [{ pts, opacity: 0.12 }],
    );
    this.app.showValue(formatLength(this.anchor!.distanceTo(this.cur!)));
  }

  protected finish(radius?: number): void {
    const pts = this.points(radius);
    if (pts.length < 3) return;
    this.commit(this.polygon ? t('Polygon') : t('Circle'), loopSegments(pts), { plane: this.planeNow(), curve: !this.polygon });
    this.reset();
  }

  value(text: string): boolean {
    const seg = /^(\d+)\s*s$/i.exec(text.trim());
    if (seg) {
      this.segments = Math.max(3, Math.min(720, Number(seg[1])));
      this.app.setHint();
      this.refresh();
      return true;
    }
    if (!this.anchor) return false;
    const r = parseLength(text);
    if (r === null || r <= 0) return false;
    this.finish(r);
    return true;
  }
}

export class PolygonTool extends CircleTool {
  readonly id = 'polygon';
  readonly name = t('Polygon');
  readonly shortcut = '';
  segments = 6;
  protected polygon = true;
}
