// SPDX-License-Identifier: GPL-3.0-or-later
// IngeTrazo Web — the application shell: input, menus, files, autosave.
// ``startApp`` builds it; extensions plug in through ``src/ext.ts``.
import './style.css';
import { Vector2 } from 'three';
import { App } from './app';
import { Model } from './core/scene';
import { settings, type LengthUnit } from './core/units';
import { clearAutosave, readAutosave, writeAutosave } from './io/autosave';
import { download, exportGLTF, exportOBJ, exportSTL, importOBJ, importSTL } from './io/exchange';
import { loadIgz, saveIgz } from './io/igz';
import { importGLTF } from './io/gltf';
import type { PointerInfo } from './tools/base';
import { CircleTool, LineTool, PolygonTool, RectangleTool } from './tools/draw';
import { EraserTool, MoveTool, OrbitTool, PaintTool, PanTool, PushPullTool, RotateTool, TapeTool } from './tools/modify';
import { SelectTool } from './tools/select';
import { type Action, buildMenus, buildToolbar, buildTray, dialog, showContextMenu } from './ui/ui';
import type { StdView, ViewSpec } from './view/camera';
import { type Extension, loadExtensions } from './ext';
import { ICONS } from './ui/icons';
import { APP_HTML } from './ui/shell';
import { LANGS, lang, locale, setLang, t } from './i18n';

/** Key names in the current language (Strg → Ctrl, Umschalt → Shift, …). */
function keys(s: string): string {
  return s.replace(/Ctrl|Shift|Del|Space|Arrow keys|selection|hold/g, (w) => t(w));
}

export type StartOptions = {
  extensions?: Extension[];
  /** Examples under <base>/examples/: [file, label]. */
  examples?: [string, string][];
  /** HTML for the brand next to the logo. */
  brand?: string;
  title?: string;
  /** More menus, placed before *Hilfe* (e.g. the extension manager). */
  menus?: (app: App) => { label: string; items: (Action | '-')[] }[];
};

export function startApp(opts: StartOptions = {}): App {
  try {
    const u = localStorage.getItem('igw-unit');
    if (u === 'm' || u === 'cm' || u === 'mm') settings.unit = u as LengthUnit;
  } catch {
    /* storage blocked */
  }

  document.documentElement.lang = lang;
  if (!document.getElementById('app')) document.body.insertAdjacentHTML('afterbegin', APP_HTML);
  if (opts.brand) document.querySelector('.brand span')!.innerHTML = opts.brand;
  const canvas = document.getElementById('canvas') as HTMLCanvasElement;
  const app = new App(canvas);
  app.vcbInput = document.getElementById('vcb-input') as HTMLInputElement;
  app.vcbLabel = document.getElementById('vcb-label')!;
  app.hintEl = document.getElementById('hint')!;

  for (const T of [SelectTool, LineTool, RectangleTool, CircleTool, PolygonTool, PushPullTool, MoveTool, RotateTool, EraserTool, PaintTool, TapeTool, OrbitTool, PanTool])
    app.register(new T(app));
  const contrib = loadExtensions(app, opts.extensions ?? []);
  app.setTool('select');

  // ---- Files ---------------------------------------------------------------------
  let fileHandle: FileSystemFileHandle | null = null;
  const EXAMPLES: [string, string][] = opts.examples ?? [
    ['banca-pergola-yanque.igz', t('Bench with pergola (Yanque)')],
    ['luminaria-solar-yanque.igz', t('Solar street light (Yanque)')],
    ['arco-yanque.igz', t('Welcome arch with reinforcement (Yanque)')],
    ['pileta-fuente-yanque.igz', t('Fountain (Yanque)')],
  ];

  /** The document name; the model's German default is shown translated. */
  const docName = () => (!app.model.name || app.model.name === 'Untitled' ? t('Untitled') : app.model.name);

  function setTitle(): void {
    const title = `${docName()}${app.dirty ? ' •' : ''}`;
    document.getElementById('doc-title')!.textContent = title;
    document.title = `${title} – ${opts.title ?? 'IngeTrazo Web'}`;
  }
  app.on((w) => (w === 'history' || w === 'document') && setTitle());

  async function confirmDiscard(): Promise<boolean> {
    if (!app.dirty) return true;
    const r = await dialog(t('Unsaved changes'), t('The current model has unsaved changes. Discard them?'), [
      { label: t('Cancel'), value: 'cancel' },
      { label: t('Discard'), value: 'ok', primary: true },
    ]);
    return r === 'ok';
  }

  async function newDocument(): Promise<void> {
    if (!(await confirmDiscard())) return;
    fileHandle = null;
    app.setModel(new Model());
    void clearAutosave();
  }

  async function openBytes(bytes: Uint8Array, name: string): Promise<void> {
    const lower = name.toLowerCase();
    if (lower.endsWith('.stl') || lower.endsWith('.obj')) {
      await importMesh(bytes, name);
      return;
    }
    if (lower.endsWith('.glb') || lower.endsWith('.gltf')) {
      await importGltfFile(bytes, name);
      return;
    }
    try {
      const m = await loadIgz(bytes, name);
      app.setModel(m);
      app.toast(t('Opened: {name}', { name }));
    } catch (e) {
      app.toast(t('Opening failed: {msg}', { msg: (e as Error).message }), 'warn');
    }
  }

  async function importMesh(bytes: Uint8Array, name: string): Promise<void> {
    const body = document.createElement('div');
    body.innerHTML = `<p>${t('Which unit is {name} saved in?', { name: `<b>${escapeHtml(name)}</b>` })}</p>`;
    const r = await dialog(t('Import mesh'), body, [
      { label: t('Cancel'), value: 'cancel' },
      { label: t('Millimetres'), value: '0.001', primary: true },
      { label: t('Centimetres'), value: '0.01' },
      { label: t('Metres'), value: '1' },
    ]);
    if (r === 'cancel') return;
    const scale = Number(r);
    const tx = app.history.begin(t('Import')).structure();
    const base = name.replace(/\.[^.]+$/, '');
    const g = name.toLowerCase().endsWith('.stl')
      ? importSTL(bytes.slice().buffer as ArrayBuffer, scale, base)
      : importOBJ(new TextDecoder().decode(bytes), scale, base, true);
    g.parent = app.context;
    app.contextGroups.push(g);
    app.model.touch();
    tx.commit();
    app.clearSelection();
    app.sel.groups.add(g);
    app.selectionChanged();
    app.zoomExtents();
    app.toast(t('Imported: {n} faces', { n: g.mesh.faces.size }));
  }

  async function importGltfFile(bytes: Uint8Array, name: string): Promise<void> {
    app.toast(t('Importing {name}…', { name }));
    try {
      const tx = app.history.begin(t('Import glTF')).structure();
      const res = await importGLTF(bytes, name.replace(/\.[^.]+$/, ''), app.model);
      const g = res.group;
      g.parent = app.context;
      app.contextGroups.push(g);
      app.model.touch();
      tx.commit();
      app.clearSelection();
      app.sel.groups.add(g);
      app.selectionChanged();
      app.zoomExtents();
      app.emit('document');
      const tex = res.textures ? t(', {n} textures', { n: res.textures }) : '';
      app.toast(t('Imported: {meshes} meshes, {tris} triangles', { meshes: res.meshes, tris: res.triangles }) + tex);
    } catch (e) {
      app.toast(t('glTF import failed: {msg}', { msg: (e as Error).message }), 'warn');
    }
  }

  function escapeHtml(s: string): string {
    return s.replace(/[&<>"']/g, (c) => `&#${c.charCodeAt(0)};`);
  }

  async function openFile(): Promise<void> {
    if (!(await confirmDiscard())) return;
    const w = window as unknown as { showOpenFilePicker?: (o: unknown) => Promise<FileSystemFileHandle[]> };
    if (w.showOpenFilePicker) {
      try {
        const [h] = await w.showOpenFilePicker({
          types: [{ description: t('IngeTrazo document'), accept: { 'application/octet-stream': ['.igz'] } }],
        });
        const f = await h.getFile();
        fileHandle = h;
        await openBytes(new Uint8Array(await f.arrayBuffer()), f.name);
      } catch {
        /* cancelled */
      }
      return;
    }
    const input = document.getElementById('file-open') as HTMLInputElement;
    input.accept = '.igz,.json';
    input.onchange = async () => {
      const f = input.files?.[0];
      input.value = '';
      if (!f) return;
      fileHandle = null;
      await openBytes(new Uint8Array(await f.arrayBuffer()), f.name);
    };
    input.click();
  }

  async function importFile(): Promise<void> {
    const input = document.getElementById('file-open') as HTMLInputElement;
    input.accept = '.glb,.gltf,.stl,.obj';
    input.onchange = async () => {
      const f = input.files?.[0];
      input.value = '';
      if (f) await openBytes(new Uint8Array(await f.arrayBuffer()), f.name);
    };
    input.click();
  }

  async function save(as = false): Promise<void> {
    const blob = await saveIgz(app.model);
    const name = `${docName()}.igz`;
    const w = window as unknown as { showSaveFilePicker?: (o: unknown) => Promise<FileSystemFileHandle> };
    if (w.showSaveFilePicker) {
      try {
        if (!fileHandle || as) {
          fileHandle = await w.showSaveFilePicker({
            suggestedName: name,
            types: [{ description: t('IngeTrazo document'), accept: { 'application/octet-stream': ['.igz'] } }],
          });
          app.model.name = fileHandle.name.replace(/\.igz$/i, '');
        }
        const ws = await fileHandle.createWritable();
        await ws.write(blob);
        await ws.close();
      } catch {
        return;
      }
    } else download(blob, name);
    app.dirty = false;
    setTitle();
    app.toast(t('Saved: {name}', { name: `${app.model.name}.igz` }));
  }

  async function openExample(file: string): Promise<void> {
    if (!(await confirmDiscard())) return;
    app.toast(t('Loading example…'));
    const res = await fetch(`${import.meta.env.BASE_URL}examples/${file}`);
    if (!res.ok) {
      app.toast(t('Example not found.'), 'warn');
      return;
    }
    fileHandle = null;
    await openBytes(new Uint8Array(await res.arrayBuffer()), file);
  }

  async function exportAs(kind: 'glb' | 'gltf' | 'stl' | 'obj'): Promise<void> {
    const base = app.model.name || t('model');
    try {
      if (kind === 'glb') download(await exportGLTF(app.model, app.vp.materials, true), `${base}.glb`);
      if (kind === 'gltf') download(await exportGLTF(app.model, app.vp.materials, false), `${base}.gltf`);
      if (kind === 'stl') download(exportSTL(app.model, app.vp.materials), `${base}.stl`);
      if (kind === 'obj') download(exportOBJ(app.model, app.vp.materials), `${base}.obj`);
    } catch (e) {
      app.toast(t('Export failed: {msg}', { msg: (e as Error).message }), 'warn');
    }
  }

  // ---- View --------------------------------------------------------------------------
  let style = 'default';
  const view = {
    style: () => style,
    setStyle(s: string) {
      style = s;
      app.vp.materials.setXray(s === 'xray');
      app.vp.showEdges = s !== 'noedges';
      app.vp.setContext(app.context);
      app.emit('view');
    },
    setView(v: ViewSpec) {
      const b = app.model.bounds();
      app.vp.rig.setView(v, b?.min, b?.max);
      app.vp.invalidate();
      app.tool.refresh();
    },
  };

  // ---- Menus ---------------------------------------------------------------------------
  const hasSel = () => !app.selectionEmpty();
  const hasGroupSel = () => app.sel.groups.size > 0;
  const tool = (id: string, key: string): Action => ({ label: app.tools.get(id)!.name, key: keys(key), run: () => app.setTool(id) });

  const editItems: (Action | '-')[] = [
    { label: t('Undo'), key: keys('Ctrl+Z'), run: () => app.history.undo(), enabled: () => app.history.canUndo },
    { label: t('Redo'), key: keys('Ctrl+Y'), run: () => app.history.redo(), enabled: () => app.history.canRedo },
    '-',
    { label: t('Select All'), key: keys('Ctrl+A'), run: () => app.selectAll() },
    { label: t('Select None'), key: 'Esc', run: () => app.clearSelection(), enabled: hasSel },
    { label: t('Delete'), key: keys('Del'), run: () => app.deleteSelection(), enabled: hasSel },
    '-',
    { label: t('Make Group'), key: 'G', run: () => app.makeGroup(), enabled: hasSel },
    { label: t('Make Component'), key: keys('Shift+G'), run: () => app.makeGroup(true), enabled: hasSel },
    { label: t('Edit Group'), run: () => app.enterGroup([...app.sel.groups][0]), enabled: () => app.sel.groups.size === 1 },
    { label: t('Close Group'), run: () => app.exitContext(), enabled: () => !!app.context },
    { label: t('Explode'), run: () => app.explode(), enabled: hasGroupSel },
    { label: t('Make Unique'), run: () => app.makeUnique(), enabled: hasGroupSel },
    '-',
    { label: t('Toggle Hole / Solid'), key: keys('Shift+B'), run: () => app.toggleHole(), enabled: hasGroupSel },
    { label: t('Combine (subtract holes)'), key: keys('Ctrl+G'), run: () => void app.combineSelection(), enabled: () => app.sel.groups.size > 1 },
    '-',
    { label: t('Hide'), key: keys('Shift+H'), run: () => app.hideSelection(), enabled: hasSel },
    { label: t('Unhide All'), run: () => app.unhideAll() },
    { label: t('Reverse Faces'), run: () => app.reverseFaces(), enabled: () => app.sel.faces.size > 0 },
  ];

  buildMenus([
    {
      label: t('File'),
      items: [
        { label: t('New'), key: keys('Ctrl+N'), run: () => void newDocument() },
        { label: t('Open…'), key: keys('Ctrl+O'), run: () => void openFile() },
        { label: t('Save'), key: keys('Ctrl+S'), run: () => void save() },
        { label: t('Save As…'), key: keys('Ctrl+Shift+S'), run: () => void save(true) },
        '-',
        ...EXAMPLES.map(([f, label]) => ({ label: t('Example: {name}', { name: label }), run: () => void openExample(f) })),
        '-',
        { label: t('Import (GLB, glTF, STL, OBJ)…'), run: () => void importFile() },
        { label: t('Export as GLB…'), run: () => void exportAs('glb') },
        { label: t('Export as glTF…'), run: () => void exportAs('gltf') },
        { label: t('Export as STL…'), run: () => void exportAs('stl') },
        { label: t('Export as OBJ…'), run: () => void exportAs('obj') },
        { label: t('View as PNG…'), run: () => fetch(app.vp.snapshot()).then((r) => r.blob()).then((b) => download(b, `${app.model.name}.png`)) },
      ],
    },
    { label: t('Edit'), items: editItems },
    {
      label: t('View'),
      items: [
        { label: t('Zoom Extents'), key: keys('Shift+Z'), run: () => app.zoomExtents() },
        { label: t('Parallel Projection'), key: 'V', checked: () => app.vp.rig.parallel, run: () => toggleParallel() },
        '-',
        { label: t('Iso'), key: keys('0 (selection)'), run: () => view.setView('iso') },
        { label: t('Top'), key: '1', run: () => view.setView('top') },
        { label: t('Front'), key: '2', run: () => view.setView('front') },
        { label: t('Right'), key: '3', run: () => view.setView('right') },
        { label: t('Back'), key: '4', run: () => view.setView('back') },
        { label: t('Left'), key: '5', run: () => view.setView('left') },
        '-',
        { label: t('Default'), checked: () => style === 'default', run: () => view.setStyle('default') },
        { label: t('X-Ray'), key: 'X', checked: () => style === 'xray', run: () => view.setStyle(style === 'xray' ? 'default' : 'xray') },
        { label: t('No Edges'), checked: () => style === 'noedges', run: () => view.setStyle('noedges') },
        '-',
        { label: t('Sidebar'), run: () => document.getElementById('app')!.classList.toggle('tray-open') },
      ],
    },
    {
      label: t('Draw'),
      items: [tool('line', 'L'), tool('rectangle', 'R'), tool('circle', 'C'), tool('polygon', '')],
    },
    {
      label: t('Tools'),
      items: [
        tool('select', 'Space'),
        tool('pushpull', 'P'),
        tool('move', 'M'),
        tool('rotate', 'Q'),
        tool('eraser', 'E'),
        tool('paint', 'B'),
        tool('tape', 'T'),
        '-',
        tool('orbit', 'O'),
        tool('pan', 'H'),
      ],
    },
    ...contrib.menus,
    ...(opts.menus?.(app) ?? []),
    {
      label: t('Language'),
      items: LANGS.map(({ id, name }) => ({ label: name, checked: () => lang === id, run: () => setLang(id) })),
    },
    {
      label: t('Help'),
      items: [
        { label: t('Keyboard Shortcuts'), key: 'F1', run: () => void showShortcuts() },
        { label: t('About IngeTrazo Web'), run: () => void showAbout() },
      ],
    },
  ]);

  function toggleParallel(): void {
    app.vp.rig.setParallel(!app.vp.rig.parallel);
    app.vp.invalidate();
    app.emit('view');
  }

  for (const c of contrib.tools) ICONS[c.tool.id] = c.icon;
  buildToolbar(app, contrib.tools.map((c) => c.tool.id), [
    { icon: 'extents', label: `${t('Zoom Extents')} (${keys('Shift+Z')})`, run: () => app.zoomExtents() },
    { icon: 'undo', label: `${t('Undo')} (${keys('Ctrl+Z')})`, run: () => app.history.undo() },
    { icon: 'redo', label: `${t('Redo')} (${keys('Ctrl+Y')})`, run: () => app.history.redo() },
  ]);
  buildTray(app, view, contrib.panels);
  app.vp.onViewPick = (v) => view.setView(v);
  app.vp.onCubeOrbit = () => app.tool.refresh();
  app.on((w) => w === 'guides' && app.vp.setGuides(app.guides));

  function showShortcuts(): Promise<string> {
    const rows: [string, string][] = [
      [keys('Space'), t('Select')],
      ['L / R / C', t('Line / Rectangle / Circle')],
      ['P', t('Push/Pull (Ctrl = copy, double-click = last distance)')],
      ['M / Q', t('Move / Rotate (Ctrl = copy, then “3x” = array)')],
      ['E / B / T', t('Eraser / Paint Bucket / Tape Measure')],
      ['O / H', t('Orbit / Pan')],
      [t('Middle mouse button'), t('Orbit around the point under the cursor (Shift = pan)')],
      [t('Right mouse button drag'), t('Pan')],
      [t('Mouse wheel'), t('Zoom to cursor')],
      [keys('Shift+Z'), t('Zoom Extents')],
      ['0 … 5', t('Iso, Top, Front, Right, Back, Left')],
      ['V / X', t('Parallel projection / X-ray')],
      [keys('Shift (hold)'), t('Lock direction')],
      [keys('Arrow keys'), t('Lock axis: → red, ← green, ↑ blue')],
      [t('Numbers + Enter'), t('Exact value, e.g. 2.5 · 250cm · 4;3 · 24s')],
      [keys('G / Shift+G'), t('Make group / component')],
      [keys('Shift+B / Ctrl+G'), t('Toggle hole / Combine (Explode brings the parts back)')],
      [t('Double-click a group'), t('Edit group (Esc leaves it)')],
      [keys('Del'), t('Delete selection')],
      [keys('Ctrl+Z / Ctrl+Y'), t('Undo / Redo')],
      [keys('Ctrl+S / Ctrl+O'), t('Save / Open (.igz)')],
    ];
    const table = document.createElement('table');
    for (const [k, v] of rows) {
      const tr = table.insertRow();
      tr.insertCell().textContent = k;
      tr.insertCell().textContent = v;
    }
    return dialog(t('Keyboard Shortcuts'), table);
  }

  function showAbout(): Promise<string> {
    return dialog(
      'IngeTrazo Web',
      `<p>${t('Free 3D modeller for architecture, engineering and design in the browser: draw as if by hand, with Push/Pull.')}</p>
       <p>${t('This web app ports concepts and the {igz} file format of {link} (© 2026 Marco Sumari Tellez and contributors) to TypeScript and three.js.', {
         igz: '<b>.igz</b>',
         link: '<a href="https://github.com/ingelibre/ingetrazo" target="_blank" rel="noopener">IngeTrazo</a>',
       })}</p>
       <p>${t('Licence: GPL-3.0-or-later. Everything runs locally in the browser; documents never leave your computer.')}</p>
       <p class="muted">${t('Example documents: Plaza Yanque, from the IngeTrazo repository.')}</p>`,
    );
  }

  // ---- Pointer input -------------------------------------------------------------------
  function info(e: PointerEvent | MouseEvent): PointerInfo {
    const r = canvas.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top, button: e.button, shift: e.shiftKey, ctrl: e.ctrlKey || e.metaKey, alt: e.altKey };
  }

  type Nav = { mode: 'orbit' | 'pan'; prev: Vector2; pivot?: import('three').Vector3; moved: number; button: number };
  let nav: Nav | null = null;

  canvas.addEventListener('pointerdown', (e) => {
    canvas.focus({ preventScroll: true });
    document.getElementById('ctxmenu')!.hidden = true;
    const p = info(e);
    canvas.setPointerCapture(e.pointerId);
    if (e.button === 1 || e.button === 2) {
      e.preventDefault();
      const hit = app.vp.pick(p.x, p.y, { anyContext: true });
      nav = { mode: e.button === 2 || e.shiftKey ? 'pan' : 'orbit', prev: new Vector2(p.x, p.y), pivot: hit?.point, moved: 0, button: e.button };
      return;
    }
    app.tool.down(p);
  });

  canvas.addEventListener('pointermove', (e) => {
    const p = info(e);
    app.lastPointer = p;
    if (nav) {
      const d = new Vector2(p.x, p.y).sub(nav.prev);
      nav.prev.set(p.x, p.y);
      nav.moved += Math.abs(d.x) + Math.abs(d.y);
      if (nav.mode === 'orbit') app.vp.rig.orbit(d.x, d.y, nav.pivot);
      else app.vp.rig.pan(d.x, d.y, nav.pivot);
      app.vp.invalidate();
      return;
    }
    app.tool.move(p);
  });

  canvas.addEventListener('pointerup', (e) => {
    const p = info(e);
    if (nav) {
      const wasClick = nav.button === 2 && nav.moved < 4;
      nav = null;
      app.tool.refresh();
      if (wasClick) contextMenu(e.clientX, e.clientY, p);
      return;
    }
    app.tool.up(p);
  });
  canvas.addEventListener('contextmenu', (e) => e.preventDefault());
  canvas.addEventListener('dblclick', (e) => app.tool.dbl(info(e)));
  canvas.addEventListener('pointerleave', () => {
    app.vp.setMarker(null);
    app.vp.setTip(null);
  });

  canvas.addEventListener(
    'wheel',
    (e) => {
      e.preventDefault();
      const p = info(e);
      const trackpadPan = !e.ctrlKey && (Math.abs(e.deltaX) > 0.5 || (e.deltaMode === 0 && !Number.isInteger(e.deltaY)));
      if (trackpadPan) {
        // Two-finger scroll on a trackpad: orbit (Shift = pan).
        if (e.shiftKey) app.vp.rig.pan(-e.deltaX, -e.deltaY);
        else app.vp.rig.orbit(-e.deltaX * 0.6, -e.deltaY * 0.6);
      } else {
        const hit = app.vp.pick(p.x, p.y, { anyContext: true });
        let at = hit?.point;
        if (!at) {
          const { origin, dir } = app.vp.ray(p.x, p.y);
          const d = origin.distanceTo(app.vp.rig.target);
          at = origin.clone().addScaledVector(dir, d);
        }
        const k = e.ctrlKey ? 0.01 : e.deltaMode === 1 ? 0.05 : 0.0015;
        app.vp.rig.zoom(Math.exp(e.deltaY * k), at);
      }
      app.vp.invalidate();
      app.tool.refresh();
    },
    { passive: false },
  );

  function contextMenu(cx: number, cy: number, p: PointerInfo): void {
    const hit = app.vp.pick(p.x, p.y);
    if (app.selectionEmpty() && hit) {
      if (hit.group) app.sel.groups.add(hit.group);
      else if (hit.face) app.sel.faces.add(hit.face);
      app.selectionChanged();
    }
    const items: (Action | '-')[] = [
      { label: t('Edit Group'), run: () => app.enterGroup([...app.sel.groups][0]), enabled: () => app.sel.groups.size === 1 },
      { label: t('Close Group'), run: () => app.exitContext(), enabled: () => !!app.context },
      { label: t('Make Group'), key: 'G', run: () => app.makeGroup(), enabled: hasSel },
      { label: t('Make Component'), run: () => app.makeGroup(true), enabled: hasSel },
      { label: t('Explode'), run: () => app.explode(), enabled: hasGroupSel },
      { label: t('Toggle Hole / Solid'), key: keys('Shift+B'), run: () => app.toggleHole(), enabled: hasGroupSel },
      { label: t('Combine (subtract holes)'), key: keys('Ctrl+G'), run: () => void app.combineSelection(), enabled: () => app.sel.groups.size > 1 },
      { label: t('Reverse Faces'), run: () => app.reverseFaces(), enabled: () => app.sel.faces.size > 0 },
      { label: t('Hide'), run: () => app.hideSelection(), enabled: hasSel },
      { label: t('Delete'), key: keys('Del'), run: () => app.deleteSelection(), enabled: hasSel },
      '-',
      { label: t('Zoom Extents'), key: keys('Shift+Z'), run: () => app.zoomExtents() },
    ];
    showContextMenu(cx, cy, items);
  }

  // ---- Keyboard ------------------------------------------------------------------------
  const vcb = app.vcbInput;
  vcb.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      const text = vcb.value.trim();
      if (text && !app.tool.value(text)) app.toast(t('“{text}” is not understood here.', { text }), 'warn');
      vcb.value = '';
      canvas.focus();
    } else if (e.key === 'Escape') {
      vcb.value = '';
      canvas.focus();
      app.tool.cancel();
    }
    e.stopPropagation();
  });

  const SHORTCUTS: Record<string, string> = {
    ...Object.fromEntries(contrib.tools.filter((t) => t.tool.shortcut).map((t) => [t.tool.shortcut, t.tool.id])),
    ' ': 'select', l: 'line', r: 'rectangle', c: 'circle', p: 'pushpull', m: 'move', q: 'rotate', e: 'eraser', b: 'paint', t: 'tape', o: 'orbit', h: 'pan' };
  const VIEW_KEYS: Record<string, StdView> = { '0': 'iso', '1': 'top', '2': 'front', '3': 'right', '4': 'back', '5': 'left' };

  window.addEventListener('keydown', (e) => {
    const target = e.target as HTMLElement;
    if (target !== canvas && target !== document.body && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'SELECT')) return;
    if (document.querySelector('dialog[open]')) return;
    const mod = e.ctrlKey || e.metaKey;
    const k = e.key.toLowerCase();
    if (mod) {
      if (k === 'z' && !e.shiftKey) app.history.undo();
      else if (k === 'y' || (k === 'z' && e.shiftKey)) app.history.redo();
      else if (k === 's') void save(e.shiftKey);
      else if (k === 'o') void openFile();
      else if (k === 'n') void newDocument();
      else if (k === 'a') app.selectAll();
      else if (k === 'g') void app.combineSelection();
      else {
        app.tool.key(e);
        return;
      }
      e.preventDefault();
      return;
    }
    // Typed values go to the VCB.
    if (app.tool.vcbLabel && /^[0-9.,;\-x*/]$/i.test(e.key)) {
      vcb.focus();
      vcb.value = e.key;
      e.preventDefault();
      return;
    }
    if (e.key === 'Escape') {
      if (!app.tool.cancel()) {
        if (app.tool.id !== 'select') app.setTool('select');
        else app.tool.key(e);
      }
      e.preventDefault();
      return;
    }
    if (app.tool.key(e)) {
      e.preventDefault();
      return;
    }
    if (e.key === 'Delete' || e.key === 'Backspace') {
      app.deleteSelection();
      e.preventDefault();
      return;
    }
    if (e.key === 'F1') {
      e.preventDefault();
      void showShortcuts();
      return;
    }
    if (e.shiftKey && k === 'z') return app.zoomExtents();
    if (e.shiftKey && k === 'h') return app.hideSelection();
    if (e.shiftKey && k === 'b') return app.toggleHole();
    if (k === 'g') return app.makeGroup(e.shiftKey);
    if (k === 'v' && !e.shiftKey) return toggleParallel();
    if (k === 'x' && !e.shiftKey) return view.setStyle(style === 'xray' ? 'default' : 'xray');
    // Digits pick standard views only where they are not values (no VCB).
    if (e.key in VIEW_KEYS) return view.setView(VIEW_KEYS[e.key]);
    const id = SHORTCUTS[e.shiftKey ? '' : k];
    if (id) {
      app.setTool(id);
      e.preventDefault();
    }
  });

  window.addEventListener('keyup', (e) => {
    if (app.tool.keyUp(e)) e.preventDefault();
  });

  // ---- Drag & drop ---------------------------------------------------------------------
  const drop = document.getElementById('drop-hint')!;
  window.addEventListener('dragover', (e) => {
    e.preventDefault();
    drop.hidden = false;
  });
  window.addEventListener('dragleave', (e) => {
    if (!e.relatedTarget) drop.hidden = true;
  });
  window.addEventListener('drop', async (e) => {
    e.preventDefault();
    drop.hidden = true;
    const f = e.dataTransfer?.files?.[0];
    if (!f) return;
    const isMesh = /\.(stl|obj|glb|gltf)$/i.test(f.name);
    if (!isMesh && !(await confirmDiscard())) return;
    fileHandle = null;
    await openBytes(new Uint8Array(await f.arrayBuffer()), f.name);
  });

  // ---- Context bar ----------------------------------------------------------------------
  const bar = document.getElementById('context-bar')!;
  app.on((w) => {
    if (w !== 'context' && w !== 'history') return;
    const g = app.context;
    bar.hidden = !g;
    if (!g) return;
    bar.replaceChildren();
    const label = document.createElement('span');
    label.textContent = t(g.component ? 'Editing component: {name}' : 'Editing group: {name}', { name: g.name });
    const close = document.createElement('button');
    close.type = 'button';
    close.textContent = t('Close');
    close.addEventListener('click', () => app.exitContext());
    bar.append(label, close);
  });

  // ---- Autosave ----------------------------------------------------------------------------
  setInterval(async () => {
    if (!app.dirty) return;
    const blob = await saveIgz(app.model);
    await writeAutosave({ name: app.model.name, time: Date.now(), blob });
  }, 20000);

  window.addEventListener('beforeunload', (e) => {
    if (app.dirty) e.preventDefault();
  });

  void (async () => {
    const saved = await readAutosave();
    setTitle();
    app.zoomExtents();
    if (!saved) return;
    const el = document.createElement('div');
    el.className = 'toast';
    el.textContent = t('Autosaved: “{name}” ({time})', { name: saved.name, time: new Date(saved.time).toLocaleString(locale()) });
    const b = document.createElement('button');
    b.textContent = t('Restore');
    b.addEventListener('click', async () => {
      el.remove();
      await openBytes(new Uint8Array(await saved.blob.arrayBuffer()), `${saved.name}.igz`);
      app.dirty = true;
      setTitle();
    });
    const x = document.createElement('button');
    x.textContent = t('Discard');
    x.addEventListener('click', () => {
      el.remove();
      void clearAutosave();
    });
    el.append(b, x);
    document.getElementById('toasts')!.appendChild(el);
    setTimeout(() => el.remove(), 20000);
  })();

  // Expose for debugging in the console.
  (window as unknown as { ingetrazo: App }).ingetrazo = app;
  return app;
}
