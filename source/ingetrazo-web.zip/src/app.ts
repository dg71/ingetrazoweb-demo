// SPDX-License-Identifier: GPL-3.0-or-later
// IngeTrazo Web — application state and commands: the document, undo
// history, selection, edit context, tools and the Value Control Box.
import { Matrix3, Matrix4, Vector3 } from 'three';
import { History } from './core/history';
import { type Edge, type Face, Mesh } from './core/mesh';
import { CsgError, type Part, combine } from './core/csg';
import { t } from './i18n';
import { closure, copyGeometry, deleteFaces, eraseEdges, extract } from './core/ops';
import { Group, Model } from './core/scene';
import type { PointerInfo, Tool } from './tools/base';
import { Inference } from './tools/inference';
import { Viewport } from './view/viewport';

export type Selection = { faces: Set<Face>; edges: Set<Edge>; groups: Set<Group> };

export type Guides = { points: Vector3[]; lines: { a: Vector3; dir: Vector3 }[] };

export class App {
  model = new Model();
  history = new History(this.model);
  vp: Viewport;
  inference: Inference;
  tools = new Map<string, Tool>();
  tool!: Tool;
  guides: Guides = { points: [], lines: [] };
  dirty = false;
  /** Listeners for UI refresh: selection, tool, document, history. */
  private listeners = new Set<(what: string) => void>();
  vcbInput!: HTMLInputElement;
  vcbLabel!: HTMLElement;
  hintEl!: HTMLElement;
  lastPointer: PointerInfo = { x: 0, y: 0, button: 0, shift: false, ctrl: false, alt: false };

  constructor(canvas: HTMLCanvasElement) {
    this.vp = new Viewport(canvas, () => this.model);
    this.inference = new Inference(this.vp);
    this.history.onChange = () => {
      this.dirty = true;
      this.pruneSelection();
      this.vp.invalidate();
      this.emit('history');
    };
  }

  on(fn: (what: string) => void): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }
  emit(what: string): void {
    for (const l of this.listeners) l(what);
  }

  // ---- Context & selection -------------------------------------------------
  get sel(): Selection {
    return this.vp.selection;
  }
  get context(): Group | null {
    return this.vp.context;
  }
  /** The mesh tools edit right now. */
  get mesh(): Mesh {
    return this.context ? this.context.mesh : this.model.root;
  }
  /** World → context-local transform. */
  toLocal(p: Vector3): Vector3 {
    return p.clone().applyMatrix4(this.vp.contextWorld().invert());
  }
  toLocalDir(d: Vector3): Vector3 {
    const m = new Matrix3().setFromMatrix4(this.vp.contextWorld().invert());
    return d.clone().applyMatrix3(m);
  }
  toWorld(p: Vector3): Vector3 {
    return p.clone().applyMatrix4(this.vp.contextWorld());
  }
  /** Siblings the context holds (top-level groups or the context's children). */
  get contextGroups(): Group[] {
    return this.model.childrenOf(this.context);
  }

  selectionEmpty(): boolean {
    const s = this.sel;
    return !s.faces.size && !s.edges.size && !s.groups.size;
  }

  clearSelection(): void {
    const s = this.sel;
    if (this.selectionEmpty()) return;
    s.faces.clear();
    s.edges.clear();
    s.groups.clear();
    this.selectionChanged();
  }

  selectionChanged(): void {
    this.vp.selectionChanged();
    this.emit('selection');
  }

  /** Drop selected entities that no longer exist (after undo). */
  pruneSelection(): void {
    const s = this.sel;
    const mesh = this.mesh;
    let changed = false;
    for (const f of [...s.faces]) if (!mesh.faces.has(f)) (s.faces.delete(f), (changed = true));
    for (const e of [...s.edges]) if (!mesh.edges.has(e)) (s.edges.delete(e), (changed = true));
    const live = new Set(this.contextGroups);
    for (const g of [...s.groups]) if (!live.has(g)) (s.groups.delete(g), (changed = true));
    if (this.context && !this.isLive(this.context)) {
      this.vp.setContext(null);
      changed = true;
    }
    if (changed) this.selectionChanged();
    else this.vp.selectionChanged();
  }

  private isLive(g: Group): boolean {
    for (const x of this.model.allGroups()) if (x === g) return true;
    return false;
  }

  enterGroup(g: Group): void {
    this.vp.setContext(g);
    this.clearSelection();
    this.emit('context');
    this.setHint();
  }

  exitContext(): void {
    if (!this.context) return;
    const g = this.context;
    this.vp.setContext(g.parent);
    this.clearSelection();
    this.sel.groups.add(g);
    this.selectionChanged();
    this.emit('context');
  }

  // ---- Tools -----------------------------------------------------------------
  register(tool: Tool): void {
    this.tools.set(tool.id, tool);
  }

  setTool(id: string): void {
    const tool = this.tools.get(id);
    if (!tool) return;
    if (this.tool) this.tool.deactivate();
    this.tool = tool;
    this.vp.canvas.style.cursor = tool.cursor;
    tool.activate();
    this.vcbLabel.textContent = tool.vcbLabel || t('Value');
    this.vcbInput.value = '';
    this.vcbInput.disabled = !tool.vcbLabel;
    this.setHint();
    this.emit('tool');
  }

  setHint(text?: string): void {
    this.hintEl.textContent = text ?? this.tool?.hint() ?? '';
  }

  /** Show a value in the VCB (the tool's live measurement). */
  showValue(text: string): void {
    if (document.activeElement !== this.vcbInput) this.vcbInput.value = text;
  }

  toast(text: string, kind: 'info' | 'warn' = 'info'): void {
    const el = document.createElement('div');
    el.className = `toast ${kind}`;
    el.textContent = text;
    document.getElementById('toasts')!.appendChild(el);
    setTimeout(() => el.classList.add('out'), 2600);
    setTimeout(() => el.remove(), 3200);
  }

  // ---- Commands ------------------------------------------------------------------
  deleteSelection(): void {
    const s = this.sel;
    if (this.selectionEmpty()) return;
    const tx = this.history.begin(t('Delete')).track(this.mesh);
    if (s.groups.size) {
      tx.structure();
      const list = this.contextGroups;
      for (const g of s.groups) {
        const i = list.indexOf(g);
        if (i >= 0) list.splice(i, 1);
      }
      this.model.touch();
    }
    const faces = [...s.faces];
    const edges = [...s.edges];
    if (edges.length) eraseEdges(this.mesh, edges);
    deleteFaces(this.mesh, faces.filter((f) => this.mesh.faces.has(f)));
    tx.commit();
    this.clearSelection();
  }

  selectAll(): void {
    const s = this.sel;
    for (const f of this.mesh.faces) s.faces.add(f);
    for (const e of this.mesh.edges) s.edges.add(e);
    for (const g of this.contextGroups) if (!g.hidden && !g.locked) s.groups.add(g);
    this.selectionChanged();
  }

  makeGroup(component = false): void {
    const s = this.sel;
    if (this.selectionEmpty()) {
      this.toast(t('Select something first.'), 'warn');
      return;
    }
    // As in Tinkercad: grouping with a hole among the groups cuts it out.
    if (!component && [...s.groups].some(isHole)) {
      void this.combineSelection();
      return;
    }
    const tx = this.history.begin(component ? t('Make Component') : t('Make Group')).track(this.mesh).structure();
    const g = new Group(undefined, undefined);
    g.component = component;
    const num = /(\d+)$/.exec(g.name)?.[1];
    if (component && num) g.name = t('Component {n}', { n: num });
    const { faces, edges } = closure(this.mesh, s.faces, s.edges);
    copyGeometry(this.mesh, g.mesh, faces, edges, new Matrix4());
    extract(this.mesh, faces, edges);
    const list = this.contextGroups;
    for (const c of s.groups) {
      const i = list.indexOf(c);
      if (i >= 0) list.splice(i, 1);
      c.parent = g;
      g.children.push(c);
    }
    g.parent = this.context;
    list.push(g);
    this.model.touch();
    tx.commit();
    this.clearSelection();
    s.groups.add(g);
    this.selectionChanged();
  }

  explode(): void {
    const groups = [...this.sel.groups];
    if (!groups.length) return;
    const tx = this.history.begin(t('Explode')).track(this.mesh).structure();
    const list = this.contextGroups;
    const s = this.sel;
    s.groups.clear();
    for (const g of groups) {
      if (g.extra.csg) {
        // A combined body: its solids and holes come back as they were.
        const i = list.indexOf(g);
        if (i >= 0) list.splice(i, 1);
        for (const c of g.children) {
          c.matrix.premultiply(g.matrix);
          c.parent = this.context;
          c.hidden = false;
          list.push(c);
          s.groups.add(c);
        }
        continue;
      }
      const { faces, edges } = copyGeometry(g.mesh, this.mesh, g.mesh.faces, [...g.mesh.edges].filter((e) => !e.faces.length), g.matrix);
      for (const f of faces) s.faces.add(f);
      for (const e of edges) s.edges.add(e);
      for (const f of faces) for (const e of this.mesh.faceEdges(f)) s.edges.add(e);
      const i = list.indexOf(g);
      if (i >= 0) list.splice(i, 1);
      for (const c of g.children) {
        c.matrix.premultiply(g.matrix);
        c.parent = this.context;
        list.push(c);
        s.groups.add(c);
      }
      if (g.material?.color) for (const f of faces) if (!f.attrs.color && !f.attrs.texture) f.attrs.color = g.material.color;
    }
    this.model.touch();
    tx.commit();
    this.selectionChanged();
  }

  /** Mark the selected groups as holes (or, if all are holes, as solids). */
  toggleHole(): void {
    const groups = [...this.sel.groups];
    if (!groups.length) {
      this.toast(t('Select groups first (holes are always groups).'), 'warn');
      return;
    }
    const toHole = !groups.every(isHole);
    const tx = this.history.begin(toHole ? t('Make Hole') : t('Make Solid')).structure();
    for (const g of groups) {
      if (toHole) g.extra.hole = true;
      else delete g.extra.hole;
    }
    this.model.touch();
    tx.commit();
    this.selectionChanged();
  }

  /** Solids united, holes subtracted (Tinkercad's group with holes). The
   * parts are kept hidden inside the result, so Explode brings them back. */
  async combineSelection(): Promise<void> {
    const s = this.sel;
    const groups = [...s.groups];
    // Loose geometry in the selection counts as one more solid.
    const loose = closure(this.mesh, s.faces, s.edges);
    const looseMesh = new Mesh();
    if (loose.faces.size) copyGeometry(this.mesh, looseMesh, loose.faces, [], new Matrix4());
    const items = groups.length + (looseMesh.faces.size ? 1 : 0);
    if (items < 2) {
      this.toast(t('Select at least two parts (solids and holes).'), 'warn');
      return;
    }
    const solids: Part[] = looseMesh.faces.size ? [{ mesh: looseMesh, matrix: new Matrix4(), name: t('Selection') }] : [];
    const holes: Part[] = [];
    for (const g of groups) collectParts(g, new Matrix4(), isHole(g), solids, holes);
    let mesh: Mesh;
    try {
      mesh = await combine(solids, holes);
    } catch (e) {
      this.toast(e instanceof CsgError ? e.message : t('Combine failed: {error}', { error: (e as Error).message }), 'warn');
      return;
    }
    if (!mesh.faces.size) {
      this.toast(t('The holes remove the entire solid.'), 'warn');
      return;
    }
    const tx = this.history.begin(t('Combine')).track(this.mesh).structure();
    const list = this.contextGroups;
    const first = groups.find((g) => !isHole(g));
    const g = new Group(mesh, first?.name);
    g.material = first?.material ? structuredClone(first.material) : null;
    g.extra.csg = true;
    if (looseMesh.faces.size) {
      // The loose solid moves into the result as a group of its own.
      const lg = new Group(looseMesh);
      extract(this.mesh, loose.faces, loose.edges);
      lg.parent = g;
      lg.hidden = true;
      g.children.push(lg);
    }
    for (const c of groups) {
      const i = list.indexOf(c);
      if (i >= 0) list.splice(i, 1);
      c.parent = g;
      c.hidden = true;
      g.children.push(c);
    }
    g.parent = this.context;
    list.push(g);
    this.model.touch();
    tx.commit();
    this.clearSelection();
    this.sel.groups.add(g);
    this.selectionChanged();
    this.toast(
      holes.length === 1 ? t('1 hole subtracted') : holes.length ? t('{n} holes subtracted', { n: holes.length }) : t('Solids united'),
    );
  }

  /** Make a selected component's copies independent (Make Unique). */
  makeUnique(): void {
    const groups = [...this.sel.groups].filter((g) => this.model.instancesOf(g.mesh).length > 1);
    if (!groups.length) return;
    const tx = this.history.begin(t('Make Unique')).structure();
    for (const g of groups) {
      const m = new Mesh();
      m.loadData(g.mesh.toData());
      g.mesh = m;
    }
    this.model.touch();
    tx.commit();
  }

  hideSelection(): void {
    const s = this.sel;
    if (this.selectionEmpty()) return;
    const tx = this.history.begin(t('Hide')).track(this.mesh).structure();
    for (const g of s.groups) g.hidden = true;
    for (const f of s.faces) f.attrs.hidden = true;
    for (const e of s.edges) e.hidden = true;
    this.mesh.touch();
    this.model.touch();
    tx.commit();
    this.clearSelection();
  }

  unhideAll(): void {
    const tx = this.history.begin(t('Unhide All')).track(this.mesh).structure();
    // The parts kept inside a combined body stay hidden.
    for (const g of this.model.allGroups()) if (!g.parent?.extra.csg) g.hidden = false;
    for (const f of this.mesh.faces) delete f.attrs.hidden;
    for (const e of this.mesh.edges) e.hidden = false;
    this.mesh.touch();
    this.model.touch();
    tx.commit();
  }

  reverseFaces(): void {
    const faces = [...this.sel.faces];
    if (!faces.length) return;
    const tx = this.history.begin(t('Reverse Faces')).track(this.mesh);
    for (const f of faces) this.mesh.reverseFace(f);
    tx.commit();
    this.vp.selectionChanged();
  }

  zoomExtents(): void {
    const b = this.model.bounds();
    if (b) this.vp.rig.fit(b.min, b.max);
    else this.vp.rig.fit(new Vector3(-5, -5, 0), new Vector3(5, 5, 3));
    this.vp.invalidate();
    this.tool?.refresh();
  }

  /** Replace the document. */
  setModel(m: Model): void {
    this.vp.setContext(null);
    this.clearSelection();
    this.model.clear();
    this.vp.materials.reset();
    Object.assign(this.model, {
      root: m.root,
      groups: m.groups,
      kept: m.kept,
      materials: m.materials,
      textures: m.textures,
      extra: m.extra,
      name: m.name,
    });
    this.model.touch();
    this.history.clear();
    this.guides = { points: [], lines: [] };
    this.dirty = false;
    this.zoomExtents();
    this.emit('document');
  }
}

export const isHole = (g: Group): boolean => g.extra.hole === true;

/** A group's own mesh and its visible children, in its parent's frame,
 * sorted into solids and holes (a hole stays a hole, whatever holds it). */
function collectParts(g: Group, parent: Matrix4, hole: boolean, solids: Part[], holes: Part[]): void {
  const m = parent.clone().multiply(g.matrix);
  if (g.mesh.faces.size) (hole ? holes : solids).push({ mesh: g.mesh, matrix: m, name: g.name });
  if (!g.extra.csg) for (const c of g.children) if (!c.hidden) collectParts(c, m, hole || isHole(c), solids, holes);
}
