// SPDX-License-Identifier: GPL-3.0-or-later
// IngeTrazo Web — entry point of the plain modeller, with the extension
// manager: installed extensions (and ``?ext=<url>``) load before the UI.
import * as lib from './index';
import { install, installed, loadAll, provideHost, uninstall } from './extload';
import { startApp } from './start';
import type { App } from './app';
import { dialog } from './ui/ui';
import { t } from './i18n';

provideHost(lib);

function urlField(): { body: HTMLElement; input: HTMLInputElement } {
  const body = document.createElement('div');
  const p = document.createElement('p');
  p.textContent = t('Address of the extension module (.js), e.g. {url}', { url: 'https://example.com/my-extension.js' });
  const input = document.createElement('input');
  input.type = 'url';
  input.style.width = '100%';
  input.placeholder = `https://…/${t('extension')}.js`;
  body.append(p, input);
  return { body, input };
}

async function installUrl(app: App): Promise<void> {
  const { body, input } = urlField();
  setTimeout(() => input.focus(), 0);
  const r = await dialog(t('Install extension'), body, [
    { label: t('Cancel'), value: 'cancel' },
    { label: t('Install'), value: 'ok', primary: true },
  ]);
  const url = input.value.trim();
  if (r !== 'ok' || !url) return;
  try {
    const ext = await install({ url });
    app.toast(t('“{name}” installed – reloading…', { name: ext.name }));
    setTimeout(() => location.reload(), 800);
  } catch (e) {
    app.toast(t('Installation failed: {msg}', { msg: (e as Error).message }), 'warn');
  }
}

function installFile(app: App): void {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = '.js,.mjs,text/javascript';
  input.onchange = async () => {
    const f = input.files?.[0];
    if (!f) return;
    try {
      const ext = await install({ code: await f.text() });
      app.toast(t('“{name}” installed – reloading…', { name: ext.name }));
      setTimeout(() => location.reload(), 800);
    } catch (e) {
      app.toast(t('Installation failed: {msg}', { msg: (e as Error).message }), 'warn');
    }
  };
  input.click();
}

const { extensions, errors } = await loadAll();

const app = startApp({
  extensions,
  menus: (app) => [
    {
      label: t('Extensions'),
      items: [
        { label: t('Install (address)…'), run: () => void installUrl(app) },
        { label: t('Install (file)…'), run: () => installFile(app) },
        ...(installed().length ? (['-'] as const) : []),
        ...installed().map((x) => ({
          label: t('Remove: {name}', { name: x.name }),
          run: () => {
            uninstall(x.name);
            location.reload();
          },
        })),
      ],
    },
  ],
});

for (const e of errors) app.toast(t('Extension not loaded: {err}', { err: e }), 'warn');
