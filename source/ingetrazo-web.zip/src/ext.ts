// SPDX-License-Identifier: GPL-3.0-or-later
// IngeTrazo Web — extension API (the web counterpart of IngeTrazo's
// core/extensions.py + views/extension_api.py): an extension contributes
// tools, menus, tray panels, viewport overlays and snap points.
//
// Parameters an extension stores on a group belong in ``group.extra.ext``
// (keyed by the extension id): IngeTrazo writes that key as ``"ext"`` in the
// .igz, so they survive a round trip through the desktop app too.
import type { Object3D, Vector3 } from 'three';
import type { App } from './app';
import type { Tool } from './tools/base';
import type { Action } from './ui/ui';

export type SnapPoint = { point: Vector3; label: string; color?: string };

export type PanelSpec = {
  title: string;
  open?: boolean;
  /** Called on selection/document/history changes and on ``refresh()``. */
  render: (body: HTMLElement) => void;
};

export type ExtensionApi = {
  app: App;
  /** Add a tool; ``icon`` is an inline SVG (24×24, currentColor). */
  addTool(tool: Tool, icon: string): void;
  addMenu(label: string, items: (Action | '-')[]): void;
  addPanel(spec: PanelSpec): { refresh(): void };
  /** Extra objects drawn in the viewport (world coordinates). */
  addOverlay(obj: Object3D): void;
  /** Points every tool snaps to (in world coordinates). */
  addSnapPoints(fn: () => SnapPoint[]): void;
  /** Ask for a redraw after changing an overlay. */
  redraw(): void;
};

export type Extension = {
  id: string;
  name: string;
  setup(api: ExtensionApi): void;
};

/** What the extensions contributed, collected before the UI is built. */
export type Contributions = {
  tools: { tool: Tool; icon: string }[];
  menus: { label: string; items: (Action | '-')[] }[];
  panels: { spec: PanelSpec; refresh: () => void; body?: HTMLElement }[];
};

export function loadExtensions(app: App, exts: Extension[]): Contributions {
  const c: Contributions = { tools: [], menus: [], panels: [] };
  for (const ext of exts) {
    const api: ExtensionApi = {
      app,
      addTool(tool, icon) {
        app.register(tool);
        c.tools.push({ tool, icon });
      },
      addMenu(label, items) {
        c.menus.push({ label, items });
      },
      addPanel(spec) {
        const entry: Contributions['panels'][number] = {
          spec,
          refresh: () => {
            if (entry.body) spec.render(entry.body);
          },
        };
        c.panels.push(entry);
        return { refresh: () => entry.refresh() };
      },
      addOverlay(obj) {
        app.vp.addOverlay(obj);
      },
      addSnapPoints(fn) {
        app.inference.providers.push(fn);
      },
      redraw() {
        app.vp.invalidate();
      },
    };
    try {
      ext.setup(api);
    } catch (e) {
      // A broken extension never breaks the app (same contract as IngeTrazo).
      console.error(`Extension ${ext.id} failed to load`, e);
    }
  }
  return c;
}
