# IngeTrazo Web

**English** · [Deutsch](README.de.md) · [Español](README.es.md)

Free 3D modeller for architecture, engineering and design, **right in the browser**:
draw as if by hand, with Push/Pull. A web port of
[IngeTrazo](https://github.com/ingelibre/ingetrazo) (Python/Qt) to TypeScript and three.js.
It reads and writes IngeTrazo's `.igz` document format.

Everything runs locally in the browser. There is no server, and documents never leave your computer.
The user interface is available in English (default), German and Spanish.

![IngeTrazo Web](docs/screenshots/en.png)

## Getting started

```bash
npm install
npm run dev        # http://localhost:5173
npm test           # geometry and file-format tests (vitest)
npm run build      # static build in dist/ (relative paths, runs from any sub-folder)
```

## Features

- **Viewport**: Z-up camera, orbit around the point under the cursor (middle mouse button),
  pan (right mouse button / Shift+middle), zoom to cursor, trackpad gestures,
  perspective ↔ parallel, standard views, zoom extents, X-ray, hidden edges.
- **View cube**: click a side, edge or corner for a straight or oblique view; drag it to orbit.
- **Inference**: endpoint, midpoint, on edge, on face, magnetic red/green/blue axes.
  Shift locks the direction, the arrow keys lock an axis.
- **Value Control Box**: just type and press Enter, e.g. `2,5`, `250cm`, `4;3` (rectangle),
  `24s` (segments), `3:12` (slope when rotating), `3x` (array after a copy).
- **Drawing**: line, rectangle, circle, polygon. Closed loops become faces automatically
  (also when their corners are a few millimetres off-plane). Drawing on a face splits it or
  punches a hole into it.
- **Push/Pull**: a free-standing face becomes a solid, a top face is stretched, recesses and
  steps appear, coplanar side faces merge. Ctrl = copy (stack a storey), double-click = last distance.
- **Move / Copy / Array, Rotate** (15° angle snapping), **Eraser** (Ctrl = soften, Shift = hide),
  **Paint bucket** (colours, document materials, Alt = sample), **Tape measure** with guide lines and points.
- **Groups and components**: create, edit (double-click), explode, make unique.
  Component copies share their geometry.
- **Solids and holes** (as in Tinkercad): turn a group into a hole with *Shift+B* (shown
  see-through grey), then select solids and holes together (loose geometry too) and group them
  with *G* (or *Ctrl+G*): the holes cut the solids and the solids are united. A hole stays a hole,
  even inside a group. The parts are kept hidden inside the result, so *Explode* brings
  them back. The Boolean operations are computed by [Manifold](https://github.com/elalish/manifold)
  (WASM, Apache-2.0). Every part must be a closed solid.
- **Files**: open (formats 1–3, including embedded textures) and save `.igz`; import GLB/glTF,
  STL and OBJ (coplanar triangles merge into faces, glTF textures are kept); export GLB/glTF,
  STL, OBJ and PNG. Automatic backup in the browser (IndexedDB).
- **Examples**: the four Plaza Yanque documents from the IngeTrazo repository (menu *File*).
- **Languages**: the user interface is available in English (default), German and Spanish; switch via the
  menu *Sprache / Language / Idioma*.

## Architecture

| Folder | Contents | Counterpart in IngeTrazo |
|---|---|---|
| `src/core/mesh.ts` | Mesh with shared vertices, 0.1 mm weld tolerance, radial edges (non-manifold allowed) | `core/mesh.py` |
| `src/core/arrangement.ts` | rebuilds every face of a plane from its edges (close, split, holes, merge seams) | `core/cap_rebuild.py`, `core/topology.py` |
| `src/core/ops.ts` | drawing with edge splitting, erasing, Push/Pull, copying | `tools/pushpull.py`, `core/edits.py` |
| `src/core/csg.ts` | solids ∪ … − holes via Manifold; face paint carried per triangle, planar faces rebuilt afterwards | – |
| `src/core/history.ts` | undo via snapshots of the touched meshes and the group tree | `core/history.py` |
| `src/io/igz.ts` | `.igz` reading (JSON, ZIP, binary blocks) and writing | `formats/igz.py` |
| `src/view/` | three.js rendering, materials, `.skp`-style texture projection | `views/viewport.py`, `core/texture.py` |
| `src/tools/` | tools and inference | `tools/*.py`, `core/snap.py` |

Keys of an `.igz` this build does not edit (layers, scenes, sheets, dimensions, IFC tags …) are
kept unchanged when saving.

## Extensions

An extension adds tools, menus, side panels, viewport overlays and snap points to IngeTrazo Web
without changing the app. It is **one ES module** whose `default` export is `{ id, name, setup(api) }`.
The API is in [`src/ext.ts`](src/ext.ts); everything an extension may import from `ingetrazo-web` is
listed in [`src/index.ts`](src/index.ts) (geometry `Mesh`/`ops`, document `Group`/`Model`, `Tool`,
`units`, `dialog`, `combineSolids`, `t`/`addTranslations` …).

### 1. Write it

A minimal extension: a menu that inserts a 1 m cube as a group, in one undo step.

```ts
import { Vector3 } from 'three';
import { type Extension, Group, ops, t, addTranslations } from 'ingetrazo-web';

addTranslations('de', { 'Insert cube': 'Würfel einfügen' });
addTranslations('es', { 'Insert cube': 'Insertar cubo' });

const extension: Extension = {
  id: 'cube',            // key for group.extra.ext.cube
  name: 'Cube',
  setup(api) {
    const app = api.app;
    api.addMenu('Cube', [{
      label: t('Insert cube'),
      run: () => {
        const g = new Group(undefined, 'Cube');
        const pts = [new Vector3(0, 0, 0), new Vector3(1, 0, 0), new Vector3(1, 1, 0), new Vector3(0, 1, 0)];
        const { faces } = ops.drawSegments(g.mesh, ops.loopSegments(pts));
        ops.pushPull(g.mesh, faces[0], 1);
        g.extra.ext = { cube: { size: 1 } };          // saved in the .igz
        const tx = app.history.begin(t('Insert cube')).structure();
        g.parent = app.context;
        app.contextGroups.push(g);
        app.model.touch();
        tx.commit();                                  // one undo step
      },
    }]);
  },
};
export default extension;
```

### 2. The API

`setup(api)` receives:

| Method | Adds |
|---|---|
| `addTool(tool, svgIcon)` | a tool in the toolbar (subclass of `Tool`: `down/move/up`, `hint()`, `value(text)` for typed values, `shortcut`) |
| `addMenu(label, items)` | a menu before *Help*; items `{ label, run, key?, enabled?, checked? }` or `'-'` |
| `addPanel({ title, render })` | a side panel; `render(body)` runs on selection, document and undo changes |
| `addOverlay(object3d)` | extra three.js objects in the viewport (world coordinates) |
| `addSnapPoints(() => points)` | points every tool snaps to |
| `redraw()` | repaint after changing an overlay |
| `api.app` | the application: `model`, `sel`, `history`, `toast()`, `setTool()`, `inference`, `vp` |

### 3. Build it

Bundle it as a single ES module with `three` and `ingetrazo-web` **external**; the app hands the
extension its own copies at load time (one three.js, the same classes). With Vite:

```ts
// vite.config.ts
import { defineConfig } from 'vite';
export default defineConfig({
  build: {
    lib: { entry: 'src/index.ts', formats: ['es'], fileName: () => 'my-extension.js' },
    rollupOptions: { external: ['three', 'ingetrazo-web'] },
  },
});
```

For type checking, point `ingetrazo-web` at this repository, e.g. with `"paths": { "ingetrazo-web": ["../ingetrazo-web/src/index.ts"] }`
in `tsconfig.json`, or install it as a dependency (`npm i ../ingetrazo-web`).

### 4. Load it

- **Install**: menu *Extensions ▸ Install (address)…* with the module's URL (it must be reachable with CORS),
  or *Install (file)…* with the `.js` file. The app reloads; the browser remembers the extension.
- **Develop**: `http://localhost:5173/?ext=http://localhost:8080/my-extension.js` loads it for this visit only.
- **Remove**: *Extensions ▸ Remove: …*.
- **Build your own app around it**: `startApp({ extensions: [extension], brand, title })` from `ingetrazo-web`.

### 5. Rules of thumb

- Store your parameters on the group in `group.extra.ext.<id>`; they are saved in the `.igz` (as `ext`, like IngeTrazo) and survive undo.
- Wrap every change in `app.history.begin(label).track(mesh).structure() … tx.commit()` so it is one undo step.
- Write UI texts in English and wrap them in `t()`; register German and Spanish with `addTranslations('de' | 'es', { English: translation })`.
- An exception in `setup()` is caught and logged; it never breaks the app.

### Examples

- [`examples/extension-stairs`](examples/extension-stairs/src/index.ts): stair generator with a tool, a panel, a menu, snap points and translations (~140 lines). Build: `npm run build:example-ext` → `examples/extension-stairs/dist/stairs.js`.

## Not ported yet

Arc, freehand, offset, Follow Me, fillet, scale, mirror, intersect faces, section planes, editing
dimensions and texts, scenes, layer management, sheet composition, sun and shadows,
georeferencing, `.skp`, DXF and IFC import/export.

## License

GPL-3.0-or-later, like IngeTrazo (see `LICENSE`). Concepts, file format and example documents
come from IngeTrazo, © 2026 Marco Sumari Tellez and IngeTrazo contributors.
