# IngeTrazo Web

[English](README.md) · **Deutsch** · [Español](README.es.md)

Freier 3D-Modeler für Architektur, Ingenieurwesen und Design, **direkt im Browser**:
zeichnen wie von Hand, mit Push/Pull. Eine Web-Portierung von
[IngeTrazo](https://github.com/ingelibre/ingetrazo) (Python/Qt) nach TypeScript und three.js.
Sie liest und schreibt dessen Dokumentformat `.igz`.

Alles läuft lokal im Browser. Es gibt keinen Server, und Dokumente verlassen den Rechner nicht.
Die Oberfläche gibt es auf Englisch (Standard), Deutsch und Spanisch.

![IngeTrazo Web](docs/screenshots/de.png)

## Starten

```bash
npm install
npm run dev        # http://localhost:5173
npm test           # Geometrie- und Dateiformat-Tests (vitest)
npm run build      # statischer Build nach dist/ (relativer Pfad, läuft in jedem Unterordner)
```

## Was funktioniert

- **Viewport**: Z-oben-Kamera, Orbit um den Punkt unter dem Cursor (mittlere Maustaste),
  Verschieben (rechte Maustaste / Umschalt+Mitte), Zoom zum Cursor, Trackpad-Gesten,
  Perspektive ↔ Parallel, Standardansichten, Alles zeigen, Röntgen, ohne Kanten.
- **Orientierungswürfel**: Klick auf Seite, Kante oder Ecke wählt Ansicht bzw. Schrägansicht,
  Ziehen am Würfel dreht die Ansicht.
- **Inferenz**: Endpunkt, Mittelpunkt, auf Kante, auf Fläche, magnetische rote/grüne/blaue
  Achse. Umschalt sperrt die Richtung, die Pfeiltasten sperren eine Achse.
- **Werteingabe (VCB)**: einfach lostippen und mit Enter bestätigen, z. B. `2,5`, `250cm`,
  `4;3` (Rechteck), `24s` (Segmente), `3:12` (Steigung beim Drehen), `3x` (Reihe nach einer Kopie).
- **Zeichnen**: Linie, Rechteck, Kreis, Polygon. Geschlossene Schleifen werden automatisch
  zu Flächen. Was auf einer Fläche gezeichnet wird, teilt sie bzw. stanzt ein Loch hinein.
- **Push/Pull**: frei stehende Fläche wird Körper, Deckfläche wird gestreckt, Vertiefungen und
  Absätze entstehen, gleich ebene Seitenflächen verschmelzen. Strg = Kopie (Geschoss stapeln),
  Doppelklick = letzter Abstand.
- **Verschieben / Kopieren / Reihe, Drehen** (Winkelraster 15°), **Radiergummi**
  (Strg = glätten, Umschalt = ausblenden), **Farbeimer** (Farben, Dokumentmaterialien, Alt = aufnehmen),
  **Maßband** mit Hilfslinien und Hilfspunkten.
- **Gruppen und Komponenten**: erstellen, bearbeiten (Doppelklick), auflösen, eindeutig machen.
  Komponentenkopien teilen sich die Geometrie.
- **Körper und Bohrungen** (wie Tinkercad): eine Gruppe mit *Umschalt+B* zur Bohrung machen
  (durchscheinend grau), dann Körper und Bohrungen zusammen auswählen (auch ungruppierte Geometrie)
  und mit *G* gruppieren (oder *Strg+G*): Die Bohrungen schneiden die Körper, und die Körper
  werden vereinigt. Eine Bohrung bleibt eine Bohrung, auch in einer Gruppe. Die Teile bleiben verborgen im Ergebnis
  erhalten, sodass *Auflösen* sie zurückholt. Die Booleschen Operationen rechnet die Bibliothek
  [Manifold](https://github.com/elalish/manifold) (WASM, Apache-2.0). Alle Teile müssen
  geschlossene Körper sein.
- **Dateien**: `.igz` öffnen (Format 1–3, inklusive eingebetteter Texturen) und speichern,
  GLB/glTF, STL und OBJ importieren (gleich ebene Dreiecke werden zu Flächen zusammengeführt,
  glTF-Texturen bleiben erhalten),
  Export als GLB/glTF, STL, OBJ und PNG. Automatische Sicherung im Browser (IndexedDB).
- **Beispiele**: die vier Plaza-Yanque-Dokumente aus dem IngeTrazo-Repository (Menü *Datei*).
- **Sprachen**: Die Oberfläche gibt es auf Englisch (Standard), Deutsch und Spanisch; umschalten über das
  Menü *Sprache / Language / Idioma*.

## Architektur

| Ordner | Inhalt | Vorbild in IngeTrazo |
|---|---|---|
| `src/core/mesh.ts` | Mesh mit gemeinsamen Eckpunkten, Schweißtoleranz 0,1 mm, radiale Kanten (nicht-mannigfaltig erlaubt) | `core/mesh.py` |
| `src/core/arrangement.ts` | baut alle Flächen einer Ebene aus deren Kanten neu auf (Flächen schließen, teilen, Löcher, Nähte verschmelzen) | `core/cap_rebuild.py`, `core/topology.py` |
| `src/core/ops.ts` | Zeichnen mit Kantenschnitt, Radieren, Push/Pull, Kopieren | `tools/pushpull.py`, `core/edits.py` |
| `src/core/csg.ts` | Körper ∪ … − Bohrungen über Manifold, Flächenfarbe pro Dreieck mitgeführt, danach wieder ebene Flächen | – |
| `src/core/history.ts` | Rückgängig über Schnappschüsse der betroffenen Meshes und des Gruppenbaums | `core/history.py` |
| `src/io/igz.ts` | `.igz`-Lesen (JSON, ZIP, Binärblöcke) und -Schreiben | `formats/igz.py` |
| `src/view/` | three.js-Darstellung, Materialien, Texturprojektion wie `.skp` | `views/viewport.py`, `core/texture.py` |
| `src/tools/` | Werkzeuge und Inferenz | `tools/*.py`, `core/snap.py` |

Unbekannte Schlüssel eines `.igz` (Ebenen, Szenen, Blätter, Bemaßungen, IFC-Tags …) bleiben beim
Speichern unverändert erhalten.

## Erweiterungen

Eine Erweiterung ergänzt IngeTrazo Web um Werkzeuge, Menüs, Seitenleisten-Panels, Viewport-Overlays
und Fangpunkte, ohne die App zu ändern. Sie ist **ein einzelnes ES-Modul**, dessen `default`-Export
`{ id, name, setup(api) }` ist. Die API steht in [`src/ext.ts`](src/ext.ts); alles, was eine Erweiterung aus
`ingetrazo-web` importieren darf, listet [`src/index.ts`](src/index.ts) (Geometrie `Mesh`/`ops`, Dokument
`Group`/`Model`, `Tool`, `units`, `dialog`, `combineSolids`, `t`/`addTranslations` …).

### 1. Schreiben

Eine minimale Erweiterung: ein Menü, das einen 1-m-Würfel als Gruppe einfügt, in einem Rückgängig-Schritt.

```ts
import { Vector3 } from 'three';
import { type Extension, Group, ops, t, addTranslations } from 'ingetrazo-web';

addTranslations('de', { 'Insert cube': 'Würfel einfügen' });
addTranslations('es', { 'Insert cube': 'Insertar cubo' });

const extension: Extension = {
  id: 'cube',            // key for group.extra.ext.cube
  name: 'Cube',
  setup(api) {
    const app = api.app;
    api.addMenu('Cube', [{
      label: t('Insert cube'),
      run: () => {
        const g = new Group(undefined, 'Cube');
        const pts = [new Vector3(0, 0, 0), new Vector3(1, 0, 0), new Vector3(1, 1, 0), new Vector3(0, 1, 0)];
        const { faces } = ops.drawSegments(g.mesh, ops.loopSegments(pts));
        ops.pushPull(g.mesh, faces[0], 1);
        g.extra.ext = { cube: { size: 1 } };          // saved in the .igz
        const tx = app.history.begin(t('Insert cube')).structure();
        g.parent = app.context;
        app.contextGroups.push(g);
        app.model.touch();
        tx.commit();                                  // one undo step
      },
    }]);
  },
};
export default extension;
```

### 2. Die API

`setup(api)` bekommt:

| Methode | Fügt hinzu |
|---|---|
| `addTool(tool, svgIcon)` | Werkzeug in der Werkzeugleiste (Unterklasse von `Tool`: `down/move/up`, `hint()`, `value(text)` für getippte Werte, `shortcut`) |
| `addMenu(label, items)` | Menü vor *Hilfe*; Einträge `{ label, run, key?, enabled?, checked? }` oder `'-'` |
| `addPanel({ title, render })` | Seitenleisten-Panel; `render(body)` läuft bei Auswahl-, Dokument- und Rückgängig-Änderungen |
| `addOverlay(object3d)` | zusätzliche three.js-Objekte im Viewport (Weltkoordinaten) |
| `addSnapPoints(() => points)` | Punkte, an denen alle Werkzeuge fangen |
| `redraw()` | neu zeichnen, nachdem ein Overlay geändert wurde |
| `api.app` | die Anwendung: `model`, `sel`, `history`, `toast()`, `setTool()`, `inference`, `vp` |

### 3. Bauen

Als einzelnes ES-Modul bündeln, mit `three` und `ingetrazo-web` als **extern**. Die App reicht der
Erweiterung beim Laden ihre eigenen Exemplare (ein three.js, dieselben Klassen). Mit Vite:

```ts
// vite.config.ts
import { defineConfig } from 'vite';
export default defineConfig({
  build: {
    lib: { entry: 'src/index.ts', formats: ['es'], fileName: () => 'my-extension.js' },
    rollupOptions: { external: ['three', 'ingetrazo-web'] },
  },
});
```

Für die Typprüfung `ingetrazo-web` auf dieses Repository zeigen lassen, z. B. mit
`"paths": { "ingetrazo-web": ["../ingetrazo-web/src/index.ts"] }` in der `tsconfig.json`, oder es als
Abhängigkeit installieren (`npm i ../ingetrazo-web`).

### 4. Laden

- **Installieren**: Menü *Erweiterungen ▸ Installieren (Adresse) …* mit der Adresse des Moduls (per CORS erreichbar)
  oder *Installieren (Datei) …* mit der `.js`-Datei. Die App lädt neu, der Browser merkt sich die Erweiterung.
- **Entwickeln**: `http://localhost:5173/?ext=http://localhost:8080/my-extension.js` lädt sie nur für diesen Aufruf.
- **Entfernen**: *Erweiterungen ▸ Entfernen: …*.
- **Eigene App darum bauen**: `startApp({ extensions: [extension], brand, title })` aus `ingetrazo-web`.

### 5. Faustregeln

- Parameter an der Gruppe in `group.extra.ext.<id>` ablegen; sie werden im `.igz` gespeichert (als `ext`, wie bei IngeTrazo) und überstehen Rückgängig.
- Jede Änderung in `app.history.begin(label).track(mesh).structure() … tx.commit()` fassen, damit sie ein Rückgängig-Schritt ist.
- Oberflächentexte auf Englisch schreiben und in `t()` fassen; Deutsch und Spanisch mit `addTranslations('de' | 'es', { Englisch: Übersetzung })` eintragen.
- Eine Ausnahme in `setup()` wird abgefangen und protokolliert; sie legt die App nie lahm.

### Beispiele

- [`examples/extension-stairs`](examples/extension-stairs/src/index.ts): Treppengenerator mit Werkzeug, Panel, Menü, Fangpunkten und Übersetzungen (~140 Zeilen). Bauen: `npm run build:example-ext` → `examples/extension-stairs/dist/stairs.js`.

## Noch nicht portiert

Bogen, Freihand, Versatz (Offset), Folge mir, Abrunden, Skalieren, Spiegeln, Verschneiden
(Schnittmenge), Schnittebenen, Bemaßungen und Texte bearbeiten, Szenen, Ebenen-Verwaltung,
Blattkomposition, Sonne und Schatten, Georeferenzierung, `.skp`-, DXF- und IFC-Import/Export.

## Lizenz

GPL-3.0-or-later, wie IngeTrazo (siehe `LICENSE`). Konzepte, Dateiformat und Beispieldokumente
stammen aus IngeTrazo, © 2026 Marco Sumari Tellez und IngeTrazo-Mitwirkende.
