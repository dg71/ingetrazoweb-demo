// SPDX-License-Identifier: GPL-3.0-or-later
// Example extension for IngeTrazo Web: a stair generator.
//
// Shows the whole extension API in ~120 lines: a menu, a side panel, a tool
// with a status-bar hint and a typed value, snap points, an undo step,
// parameters stored on the group (saved in the .igz) and translations.
import { Matrix4, Vector3 } from 'three';
import {
  type App,
  type Extension,
  Group,
  Mesh,
  type PointerInfo,
  Tool,
  addTranslations,
  ops,
  showSnap,
  t,
  units,
} from 'ingetrazo-web';

// 1. Translations: English text is the key (English is the source language).
addTranslations('de', {
  Stairs: 'Treppe',
  'Insert stairs': 'Treppe einfügen',
  Steps: 'Stufen',
  Rise: 'Steigung',
  Tread: 'Auftritt',
  Width: 'Breite',
  'Click the start point of the stairs ({n} steps).': 'Startpunkt der Treppe klicken ({n} Stufen).',
  'Stairs with {n} steps': 'Treppe mit {n} Stufen',
});
addTranslations('es', {
  Stairs: 'Escalera',
  'Insert stairs': 'Insertar escalera',
  Steps: 'Peldaños',
  Rise: 'Contrahuella',
  Tread: 'Huella',
  Width: 'Ancho',
  'Click the start point of the stairs ({n} steps).': 'Haga clic en el punto inicial de la escalera ({n} peldaños).',
  'Stairs with {n} steps': 'Escalera de {n} peldaños',
});

type StairParams = { steps: number; rise: number; tread: number; width: number };
const params: StairParams = { steps: 8, rise: 0.18, tread: 0.28, width: 1.2 };

// 2. Geometry: the side profile as one face, pushed out by the width.
function stairMesh(p: StairParams): Mesh {
  const pts = [new Vector3(0, 0, 0)];
  for (let i = 0; i < p.steps; i++) {
    pts.push(new Vector3(i * p.tread, 0, (i + 1) * p.rise));
    pts.push(new Vector3((i + 1) * p.tread, 0, (i + 1) * p.rise));
  }
  pts.push(new Vector3(p.steps * p.tread, 0, 0));
  const m = new Mesh();
  const { faces } = ops.drawSegments(m, ops.loopSegments(pts));
  ops.pushPull(m, faces[0], p.width);
  return m;
}

// 3. Insert as a group, in one undo step; parameters go to group.extra.ext.<id>.
function insertStairs(app: App, at: Vector3): void {
  const tx = app.history.begin(t('Insert stairs')).structure();
  const g = new Group(stairMesh(params), t('Stairs with {n} steps', { n: params.steps }));
  g.extra.ext = { stairs: { ...params } };
  g.matrix.copy(app.vp.contextWorld().invert().multiply(new Matrix4().setPosition(at)));
  g.parent = app.context;
  app.contextGroups.push(g);
  app.model.touch();
  tx.commit();
}

// 4. A tool: click a point (with inference); type a number to set the steps.
class StairTool extends Tool {
  readonly id = 'stairs';
  readonly name = t('Stairs');
  readonly shortcut = 'y';
  vcbLabel = t('Steps');

  hint(): string {
    return t('Click the start point of the stairs ({n} steps).', { n: params.steps });
  }
  move(p: PointerInfo): void {
    super.move(p);
    showSnap(this.app, this.app.inference.find(p.x, p.y), p);
  }
  down(p: PointerInfo): void {
    insertStairs(this.app, this.app.inference.find(p.x, p.y).point);
  }
  value(text: string): boolean {
    const n = Math.round(Number(text));
    if (!(n >= 1 && n <= 100)) return false;
    params.steps = n;
    this.app.setHint(this.hint());
    return true;
  }
}

const ICON =
  '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round" aria-hidden="true"><path d="M3 20h18V4h-4v4h-4v4H9v4H3z"/></svg>';

// 5. The extension object: setup() receives the API.
const extension: Extension = {
  id: 'stairs',
  name: 'Stair generator',
  setup(api) {
    const app = api.app;
    api.addTool(new StairTool(app), ICON);
    api.addMenu(t('Stairs'), [{ label: t('Insert stairs'), run: () => insertStairs(app, new Vector3()) }]);
    api.addPanel({
      title: t('Stairs'),
      render(body) {
        body.replaceChildren();
        for (const [key, label] of [['steps', 'Steps'], ['rise', 'Rise'], ['tread', 'Tread'], ['width', 'Width']] as const) {
          const row = document.createElement('label');
          row.className = 'row';
          const input = document.createElement('input');
          input.type = 'number';
          input.step = key === 'steps' ? '1' : '0.01';
          input.value = String(params[key]);
          input.onchange = () => (params[key] = Number(input.value) || params[key]);
          row.append(t(label) + ' ', input);
          body.append(row);
        }
        const info = document.createElement('p');
        info.textContent = `${t('Stairs')}: ${units.formatLength(params.steps * params.rise)}`;
        body.append(info);
      },
    });
    // Snap to the top of every stair in the model.
    api.addSnapPoints(() =>
      [...app.model.allGroups()]
        .filter((g) => g.extra.ext && (g.extra.ext as Record<string, unknown>).stairs)
        .map((g) => {
          const p = (g.extra.ext as { stairs: StairParams }).stairs;
          return { point: new Vector3(p.steps * p.tread, 0, p.steps * p.rise).applyMatrix4(g.worldMatrix()), label: t('Stairs') };
        }),
    );
  },
};

export default extension;
