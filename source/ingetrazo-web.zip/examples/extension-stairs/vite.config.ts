import { defineConfig } from 'vite';

// One ES module; three and ingetrazo-web are supplied by the host app.
export default defineConfig({
  root: __dirname,
  publicDir: false,
  build: {
    target: 'es2022',
    outDir: 'dist',
    emptyOutDir: true,
    lib: { entry: 'src/index.ts', formats: ['es'], fileName: () => 'stairs.js' },
    rollupOptions: { external: ['three', 'ingetrazo-web'] },
  },
});
