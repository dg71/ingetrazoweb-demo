import { defineConfig } from 'vite';

// Relative base: the built app runs from any folder or static host
// (GitHub Pages, a sub-path on a web server, or a local file server).
export default defineConfig({
  base: './',
  build: {
    target: 'es2022',
    chunkSizeWarningLimit: 1500,
  },
});
