import { describe, expect, it } from 'vitest';
import { Matrix4, Vector3 } from 'three';
import { Mesh } from '../src/core/mesh';
import { circlePoints, drawSegments, loopSegments, pushPull } from '../src/core/ops';
import { Plane } from '../src/core/plane';
import { combine } from '../src/core/csg';

const V = (x: number, y: number, z = 0) => new Vector3(x, y, z);
const ground = new Plane(new Vector3(0, 0, 1), 0);

function box(x0: number, y0: number, x1: number, y1: number, h: number): Mesh {
  const m = new Mesh();
  drawSegments(m, loopSegments([V(x0, y0), V(x1, y0), V(x1, y1), V(x0, y1)]), { plane: ground });
  pushPull(m, [...m.faces][0], h);
  return m;
}
function volume(m: Mesh): number {
  let v = 0;
  for (const f of m.faces) v += (f.area() * f.normal().dot(f.loop[0].position)) / 3;
  return v;
}
const closed = (m: Mesh) => [...m.edges].every((e) => e.faces.length === 2);
const id = new Matrix4();

describe('solids and holes', () => {
  it('a corridor through a mat: box minus a longer, narrower box', async () => {
    const mat = box(0, 0, 10, 6, 0.3);
    for (const f of mat.faces) f.attrs.color = [0.2, 0.3, 0.8];
    const gang = box(4, -1, 5.5, 7, 1);
    const r = await combine([{ mesh: mat, matrix: id }], [{ mesh: gang, matrix: new Matrix4().makeTranslation(0, 0, -0.5) }]);
    expect(closed(r)).toBe(true);
    expect(volume(r)).toBeCloseTo((60 - 1.5 * 6) * 0.3, 4);
    // Two separate blocks, each a box: 12 faces, no stray triangles.
    expect(r.faces.size).toBe(12);
    for (const f of r.faces) expect(f.attrs.color).toEqual([0.2, 0.3, 0.8]);
  });

  it('a round bore stays smooth and the solids unite', async () => {
    const a = box(0, 0, 2, 2, 1);
    const b = box(1, 0, 3, 2, 1);
    const c = new Mesh();
    drawSegments(c, loopSegments(circlePoints(V(1.5, 1, -1), new Vector3(0, 0, 1), V(1.9, 1, -1), 24)), {
      plane: new Plane(new Vector3(0, 0, 1), -1),
      curve: true,
    });
    pushPull(c, [...c.faces][0], 3);
    const r = await combine([{ mesh: a, matrix: id }, { mesh: b, matrix: id }], [{ mesh: c, matrix: id }]);
    expect(closed(r)).toBe(true);
    const bore = Math.PI * 0.4 * 0.4 * Math.cos(Math.PI / 24) * Math.sin(Math.PI / 24) * 24 / Math.PI; // 24-gon area
    expect(volume(r)).toBeCloseTo(6 - bore, 3);
    expect([...r.edges].filter((e) => e.soft).length).toBeGreaterThanOrEqual(24);
    // Top: one face with a hole.
    const top = [...r.faces].filter((f) => f.normal().z > 0.99);
    expect(top.length).toBe(1);
    expect(top[0].holes.length).toBe(1);
  });

  it('refuses an open part', async () => {
    const open = new Mesh();
    drawSegments(open, loopSegments([V(0, 0), V(1, 0), V(1, 1), V(0, 1)]), { plane: ground });
    await expect(combine([{ mesh: box(0, 0, 1, 1, 1), matrix: id }], [{ mesh: open, matrix: id, name: 'Face' }])).rejects.toThrow(/not a closed solid/);
  });
});
