import { describe, expect, it } from 'vitest';
import { Vector3 } from 'three';
import { Mesh } from '../src/core/mesh';
import { circlePoints, drawSegments, eraseEdges, loopSegments, pushPull } from '../src/core/ops';
import { Plane } from '../src/core/plane';

const V = (x: number, y: number, z = 0) => new Vector3(x, y, z);
const rect = (x0: number, y0: number, x1: number, y1: number, z = 0) =>
  loopSegments([V(x0, y0, z), V(x1, y0, z), V(x1, y1, z), V(x0, y1, z)]);
const ground = new Plane(new Vector3(0, 0, 1), 0);

function isClosed(m: Mesh): boolean {
  for (const e of m.edges) if (e.faces.length !== 2) return false;
  return true;
}
function volume(m: Mesh): number {
  let v = 0;
  for (const f of m.faces) {
    const n = f.normal();
    v += (f.area() * n.dot(f.loop[0].position)) / 3;
  }
  return v;
}

describe('drawing', () => {
  it('closes a rectangle into one face facing up', () => {
    const m = new Mesh();
    drawSegments(m, rect(0, 0, 2, 1), { plane: ground });
    expect(m.faces.size).toBe(1);
    const f = [...m.faces][0];
    expect(f.normal().z).toBeCloseTo(1);
    expect(f.area()).toBeCloseTo(2);
  });

  it('closes a loop drawn line by line', () => {
    const m = new Mesh();
    drawSegments(m, [[V(0, 0), V(1, 0)]]);
    drawSegments(m, [[V(1, 0), V(1, 1)]]);
    expect(m.faces.size).toBe(0);
    drawSegments(m, [[V(1, 1), V(0, 0)]]);
    expect(m.faces.size).toBe(1);
  });

  it('a rectangle drawn on a face punches it and fills the hole', () => {
    const m = new Mesh();
    drawSegments(m, rect(0, 0, 4, 4), { plane: ground });
    drawSegments(m, rect(1, 1, 2, 2), { plane: ground });
    expect(m.faces.size).toBe(2);
    const areas = [...m.faces].map((f) => f.area()).sort();
    expect(areas[0]).toBeCloseTo(1);
    expect(areas[1]).toBeCloseTo(15);
  });

  it('a line across a face splits it', () => {
    const m = new Mesh();
    drawSegments(m, rect(0, 0, 4, 2), { plane: ground });
    drawSegments(m, [[V(1, 0), V(1, 2)]]);
    expect(m.faces.size).toBe(2);
    expect(m.edges.size).toBe(7);
  });

  it('crossing lines split each other', () => {
    const m = new Mesh();
    drawSegments(m, [[V(0, 0), V(2, 2)]]);
    drawSegments(m, [[V(0, 2), V(2, 0)]]);
    expect(m.edges.size).toBe(4);
  });
});

describe('push/pull', () => {
  it('pulls a free rectangle into a closed box', () => {
    const m = new Mesh();
    drawSegments(m, rect(0, 0, 2, 1), { plane: ground });
    const f = [...m.faces][0];
    expect(pushPull(m, f, 3).ok).toBe(true);
    expect(m.faces.size).toBe(6);
    expect(isClosed(m)).toBe(true);
    expect(volume(m)).toBeCloseTo(6);
  });

  it('pushing a free face down still makes an outward box', () => {
    const m = new Mesh();
    drawSegments(m, rect(0, 0, 1, 1), { plane: ground });
    pushPull(m, [...m.faces][0], -2);
    expect(isClosed(m)).toBe(true);
    expect(volume(m)).toBeCloseTo(2);
  });

  it('stretches a box top', () => {
    const m = new Mesh();
    drawSegments(m, rect(0, 0, 1, 1), { plane: ground });
    const r = pushPull(m, [...m.faces][0], 1);
    pushPull(m, r.cap!, 2);
    expect(m.faces.size).toBe(6);
    expect(volume(m)).toBeCloseTo(3);
    const r2 = pushPull(m, r.cap!, -1);
    expect(r2.ok).toBe(true);
    expect(volume(m)).toBeCloseTo(2);
  });

  it('refuses to collapse a box', () => {
    const m = new Mesh();
    drawSegments(m, rect(0, 0, 1, 1), { plane: ground });
    const r = pushPull(m, [...m.faces][0], 1);
    expect(pushPull(m, r.cap!, -1).ok).toBe(false);
  });

  it('pulls a rectangle drawn on a box top (bordered face)', () => {
    const m = new Mesh();
    drawSegments(m, rect(0, 0, 4, 4), { plane: ground });
    const r = pushPull(m, [...m.faces][0], 1);
    const top = new Plane(new Vector3(0, 0, 1), 1);
    const { faces } = drawSegments(m, rect(1, 1, 2, 2, 1), { plane: top });
    const inner = faces.find((f) => Math.abs(f.area() - 1) < 1e-6)!;
    expect(inner).toBeDefined();
    pushPull(m, inner, 1);
    expect(isClosed(m)).toBe(true);
    expect(volume(m)).toBeCloseTo(17);
    // Push it into the slab instead: a recess.
    void r;
  });

  it('carves a recess', () => {
    const m = new Mesh();
    drawSegments(m, rect(0, 0, 4, 4), { plane: ground });
    pushPull(m, [...m.faces][0], 2);
    const top = new Plane(new Vector3(0, 0, 1), 2);
    const { faces } = drawSegments(m, rect(1, 1, 2, 2, 2), { plane: top });
    const inner = faces.find((f) => Math.abs(f.area() - 1) < 1e-6)!;
    pushPull(m, inner, -1);
    expect(isClosed(m)).toBe(true);
    expect(volume(m)).toBeCloseTo(31);
  });

  it('a step flush with the side merges the side faces', () => {
    const m = new Mesh();
    drawSegments(m, rect(0, 0, 4, 4), { plane: ground });
    pushPull(m, [...m.faces][0], 1);
    const top = new Plane(new Vector3(0, 0, 1), 1);
    const { faces } = drawSegments(m, [[V(0, 2, 1), V(4, 2, 1)]], { plane: top });
    const half = faces[0];
    expect(faces.length).toBe(2);
    pushPull(m, half, 1);
    expect(isClosed(m)).toBe(true);
    expect(volume(m)).toBeCloseTo(24);
    // The x=0 side is one L-shaped face, not two rectangles.
    const side = [...m.faces].filter((f) => Math.abs(f.normal().x + 1) < 1e-6);
    expect(side.length).toBe(1);
  });

  it('extrudes a circle into a smooth cylinder', () => {
    const m = new Mesh();
    const pts = circlePoints(V(0, 0), new Vector3(0, 0, 1), V(1, 0), 24);
    drawSegments(m, loopSegments(pts), { plane: ground, curve: true });
    expect(m.faces.size).toBe(1);
    pushPull(m, [...m.faces][0], 1);
    expect(m.faces.size).toBe(26);
    expect(isClosed(m)).toBe(true);
    const soft = [...m.edges].filter((e) => e.soft).length;
    expect(soft).toBe(24);
  });
});

describe('erase', () => {
  it('erasing a seam merges coplanar faces', () => {
    const m = new Mesh();
    drawSegments(m, rect(0, 0, 4, 2), { plane: ground });
    drawSegments(m, [[V(1, 0), V(1, 2)]]);
    const seam = [...m.edges].find((e) => e.a.x === 1 && e.b.x === 1)!;
    eraseEdges(m, [seam]);
    expect(m.faces.size).toBe(1);
    expect(m.edges.size).toBe(4);
    expect([...m.faces][0].area()).toBeCloseTo(8);
  });

  it('erasing a boundary edge removes its face', () => {
    const m = new Mesh();
    drawSegments(m, rect(0, 0, 1, 1), { plane: ground });
    eraseEdges(m, [[...m.edges][0]]);
    expect(m.faces.size).toBe(0);
    expect(m.edges.size).toBe(3);
  });
});

describe('snapshots', () => {
  it('round-trips through toData/loadData', () => {
    const m = new Mesh();
    drawSegments(m, rect(0, 0, 2, 1), { plane: ground });
    pushPull(m, [...m.faces][0], 1);
    const d = m.toData();
    const m2 = new Mesh();
    m2.loadData(d);
    expect(m2.faces.size).toBe(6);
    expect(m2.edges.size).toBe(12);
    expect(isClosed(m2)).toBe(true);
  });
});

describe('seam merge with float noise', () => {
  it('keeps every face when a sample point lands on the dissolved diagonal', async () => {
    const { dissolveSeams } = await import('../src/core/ops');
    // A float32 cube as triangles (as a glTF file brings it): 12 → 6 faces.
    const c = [0, 0.5].map((x) => Math.fround(x - 0.0975));
    const s = [0, 0.5].map((y) => Math.fround(y - 0.275));
    const z = [0, 0.5].map((v) => Math.fround(-v));
    const P = (i: number, j: number, k: number) => V(c[i], s[j], z[k]);
    const quads = [
      [P(0, 0, 0), P(1, 0, 0), P(1, 1, 0), P(0, 1, 0)],
      [P(0, 0, 1), P(0, 1, 1), P(1, 1, 1), P(1, 0, 1)],
      [P(0, 0, 0), P(0, 0, 1), P(1, 0, 1), P(1, 0, 0)],
      [P(0, 1, 0), P(1, 1, 0), P(1, 1, 1), P(0, 1, 1)],
      [P(0, 0, 0), P(0, 1, 0), P(0, 1, 1), P(0, 0, 1)],
      [P(1, 0, 0), P(1, 0, 1), P(1, 1, 1), P(1, 1, 0)],
    ];
    for (const local of [false, true]) {
      const m = new Mesh();
      for (const [a, b, cc, d] of quads) {
        m.addFaceVerts([a, b, cc].map((p) => m.vertex(p)));
        m.addFaceVerts([a, cc, d].map((p) => m.vertex(p)));
      }
      dissolveSeams(m, [...m.edges], { local });
      expect(m.faces.size).toBe(6);
      expect(isClosed(m)).toBe(true);
    }
  });
});

describe('nearly planar loops', () => {
  it('closes a quad whose corner is a few mm off the plane, not one that is far off', async () => {
    const { closeNearPlanar } = await import('../src/core/ops');
    for (const [dz, expectFace] of [[0.003, true], [0.4, false]] as const) {
      const m = new Mesh();
      const pts = [V(0, 0, 0), V(3, 0, 0), V(3, 2, dz), V(0, 2, 0)];
      let res;
      for (let i = 0; i < 4; i++) res = drawSegments(m, [[pts[i], pts[(i + 1) % 4]]]);
      expect(m.faces.size).toBe(0); // the exact arrangement cannot close it
      const near = closeNearPlanar(m, res!.edges);
      expect(!!near.face).toBe(expectFace);
      expect(near.deviation).toBeGreaterThan(0);
      if (expectFace) {
        expect(m.faces.size).toBe(1);
        expect([...m.faces][0].normal().z).toBeGreaterThan(0.99);
      }
    }
  });
});
