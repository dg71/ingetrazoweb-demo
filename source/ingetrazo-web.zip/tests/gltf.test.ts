import { describe, expect, it } from 'vitest';
import { Vector2, Vector3 } from 'three';
import { fitUvw, importGLTF } from '../src/io/gltf';
import { Model } from '../src/core/scene';

/** A minimal GLB: one unit cube (24 corners, 12 triangles), a red material,
 * used by two nodes — the second 3 m along +X and 1 m up (+Y in glTF). */
function cubeGlb(): Uint8Array {
  const pos: number[] = [];
  const idx: number[] = [];
  const faces = [
    [[0, 0, 1], [1, 0, 1], [1, 1, 1], [0, 1, 1]],
    [[1, 0, 0], [0, 0, 0], [0, 1, 0], [1, 1, 0]],
    [[1, 0, 1], [1, 0, 0], [1, 1, 0], [1, 1, 1]],
    [[0, 0, 0], [0, 0, 1], [0, 1, 1], [0, 1, 0]],
    [[0, 1, 1], [1, 1, 1], [1, 1, 0], [0, 1, 0]],
    [[0, 0, 0], [1, 0, 0], [1, 0, 1], [0, 0, 1]],
  ];
  for (const f of faces) {
    const b = pos.length / 3;
    for (const p of f) pos.push(...p);
    idx.push(b, b + 1, b + 2, b, b + 2, b + 3);
  }
  const posBytes = new Float32Array(pos);
  const idxBytes = new Uint16Array(idx);
  const bin = new Uint8Array(posBytes.byteLength + idxBytes.byteLength);
  bin.set(new Uint8Array(posBytes.buffer), 0);
  bin.set(new Uint8Array(idxBytes.buffer), posBytes.byteLength);
  const json = {
    asset: { version: '2.0' },
    scene: 0,
    scenes: [{ nodes: [0, 1] }],
    nodes: [{ mesh: 0, name: 'A' }, { mesh: 0, name: 'B', translation: [3, 1, 0] }],
    meshes: [{ primitives: [{ attributes: { POSITION: 0 }, indices: 1, material: 0 }] }],
    materials: [{ name: 'Rot', pbrMetallicRoughness: { baseColorFactor: [0.8, 0.1, 0.1, 1] } }],
    buffers: [{ byteLength: bin.byteLength }],
    bufferViews: [
      { buffer: 0, byteOffset: 0, byteLength: posBytes.byteLength },
      { buffer: 0, byteOffset: posBytes.byteLength, byteLength: idxBytes.byteLength },
    ],
    accessors: [
      { bufferView: 0, componentType: 5126, count: 24, type: 'VEC3', min: [0, 0, 0], max: [1, 1, 1] },
      { bufferView: 1, componentType: 5123, count: 36, type: 'SCALAR' },
    ],
  };
  const pad = (b: Uint8Array, fill: number) => {
    const n = Math.ceil(b.length / 4) * 4;
    const out = new Uint8Array(n).fill(fill);
    out.set(b);
    return out;
  };
  const jsonBytes = pad(new TextEncoder().encode(JSON.stringify(json)), 0x20);
  const binBytes = pad(bin, 0);
  const total = 12 + 8 + jsonBytes.length + 8 + binBytes.length;
  const out = new Uint8Array(total);
  const dv = new DataView(out.buffer);
  dv.setUint32(0, 0x46546c67, true);
  dv.setUint32(4, 2, true);
  dv.setUint32(8, total, true);
  dv.setUint32(12, jsonBytes.length, true);
  dv.setUint32(16, 0x4e4f534a, true);
  out.set(jsonBytes, 20);
  const o = 20 + jsonBytes.length;
  dv.setUint32(o, binBytes.length, true);
  dv.setUint32(o + 4, 0x004e4942, true);
  out.set(binBytes, o + 8);
  return out;
}

describe('glTF import', () => {
  it('turns triangles into faces, keeps instancing, colour and turns Y-up to Z-up', async () => {
    const model = new Model();
    const res = await importGLTF(cubeGlb(), 'Würfel', model);
    expect(res.triangles).toBe(12);
    expect(res.meshes).toBe(1);
    const [a, b] = res.group.children;
    expect(res.group.children.length).toBe(2);
    expect(a.mesh).toBe(b.mesh); // one shared mesh → component copies
    expect(a.component && b.component).toBe(true);
    expect(a.mesh.faces.size).toBe(6); // the 12 triangles merged into 6 quads
    for (const e of a.mesh.edges) expect(e.faces.length).toBe(2);
    const f = [...a.mesh.faces][0];
    expect(f.attrs.color![0]).toBeGreaterThan(0.85); // sRGB of linear 0.8
    expect(f.attrs.mat).toBe('Rot');
    // Node B: glTF (3, 1, 0) → Z-up (3, 0, 1).
    const t = new Vector3().setFromMatrixPosition(b.matrix);
    expect(t.x).toBeCloseTo(3);
    expect(t.y).toBeCloseTo(0);
    expect(t.z).toBeCloseTo(1);
    // The cube itself stands Z-up: its height runs along +Z.
    const bb = a.mesh.bounds()!;
    expect(bb.max.z - bb.min.z).toBeCloseTo(1);
  });

  it('fits the affine UV map of a triangle', () => {
    const p = [new Vector3(0, 0, 0), new Vector3(2, 0, 0), new Vector3(0, 0, 1)];
    const t = [new Vector2(0, 0), new Vector2(1, 0), new Vector2(0, 0.5)];
    const m = fitUvw(p, t)!;
    const at = (q: Vector3) => [m[0] * q.x + m[1] * q.y + m[2] * q.z + m[3], m[4] * q.x + m[5] * q.y + m[6] * q.z + m[7]];
    for (let i = 0; i < 3; i++) {
      expect(at(p[i])[0]).toBeCloseTo(t[i].x);
      expect(at(p[i])[1]).toBeCloseTo(t[i].y);
    }
  });
});
