import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { loadIgz, saveIgz } from '../src/io/igz';

const ex = (n: string) => new Uint8Array(readFileSync(new URL(`../public/examples/${n}`, import.meta.url)));

describe('igz', () => {
  for (const name of ['banca-pergola-yanque.igz', 'luminaria-solar-yanque.igz', 'arco-yanque.igz', 'pileta-fuente-yanque.igz']) {
    it(`opens ${name} and round-trips it`, async () => {
      const t0 = performance.now();
      const m = await loadIgz(ex(name), name);
      const groups = [...m.allGroups()];
      let faces = m.root.faces.size;
      for (const g of groups) faces += g.mesh.faces.size;
      console.log(name, 'groups', groups.length, 'faces', faces, 'textures', m.textures.size, `${Math.round(performance.now() - t0)} ms`);
      expect(groups.length).toBeGreaterThan(0);
      expect(faces).toBeGreaterThan(0);
      const blob = await saveIgz(m);
      const m2 = await loadIgz(new Uint8Array(await blob.arrayBuffer()), name);
      let faces2 = m2.root.faces.size;
      for (const g of m2.allGroups()) faces2 += g.mesh.faces.size;
      expect(faces2).toBe(faces);
      expect(m2.textures.size).toBe(m.textures.size);
    });
  }
});
