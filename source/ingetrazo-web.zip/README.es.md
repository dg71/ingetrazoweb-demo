# IngeTrazo Web

[English](README.md) · [Deutsch](README.de.md) · **Español**

Modelador 3D libre para arquitectura, ingeniería y diseño, **directamente en el navegador**:
dibuja como a mano alzada, con Empujar/Tirar. Una adaptación web de
[IngeTrazo](https://github.com/ingelibre/ingetrazo) (Python/Qt) a TypeScript y three.js.
Lee y escribe el formato de documento `.igz` de IngeTrazo.

Todo se ejecuta localmente en el navegador. No hay servidor y los documentos nunca salen de tu computadora.
La interfaz está disponible en inglés (predeterminado), alemán y español.

![IngeTrazo Web](docs/screenshots/es.png)

## Primeros pasos

```bash
npm install
npm run dev        # http://localhost:5173
npm test           # geometry and file-format tests (vitest)
npm run build      # static build in dist/ (relative paths, runs from any sub-folder)
```

## Funciones

- **Vista**: cámara con Z hacia arriba, órbita alrededor del punto bajo el cursor (botón central del mouse),
  desplazamiento (botón derecho / Shift+central), zoom hacia el cursor, gestos de trackpad,
  perspectiva ↔ paralela, vistas estándar, ver todo, rayos X, aristas ocultas.
- **Cubo de vistas**: haz clic en una cara, arista o esquina para obtener una vista recta u oblicua; arrástralo para orbitar.
- **Inferencia**: extremo, punto medio, en arista, en cara, ejes magnéticos rojo/verde/azul.
  Shift bloquea la dirección y las teclas de flecha bloquean un eje.
- **Cuadro de control de valores**: simplemente escribe y presiona Enter, p. ej. `2,5`, `250cm`, `4;3` (rectángulo),
  `24s` (segmentos), `3:12` (pendiente al rotar), `3x` (matriz después de una copia).
- **Dibujo**: Línea, Rectángulo, círculo, polígono. Los contornos cerrados se convierten automáticamente en caras
  (también cuando sus vértices se salen unos milímetros del plano). Dibujar sobre una cara la divide o
  le abre un agujero.
- **Empujar/Tirar**: una cara aislada se convierte en un sólido, una cara superior se estira, aparecen huecos y
  escalones, las caras laterales coplanares se fusionan. Ctrl = copiar (apilar un piso), doble clic = última distancia.
- **Mover / Copiar / Matriz, Rotar** (ajuste angular de 15°), **Borrador** (Ctrl = suavizar, Shift = ocultar),
  **Bote de pintura** (colores, materiales del documento, Alt = muestrear), **Cinta métrica** con líneas y puntos guía.
- **Grupos y componentes**: crear, editar (doble clic), explotar, hacer único.
  Las copias de un componente comparten su geometría.
- **Sólidos y agujeros** (como en Tinkercad): convierte un grupo en agujero con *Shift+B* (se muestra
  en gris translúcido), luego selecciona sólidos y agujeros juntos (también geometría suelta) y agrúpalos
  con *G* (o *Ctrl+G*): los agujeros cortan los sólidos y los sólidos se unen. Un agujero sigue siendo agujero,
  incluso dentro de un grupo. Las piezas se conservan ocultas dentro del resultado, así que *Descomponer* las
  recupera. Las operaciones booleanas las calcula [Manifold](https://github.com/elalish/manifold)
  (WASM, Apache-2.0). Cada pieza debe ser un sólido cerrado.
- **Archivos**: abrir (formatos 1–3, incluidas texturas incrustadas) y guardar `.igz`; importar GLB/glTF,
  STL y OBJ (los triángulos coplanares se fusionan en caras, las texturas glTF se conservan); exportar GLB/glTF,
  STL, OBJ y PNG. Copia de seguridad automática en el navegador (IndexedDB).
- **Ejemplos**: los cuatro documentos de Plaza Yanque del repositorio de IngeTrazo (menú *Archivo*).
- **Idiomas**: la interfaz está disponible en inglés (predeterminado), alemán y español; se cambia desde el menú
  *Sprache / Language / Idioma*.

## Arquitectura

| Carpeta | Contenido | Equivalente en IngeTrazo |
|---|---|---|
| `src/core/mesh.ts` | Malla con vértices compartidos, tolerancia de soldadura de 0,1 mm, aristas radiales (se permite geometría no variedad) | `core/mesh.py` |
| `src/core/arrangement.ts` | reconstruye cada cara de un plano a partir de sus aristas (cerrar, dividir, agujeros, fusionar costuras) | `core/cap_rebuild.py`, `core/topology.py` |
| `src/core/ops.ts` | dibujo con división de aristas, borrado, Empujar/Tirar, copia | `tools/pushpull.py`, `core/edits.py` |
| `src/core/csg.ts` | sólidos ∪ … − agujeros mediante Manifold; el color de cara se conserva por triángulo y luego se reconstruyen las caras planas | – |
| `src/core/history.ts` | deshacer mediante instantáneas de las mallas afectadas y del árbol de grupos | `core/history.py` |
| `src/io/igz.ts` | lectura (JSON, ZIP, bloques binarios) y escritura de `.igz` | `formats/igz.py` |
| `src/view/` | renderizado con three.js, materiales, proyección de texturas al estilo `.skp` | `views/viewport.py`, `core/texture.py` |
| `src/tools/` | herramientas e inferencia | `tools/*.py`, `core/snap.py` |

Las claves de un `.igz` que esta versión no edita (capas, escenas, láminas, cotas, etiquetas IFC …) se
conservan sin cambios al guardar.

## Extensiones

Una extensión agrega herramientas, menús, paneles laterales, superposiciones en la vista y puntos de
ajuste a IngeTrazo Web sin modificar la app. Es **un único módulo ES** cuyo export `default` es
`{ id, name, setup(api) }`. La API está en [`src/ext.ts`](src/ext.ts); todo lo que una extensión puede
importar de `ingetrazo-web` figura en [`src/index.ts`](src/index.ts) (geometría `Mesh`/`ops`, documento
`Group`/`Model`, `Tool`, `units`, `dialog`, `combineSolids`, `t`/`addTranslations` …).

### 1. Escribirla

Una extensión mínima: un menú que inserta un cubo de 1 m como grupo, en un solo paso de deshacer.

```ts
import { Vector3 } from 'three';
import { type Extension, Group, ops, t, addTranslations } from 'ingetrazo-web';

addTranslations('de', { 'Insert cube': 'Würfel einfügen' });
addTranslations('es', { 'Insert cube': 'Insertar cubo' });

const extension: Extension = {
  id: 'cube',            // key for group.extra.ext.cube
  name: 'Cube',
  setup(api) {
    const app = api.app;
    api.addMenu('Cube', [{
      label: t('Insert cube'),
      run: () => {
        const g = new Group(undefined, 'Cube');
        const pts = [new Vector3(0, 0, 0), new Vector3(1, 0, 0), new Vector3(1, 1, 0), new Vector3(0, 1, 0)];
        const { faces } = ops.drawSegments(g.mesh, ops.loopSegments(pts));
        ops.pushPull(g.mesh, faces[0], 1);
        g.extra.ext = { cube: { size: 1 } };          // saved in the .igz
        const tx = app.history.begin(t('Insert cube')).structure();
        g.parent = app.context;
        app.contextGroups.push(g);
        app.model.touch();
        tx.commit();                                  // one undo step
      },
    }]);
  },
};
export default extension;
```

### 2. La API

`setup(api)` recibe:

| Método | Agrega |
|---|---|
| `addTool(tool, svgIcon)` | una herramienta en la barra (subclase de `Tool`: `down/move/up`, `hint()`, `value(text)` para valores escritos, `shortcut`) |
| `addMenu(label, items)` | un menú antes de *Ayuda*; elementos `{ label, run, key?, enabled?, checked? }` o `'-'` |
| `addPanel({ title, render })` | un panel lateral; `render(body)` se ejecuta al cambiar la selección, el documento o el historial |
| `addOverlay(object3d)` | objetos three.js adicionales en la vista (coordenadas globales) |
| `addSnapPoints(() => points)` | puntos a los que se ajustan todas las herramientas |
| `redraw()` | redibujar tras cambiar una superposición |
| `api.app` | la aplicación: `model`, `sel`, `history`, `toast()`, `setTool()`, `inference`, `vp` |

### 3. Compilarla

Empaquétela como un único módulo ES con `three` e `ingetrazo-web` como **externos**; la app le entrega
sus propias copias al cargarla (un solo three.js, las mismas clases). Con Vite:

```ts
// vite.config.ts
import { defineConfig } from 'vite';
export default defineConfig({
  build: {
    lib: { entry: 'src/index.ts', formats: ['es'], fileName: () => 'my-extension.js' },
    rollupOptions: { external: ['three', 'ingetrazo-web'] },
  },
});
```

Para la verificación de tipos, apunte `ingetrazo-web` a este repositorio, p. ej. con
`"paths": { "ingetrazo-web": ["../ingetrazo-web/src/index.ts"] }` en `tsconfig.json`, o instálelo como
dependencia (`npm i ../ingetrazo-web`).

### 4. Cargarla

- **Instalar**: menú *Extensiones ▸ Instalar (dirección)…* con la URL del módulo (accesible con CORS),
  o *Instalar (archivo)…* con el archivo `.js`. La app se recarga; el navegador recuerda la extensión.
- **Desarrollar**: `http://localhost:5173/?ext=http://localhost:8080/my-extension.js` la carga solo para esta visita.
- **Quitar**: *Extensiones ▸ Quitar: …*.
- **Construir una app propia**: `startApp({ extensions: [extension], brand, title })` de `ingetrazo-web`.

### 5. Reglas prácticas

- Guarde sus parámetros en el grupo, en `group.extra.ext.<id>`; se guardan en el `.igz` (como `ext`, igual que en IngeTrazo) y sobreviven a deshacer.
- Envuelva cada cambio en `app.history.begin(label).track(mesh).structure() … tx.commit()` para que sea un solo paso de deshacer.
- Escriba los textos de la interfaz en inglés dentro de `t()`; registre alemán y español con `addTranslations('de' | 'es', { Inglés: traducción })`.
- Una excepción en `setup()` se captura y registra; nunca rompe la app.

### Ejemplos

- [`examples/extension-stairs`](examples/extension-stairs/src/index.ts): generador de escaleras con herramienta, panel, menú, puntos de ajuste y traducciones (~140 líneas). Compilar: `npm run build:example-ext` → `examples/extension-stairs/dist/stairs.js`.

## Aún no adaptado

Arco, mano alzada, equidistancia, Sígueme, redondeo, escalar, simetría, intersecar caras, planos de sección, edición
de cotas y textos, escenas, gestión de capas, composición de láminas, sol y sombras,
georreferenciación, importación/exportación de `.skp`, DXF e IFC.

## Licencia

GPL-3.0-or-later, igual que IngeTrazo (ver `LICENSE`). Los conceptos, el formato de archivo y los documentos de ejemplo
provienen de IngeTrazo, © 2026 Marco Sumari Tellez y colaboradores de IngeTrazo.
